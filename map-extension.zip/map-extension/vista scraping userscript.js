// ==UserScript==
// @name         Vista API scraper tester
// @namespace    http://tampermonkey.net/
// @version      1.0
// @match        https://www.amazonlogistics.com/sortcenter/vista/*
// @match        https://trans-logistics.amazon.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const API_URL = "/sortcenter/vista/controller/getContainersDetailByCriteria";

    function createMainButton() {
        const btn = document.createElement("div");
        btn.textContent = "LOAD DASHBOARD";
        btn.style.all = "initial";
        btn.style.position = "fixed";
        btn.style.right = "20px";
        btn.style.bottom = "10%";
        btn.style.zIndex = "2147483647";
        btn.style.padding = "12px 16px";
        btn.style.background = "#ff9900";
        btn.style.color = "#000";
        btn.style.borderRadius = "8px";
        btn.style.cursor = "pointer";
        btn.style.fontWeight = "bold";
        btn.style.fontFamily = "Arial, sans-serif";
        btn.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
        btn.style.userSelect = "none";

        btn.addEventListener("click", loadData, true);
        document.body.appendChild(btn);

        // Add API test button
        const testBtn = document.createElement("div");
        testBtn.textContent = "TEST API";
        testBtn.style.all = "initial";
        testBtn.style.position = "fixed";
        testBtn.style.right = "20px";
        testBtn.style.bottom = "calc(10% + 60px)";
        testBtn.style.zIndex = "2147483647";
        testBtn.style.padding = "12px 16px";
        testBtn.style.background = "#232f3e";
        testBtn.style.color = "#fff";
        testBtn.style.borderRadius = "8px";
        testBtn.style.cursor = "pointer";
        testBtn.style.fontWeight = "bold";
        testBtn.style.fontFamily = "Arial, sans-serif";
        testBtn.style.boxShadow = "0 4px 12px rgba(0,0,0,0.3)";
        testBtn.style.userSelect = "none";

        testBtn.addEventListener("click", openApiTester, true);
        document.body.appendChild(testBtn);
    }

    function openApiTester(e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const panel = document.createElement("div");
        panel.style.position = "fixed";
        panel.style.top = "10%";
        panel.style.left = "10%";
        panel.style.width = "80%";
        panel.style.height = "80%";
        panel.style.background = "white";
        panel.style.zIndex = "2147483647";
        panel.style.overflow = "auto";
        panel.style.padding = "20px";
        panel.style.boxShadow = "0 0 20px rgba(0,0,0,0.4)";
        panel.style.fontFamily = "Arial";

        const closeBtn = document.createElement("button");
        closeBtn.textContent = "Close";
        closeBtn.onclick = () => panel.remove();

        const title = document.createElement("h3");
        title.textContent = "API Request Tester";
        title.style.marginTop = "0";

        const endpointLabel = document.createElement("label");
        endpointLabel.textContent = "Endpoint: ";
        const endpointInput = document.createElement("input");
        endpointInput.type = "text";
        endpointInput.value = "/sortcenter/vista/controller/getContainersDetailByCriteria";
        endpointInput.style.width = "100%";
        endpointInput.style.marginBottom = "10px";

        const endTime = Date.now();
        const startTime = endTime - (36 * 60 * 60 * 1000);

        const payloadLabel = document.createElement("label");
        payloadLabel.textContent = "JSON Payload (edit to test different parameters):";
        const payloadTextarea = document.createElement("textarea");
        payloadTextarea.style.width = "100%";
        payloadTextarea.style.height = "200px";
        payloadTextarea.style.fontFamily = "monospace";
        payloadTextarea.style.marginBottom = "10px";
        payloadTextarea.value = JSON.stringify({
            entity: "getContainersDetailByCriteria",
            nodeId: "MTN9",
            timeBucket: {
                fieldName: "physicalLocationMoveTimestamp",
                startTime: startTime,
                endTime: endTime
            },
            filterBy: {
                state: ["Diverted"],
                isMissing: [false]
            },
            containerTypes: ["PACKAGE"],
            fetchCompoundContainerDetails: false,
            includeCriticalCptEnclosingContainers: false
        }, null, 2);

        const sendBtn = document.createElement("button");
        sendBtn.textContent = "Send Request";
        sendBtn.style.marginRight = "10px";
        sendBtn.onclick = async () => {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
            if (!csrfToken) return alert("CSRF token not found");

            try {
                const payload = JSON.parse(payloadTextarea.value);
                const body = "jsonObj=" + encodeURIComponent(JSON.stringify(payload));

                const response = await fetch(endpointInput.value, {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest",
                        "anti-csrftoken-a2z": csrfToken
                    },
                    body: body
                });

                const data = await response.json();
                responseTextarea.value = JSON.stringify(data, null, 2);
                console.log("API Response:", data);
            } catch (error) {
                responseTextarea.value = "Error: " + error.message;
                console.error("API Error:", error);
            }
        };

        const responseLabel = document.createElement("label");
        responseLabel.textContent = "Response (also logged to console):";
        const responseTextarea = document.createElement("textarea");
        responseTextarea.style.width = "100%";
        responseTextarea.style.height = "300px";
        responseTextarea.style.fontFamily = "monospace";
        responseTextarea.readOnly = true;

        panel.appendChild(closeBtn);
        panel.appendChild(title);
        panel.appendChild(endpointLabel);
        panel.appendChild(endpointInput);
        panel.appendChild(document.createElement("br"));
        panel.appendChild(payloadLabel);
        panel.appendChild(document.createElement("br"));
        panel.appendChild(payloadTextarea);
        panel.appendChild(document.createElement("br"));
        panel.appendChild(sendBtn);
        panel.appendChild(document.createElement("br"));
        panel.appendChild(document.createElement("br"));
        panel.appendChild(responseLabel);
        panel.appendChild(document.createElement("br"));
        panel.appendChild(responseTextarea);

        document.body.appendChild(panel);
    }

    async function loadData(e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
        if (!csrfToken) return alert("CSRF token not found");

        const states = ["Diverted", "InFacilityReceived", "InboundYard", "InboundDock", "Staged", "InTransit"];
        const allData = [];
        const stateCounts = {};

        // Show loading indicator
        const loadingDiv = document.createElement("div");
        loadingDiv.textContent = "Loading data...";
        loadingDiv.style.position = "fixed";
        loadingDiv.style.top = "50%";
        loadingDiv.style.left = "50%";
        loadingDiv.style.transform = "translate(-50%, -50%)";
        loadingDiv.style.background = "white";
        loadingDiv.style.padding = "20px";
        loadingDiv.style.zIndex = "2147483647";
        loadingDiv.style.boxShadow = "0 0 20px rgba(0,0,0,0.4)";
        loadingDiv.style.fontFamily = "Arial";
        document.body.appendChild(loadingDiv);

        // Fetch data for each state separately
        for (const state of states) {
            loadingDiv.textContent = `Loading ${state}...`;

            // Calculate dynamic time range (36 hours back from now)
            const endTime = Date.now();
            const startTime = endTime - (36 * 60 * 60 * 1000); // 36 hours in milliseconds

            const jsonPayload = {
                entity: "getContainersDetailByCriteria",
                nodeId: "MTN9",
                timeBucket: {
                    fieldName: "physicalLocationMoveTimestamp",
                    startTime: startTime,
                    endTime: endTime
                },
                filterBy: {
                    state: [state],
                    isMissing: [false]
                },
                containerTypes: ["PACKAGE"],
                fetchCompoundContainerDetails: false,
                includeCriticalCptEnclosingContainers: false
            };

            const body = "jsonObj=" + encodeURIComponent(JSON.stringify(jsonPayload));

            try {
                const response = await fetch(API_URL, {
                    method: "POST",
                    credentials: "include",
                    headers: {
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "X-Requested-With": "XMLHttpRequest",
                        "anti-csrftoken-a2z": csrfToken
                    },
                    body: body
                });

                const data = await response.json();
                const packages = flattenPackages(data);
                stateCounts[state] = packages.length;
                allData.push(...packages);
                loadingDiv.textContent = `Loaded ${state}: ${packages.length} packages (Total: ${allData.length})`;
                await new Promise(resolve => setTimeout(resolve, 500)); // Small delay between requests
            } catch (error) {
                console.error(`Error loading ${state}:`, error);
                alert(`Error loading ${state}: ${error.message}`);
            }
        }

        loadingDiv.remove();
        buildDashboard({ allPackages: allData, stateCounts: stateCounts });
    }

    function flattenPackages(data) {
        const groups = data?.ret?.getContainersDetailByCriteriaOutput?.containerDetails || [];
        const rows = [];

        groups.forEach(group => {
            (group.containerDetails || []).forEach(pkg => {
                // Log first package to console to see all available fields
                if (rows.length === 0) {
                    console.log("Sample package object:", pkg);
                    console.log("Available fields:", Object.keys(pkg));
                }

                rows.push({
                    id: pkg.id,
                    route: pkg.route,
                    state: pkg.lastEventType,
                    location: pkg.location,
                    dwell: pkg.dwellTimeInMinutes,
                    stackingFilter: pkg.stackingFilter,
                    inboundLoadId: pkg.inboundLoadId,
                    cpt: new Date(pkg.cpt).toLocaleString(),
                    // Try to capture size if it exists under various possible field names
                    size: pkg.size || pkg.packageSize || pkg.containerSize || pkg.dimension || "N/A"
                });
            });
        });

        return rows;
    }

    function buildDashboard(data) {
        const rows = data.allPackages || flattenPackages(data);
        const stateCounts = data.stateCounts || {};

        const panel = document.createElement("div");
        panel.style.position = "fixed";
        panel.style.top = "5%";
        panel.style.left = "5%";
        panel.style.width = "90%";
        panel.style.height = "85%";
        panel.style.background = "white";
        panel.style.zIndex = "2147483647";
        panel.style.overflow = "auto";
        panel.style.padding = "20px";
        panel.style.boxShadow = "0 0 20px rgba(0,0,0,0.4)";
        panel.style.fontFamily = "Arial";

        const closeBtn = document.createElement("button");
        closeBtn.textContent = "Close";
        closeBtn.onclick = () => panel.remove();

        const exportBtn = document.createElement("button");
        exportBtn.textContent = "Export CSV";
        exportBtn.style.marginLeft = "10px";
        exportBtn.onclick = () => exportCSV(rows);

        const header = document.createElement("div");
        header.appendChild(closeBtn);
        header.appendChild(exportBtn);
        header.style.marginBottom = "15px";

        // Add state counts summary
        if (Object.keys(stateCounts).length > 0) {
            const summaryDiv = document.createElement("div");
            summaryDiv.style.marginBottom = "15px";
            summaryDiv.style.padding = "10px";
            summaryDiv.style.background = "#f0f0f0";
            summaryDiv.style.borderRadius = "5px";

            const summaryTitle = document.createElement("strong");
            summaryTitle.textContent = "Package Counts by State:";
            summaryDiv.appendChild(summaryTitle);
            summaryDiv.appendChild(document.createElement("br"));

            Object.entries(stateCounts).forEach(([state, count]) => {
                const stateInfo = document.createElement("div");
                stateInfo.textContent = `${state}: ${count}`;
                stateInfo.style.marginLeft = "10px";
                summaryDiv.appendChild(stateInfo);
            });

            const totalDiv = document.createElement("div");
            totalDiv.style.marginTop = "5px";
            totalDiv.style.fontWeight = "bold";
            totalDiv.textContent = `Total: ${rows.length}`;
            summaryDiv.appendChild(totalDiv);

            header.appendChild(summaryDiv);
        }

        const table = document.createElement("table");
        table.border = "1";
        table.style.width = "100%";
        table.style.borderCollapse = "collapse";

        const columns = Object.keys(rows[0] || {});
        const thead = document.createElement("thead");
        const headRow = document.createElement("tr");

        columns.forEach(col => {
            const th = document.createElement("th");
            th.textContent = col;
            headRow.appendChild(th);
        });

        thead.appendChild(headRow);
        table.appendChild(thead);

        const tbody = document.createElement("tbody");

        rows.forEach(row => {
            const tr = document.createElement("tr");
            columns.forEach(col => {
                const td = document.createElement("td");
                td.textContent = row[col];
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
        panel.appendChild(header);
        panel.appendChild(table);
        document.body.appendChild(panel);
    }

    function exportCSV(rows) {
        const columns = Object.keys(rows[0]);
        const csv = [
            columns.join(","),
            ...rows.map(row =>
                columns.map(col => `"${row[col] ?? ""}"`).join(",")
            )
        ].join("\n");

        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "packages.csv";
        a.click();
        URL.revokeObjectURL(url);
    }

    createMainButton();
})();