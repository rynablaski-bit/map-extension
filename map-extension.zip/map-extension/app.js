// --- 0. Global Error Catcher ---
window.onerror = function(message, source, lineno, colno, error) {
  console.error("❌ GLOBAL ERROR:", message, "\nAt:", source, `:${lineno}:${colno}`, "\nError obj:", error);
  try {
    document.body.innerHTML = `<div style="padding: 20px; font-family: monospace; background: #ff0000; color: white; border: 5px solid darkred; margin: 20px; border-radius: 5px; z-index: 99999; position: fixed; top: 0; left: 0;">
      <h3>❌ A FATAL JAVASCRIPT ERROR OCCURRED:</h3>
      <p>${message}</p>
      <p>At: ${source.split('/').pop()}:${lineno}:${colno}</p>
      <p>Check the extension's console for more details.</p>
    </div>`;
  } catch (e) {}
  return true;
};

console.log("🚀 app.js script started");

// --- 1. Create and inject the NEW layout structure ---
let rootContainer, mapContainer, sidebarContainer;

function injectDynamicStyles() {
  const style = document.createElement('style');
  style.innerHTML = `
    #add-equipment-ui {
      margin-top: 20px;
      border-top: 2px solid #eee;
      padding-top: 15px;
    }
    #equipment-search-bar {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      margin-bottom: 10px;
    }
    #equipment-search-results {
      max-height: 300px;
      overflow-y: auto;
      border: 1px solid #eee;
      border-radius: 4px;
    }
    .search-result-item {
      padding: 10px;
      font-size: 14px;
      cursor: grab;
      border-bottom: 1px solid #f0f0f0;
    }
    .search-result-item:hover {
      background-color: #f9f9f9;
    }
    .search-result-item:last-child {
      border-bottom: none;
    }
    .search-result-item.selected {
      background-color: #007bff;
      color: white;
      font-weight: bold;
    }
  `;
  document.head.appendChild(style);
}

try {
  rootContainer = document.createElement('div');
  rootContainer.id = 'ryan-console-root';

  mapContainer = document.createElement('div');
  mapContainer.id = 'map-container';

  sidebarContainer = document.createElement('div');
  sidebarContainer.id = 'sidebar-container';
  
  // Create settings icon
  const settingsIcon = document.createElement('div');
  settingsIcon.id = 'settings-icon';
  settingsIcon.innerHTML = '⚙️';
  settingsIcon.title = 'Settings';

  rootContainer.appendChild(settingsIcon);
  rootContainer.appendChild(mapContainer);
  rootContainer.appendChild(sidebarContainer);
  
  if (document.body) {
    document.body.appendChild(rootContainer);
    console.log("✅ DOM layout injected onto document.body");
    console.log("   Current domain:", window.location.hostname);
  } else {
    window.addEventListener('DOMContentLoaded', () => {
      document.body.appendChild(rootContainer);
      console.log("✅ DOM layout injected (on DOMContentLoaded)");
      console.log("   Current domain:", window.location.hostname);
    });
  }
  
  injectDynamicStyles();

} catch (err) {
  console.error("❌ FAILED AT STEP 1 (DOM Creation):", err);
}

// --- 2. Global Constants and State ---
const SCALE = 5;

let stage, backgroundLayer, interactiveLayer, textLayer, transformer;

let allMapEntities = [];
let selectedNodeId = 'MTN9';

// Heat map state
let heatMapData = null; // { packagesByFilter, loadInfo, vrids, activeVrids }
let heatMapOriginalColors = {}; // shapeId -> original fill color

// Inbound view state
let inboundViewData = null; // { loads, dockDoorMap: dockDoorLabel -> loadEntry }
let inboundTrailerShapes = []; // Konva shapes for trailer rectangles
let currentTool = 'none';
let currentView = 'initial';
let currentTab = 'map'; // 'map' or 'api-test'

let allApiResources = [];
let missingResources = {};
// Maps resource label -> array of stacking filter strings
let stackingFilterMap = {};
// Maps stacking filter -> VSM marker string
let vsmMap = {};
// Maps stacking area label -> { chutes: [chuteId, ...], containerizeOption, waterspiderZone }
let chuteConnectionMap = {};
// Reverse: chuteId -> array of stacking area labels
let chuteToStackingMap = {};
// Maps chute short label -> full chuteId
let chuteLabelToIdMap = {};
// Zone glow colors: zone name -> hex color (persisted to localStorage)
const DEFAULT_ZONE_COLORS = { '__NC__': '#ff4444' };
const ZONE_COLORS_KEY = 'ryanConsole_zoneGlowColors';
let zoneGlowColors = { ...DEFAULT_ZONE_COLORS, ...(JSON.parse(localStorage.getItem(ZONE_COLORS_KEY) || '{}')) };
function saveZoneColors() { localStorage.setItem(ZONE_COLORS_KEY, JSON.stringify(zoneGlowColors)); }
const toolToResourceType = {
  'add-chute': 'CHUTE',
  'add-buffer-zone': 'GENERAL_AREA',
  'add-staging-pod': 'STAGING_AREA'
};

const equipmentSizes = {
  'STACKING_AREA': { l: 1.1, w: 1.25 },
  'CHUTE': { l: 1.1, w: 4 },
  'GENERAL_AREA': { l: 3, w: 3 },
  'STAGING_AREA': { l: 2.5, w: 2.5 }
};

const STORAGE_KEY_PREFIX = 'ryanConsole_';
let lastSaveTime = null;
let selectedImportFile = null;

// 🔧 NEW: Domain-hopping state management
let domainHopState = {
  isHopping: false,
  targetDomain: null,
  returnDomain: null,
  pendingApiCalls: [],
  savedState: null,
  loadingOverlay: null
};



// 🚀 PERFORMANCE: Track zoom level for cache invalidation
let lastCachedScale = 1;
let isInteracting = false;

// --- 3. UI Rendering Functions ---

function renderApiTestContent() {
  // Default date range: start of today to +48 hours
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endDate = new Date(startOfDay.getTime() + 48 * 60 * 60 * 1000);
  const toLocalISO = d => {
    const pad = n => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  };
  const defaultStart = toLocalISO(startOfDay);
  const defaultEnd = toLocalISO(endDate);

  return `
    <div class="api-test-container">
      <h3>API Testing Lab</h3>

      <div class="api-section">
        <div class="api-endpoint" style="background: #d4edda; border: 2px solid #28a745; padding: 15px; border-radius: 8px;">
          <h5 style="color: #155724;">Inbound Dock View (Same-Origin)</h5>
          <p style="color: #155724; margin: 10px 0;">Fetches prioritized inbound dock data and exports to Excel. No domain hop needed.</p>
          <label>Node ID:</label>
          <input type="text" id="api-node-id-inbound" value="MTN9" class="api-input">
          <button id="test-api-inbound" class="button" style="margin-top: 10px; background: #28a745; color: #fff; font-weight: bold; font-size: 16px; padding: 12px 24px;">
            &#x1F4E6; Fetch Inbound &amp; Export Excel
          </button>
          <div id="api-result-inbound" class="api-result"></div>
        </div>

        <div class="api-endpoint" style="background: #fff3cd; border: 2px solid #ffc107; padding: 15px; border-radius: 8px;">
          <h5 style="color: #856404;">&#x1F4CA; Inbound Dock View &mdash; Full Export (Same-Origin)</h5>
          <p style="color: #856404; margin: 10px 0;">Fetches the inbound dock view with date range and exports every field from the API response to Excel. Nothing filtered out.</p>
          <label>Node ID:</label>
          <input type="text" id="api-node-id-fullraw" value="MTN9" class="api-input">
          <div style="display: flex; gap: 10px; margin-top: 8px;">
            <div style="flex: 1;">
              <label style="font-size: 12px; color: #856404;">Start Date:</label>
              <input type="datetime-local" id="api-fullraw-start" value="${defaultStart}" class="api-input" style="font-size: 13px;">
            </div>
            <div style="flex: 1;">
              <label style="font-size: 12px; color: #856404;">End Date:</label>
              <input type="datetime-local" id="api-fullraw-end" value="${defaultEnd}" class="api-input" style="font-size: 13px;">
            </div>
          </div>
          <button id="test-api-fullraw" class="button" style="margin-top: 10px; background: #ffc107; color: #333; font-weight: bold; font-size: 16px; padding: 12px 24px;">
            &#x1F4CA; Fetch Full Raw &amp; Export Excel
          </button>
          <div id="api-result-fullraw" class="api-result"></div>
        </div>

        <div class="api-endpoint" style="background: #cce5ff; border: 2px solid #007bff; padding: 15px; border-radius: 8px;">
          <h5 style="color: #004085;">&#x1F4CB; Inbound Load Container Details (Same-Origin)</h5>
          <p style="color: #004085; margin: 10px 0;">Fetches package-level details for all inbound loads and exports to Excel. Runs the inbound call first, then drills into each load.</p>
          <label>Node ID:</label>
          <input type="text" id="api-node-id-containers" value="MTN9" class="api-input">
          <button id="test-api-containers" class="button" style="margin-top: 10px; background: #007bff; color: #fff; font-weight: bold; font-size: 16px; padding: 12px 24px;">
            &#x1F4CB; Fetch All Containers &amp; Export Excel
          </button>
          <div id="api-result-containers" class="api-result"></div>
        </div>
        
        <div class="api-endpoint" style="background: #e0e0e0; border: 2px solid #666; padding: 15px; border-radius: 8px;">
          <h5 style="color: #333;">&#x1F680; Full Inbound Pipeline (Dock View → Containers → Tantei)</h5>
          <p style="color: #555; margin: 10px 0;">Runs all three APIs in sequence: fetches inbound loads, drills into each for packages, then enriches VRIDs that have packages via Tantei. Exports one combined CSV.</p>
          <label>Node ID:</label>
          <input type="text" id="api-node-id-pipeline" value="MTN9" class="api-input">
          <div style="display: flex; gap: 10px; margin-top: 8px;">
            <div style="flex: 1;">
              <label style="font-size: 12px; color: #555;">Start Date:</label>
              <input type="datetime-local" id="api-pipeline-start" value="${defaultStart}" class="api-input" style="font-size: 13px;">
            </div>
            <div style="flex: 1;">
              <label style="font-size: 12px; color: #555;">End Date:</label>
              <input type="datetime-local" id="api-pipeline-end" value="${defaultEnd}" class="api-input" style="font-size: 13px;">
            </div>
          </div>
          <button id="test-api-pipeline" class="button" style="margin-top: 10px; background: #555; color: #fff; font-weight: bold; font-size: 16px; padding: 12px 24px;">
            &#x1F680; Run Full Pipeline &amp; Export Excel
          </button>
          <div id="api-result-pipeline" class="api-result"></div>
        </div>

        <div class="api-endpoint" style="background: #e8daef; border: 2px solid #8e44ad; padding: 15px; border-radius: 8px;">
          <h5 style="color: #6c3483;">&#x1F50D; Tantei Container Search (Cross-Origin via Background)</h5>
          <p style="color: #6c3483; margin: 10px 0;">Searches Tantei for containers by VRID(s). Enter one VRID per line. Batches 5 at a time with pagination, then exports all results to CSV.</p>
          <label>Node ID:</label>
          <input type="text" id="api-node-id-tantei" value="MTN9" class="api-input">
          <label style="margin-top: 8px; display: block;">VRID(s) — one per line:</label>
          <textarea id="api-tantei-vrids" class="api-input" rows="4" style="resize: vertical; font-family: monospace;" placeholder="e.g.&#10;116CZKQ2P&#10;115RVDHDJ"></textarea>
          <button id="test-api-tantei" class="button" style="margin-top: 10px; background: #8e44ad; color: #fff; font-weight: bold; font-size: 16px; padding: 12px 24px;">
            &#x1F50D; Search Tantei &amp; Export Excel
          </button>
          <div id="api-result-tantei" class="api-result"></div>
        </div>
      </div>
    </div>
  `;
}



function renderInitialView() {
  currentView = 'initial';
  if (!mapContainer || !sidebarContainer) {
    console.error("renderInitialView failed: mapContainer or sidebarContainer is null!");
    return;
  }
  
  // Check for last used node and auto-load it
  chrome.storage.local.get(['lastUsedNode'], async (result) => {
    if (result.lastUsedNode) {
      console.log('🔄 Auto-loading last used node:', result.lastUsedNode);
      selectedNodeId = result.lastUsedNode;
      renderLoadingView();
      try {
        const data = await loadMapData(selectedNodeId);
        initializeMap(true);
        drawMap(data);
        renderMapViewSidebar();
        // Re-apply cached heat map if available
        if (heatMapData) {
          inboundViewData = null; // trailers will be redrawn if heat map had loads
          applyHeatMapColors();
        }
      } catch (err) {
        if (err.message === 'DOMAIN_HOP_INITIATED') {
          console.log('✅ Domain hop initiated for auto-load, navigating...');
          return;
        }
        console.error("❌ Failed to auto-load map:", err);
        // Clear lastUsedNode so we don't loop on next render
        chrome.storage.local.remove(['lastUsedNode']);
        showErrorModal('Please try again or review your permissions.');
        // Show the initial view if auto-load fails
        renderInitialViewContent();
      }
    } else {
      // No last used node, show the initial view
      renderInitialViewContent();
    }
  });
}

function renderInitialViewContent() {
  mapContainer.innerHTML = `
    <div style="text-align: center; padding: 40px 20px;">
      <h2 style="margin-bottom: 20px;">Load Digital Twin Map</h2>
      <p style="margin-bottom: 30px; color: var(--text-secondary);">Enter a node ID to load the map</p>
      <div style="max-width: 400px; margin: 0 auto;">
        <label for="node-input" style="display: block; text-align: left; margin-bottom: 8px; font-weight: 500; color: var(--text-primary);">Node ID:</label>
        <input 
          type="text" 
          id="node-input" 
          placeholder="e.g., MTN9, BWI1, PHL7" 
          style="width: 100%; padding: 12px; font-size: 16px; border: 2px solid var(--border-color); border-radius: 4px; margin-bottom: 20px; text-transform: uppercase; background: var(--bg-secondary); color: var(--text-primary);"
          autocomplete="off"
        >
        <button id="load-map-btn" class="button" style="width: 100%; padding: 12px; font-size: 16px;">Load Map</button>
      </div>
    </div>
  `;
  sidebarContainer.innerHTML = '<h2>My Utilities</h2><p>Enter a node ID to load the map.</p>';
  
  // Auto-capitalize node input
  const nodeInput = document.getElementById('node-input');
  if (nodeInput) {
    nodeInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.toUpperCase();
    });
  }
}

function renderEditorSetupView() {
  currentView = 'editorSetup';
  
  const hasSavedMaps = {
    'MTN9': !!localStorage.getItem(STORAGE_KEY_PREFIX + 'MTN9'),
    'BWI1': !!localStorage.getItem(STORAGE_KEY_PREFIX + 'BWI1'),
    'PHL7': !!localStorage.getItem(STORAGE_KEY_PREFIX + 'PHL7')
  };
  
  mapContainer.innerHTML = `
    <div class="editor-setup-view">
      <h3>Load Map</h3>
      <label for="node-id-select">Node ID:</label>
      <select id="node-id-select" class="styled-select">
        <option value="MTN9">MTN9 ${hasSavedMaps.MTN9 ? '💾' : ''}</option>
        <option value="BWI1">BWI1 ${hasSavedMaps.BWI1 ? '💾' : ''}</option>
        <option value="PHL7">PHL7 ${hasSavedMaps.PHL7 ? '💾' : ''}</option>
      </select>
      <button id="load-map-btn" class="button">Load Map</button>
      <p style="margin-top: 10px; font-size: 12px; color: #666;">💾 = Saved map available</p>
    </div>
  `;
  sidebarContainer.innerHTML = '<h2>My Utilities</h2><p>Select a Node to load.</p>';
}

function renderEditorTools() {
  currentView = 'editorActive';
  const saveStatus = lastSaveTime ? `<small style="color: #666; display: block; margin-top: 5px;">Last saved: ${new Date(lastSaveTime).toLocaleTimeString()}</small>` : '';
  
  sidebarContainer.innerHTML = `
    <h2>Ryan's Console</h2>
    
    <button id="save-map-btn" class="button" style="width: 100%; margin-bottom: 10px;">💾 Save Map</button>
    ${saveStatus}
    

    <div class="tool-section" style="margin-top: 10px;">
      <button id="reload-base-map-btn" class="button" style="width: 100%; margin-bottom: 5px; background-color: #dc3545; color: white; font-size: 12px;">🔄 Reload Base Map</button>
      <button id="export-map-btn" class="button" style="width: 100%; margin-bottom: 5px; font-size: 12px;">📥 Export Map</button>
      <button id="import-map-btn" class="button" style="width: 100%; margin-bottom: 5px; font-size: 12px;">📤 Import Map</button>
      <input type="file" id="import-map-input" accept=".json" style="display: none;">
      <div id="import-file-status" style="font-size: 11px; color: #666; margin-top: 5px; display: none;">
        <span id="import-file-name"></span>
        <button id="confirm-import-btn" class="button" style="font-size: 11px; padding: 5px 10px; margin-left: 5px;">Confirm Import</button>
        <button id="cancel-import-btn" class="button" style="font-size: 11px; padding: 5px 10px; margin-left: 5px; background-color: #6c757d;">Cancel</button>
      </div>
    </div>
    
    <div class="tool-section">
      <h3>Map Editor</h3>
      <button id="tool-select" class="tool-button ${currentTool === 'select' ? 'active' : ''}" data-tool="select">Select & Move</button>
      <button id="tool-delete" class="tool-button ${currentTool === 'delete' ? 'active' : ''}" data-tool="delete">Delete Element</button>
      <button id="tool-add-label" class="tool-button ${currentTool === 'add-label' ? 'active' : ''}" data-tool="add-label">Add Label to Element</button>
    </div>
    
    <div class="tool-section">
      <h3>Add Equipment</h3>
      <button id="tool-add-stacking-area" class="tool-button ${currentTool === 'add-stacking-area' ? 'active' : ''}" data-tool="add-stacking-area">Add Stacking Area</button>
      <button id="tool-add-chute" class="tool-button ${currentTool === 'add-chute' ? 'active' : ''}" data-tool="add-chute">Add Chute</button>
      <button id="tool-add-buffer-zone" class="tool-button ${currentTool === 'add-buffer-zone' ? 'active' : ''}" data-tool="add-buffer-zone">Add Buffer Zone</button>
      <button id="tool-add-staging-pod" class="tool-button ${currentTool === 'add-staging-pod' ? 'active' : ''}" data-tool="add-staging-pod">Add Staging Pod</button>
      <button id="tool-add-belt" class="tool-button ${currentTool === 'add-belt' ? 'active' : ''}" data-tool="add-belt">Add Belt</button>
    </div>
    
    <div id="add-equipment-ui"></div>
  `;
  
  // 🔧 FIX: Re-render equipment list if an equipment tool is active
  const resourceType = toolToResourceType[currentTool];
  if (resourceType) {
    const toolButton = document.querySelector(`[data-tool="${currentTool}"]`);
    const title = toolButton ? toolButton.innerText : 'Equipment';
    renderAddEquipmentUI(resourceType, title);
    renderEquipmentList(missingResources[resourceType] || []);
  }
}

// ==================== INBOUND VIEW ====================

function showInboundViewControls() {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(startOfDay.getTime() - 24 * 60 * 60 * 1000);
  const tomorrow = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000);
  const endDate = tomorrow;
  const pad = n => String(n).padStart(2, '0');
  const toLocalISO = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());

  let trailerList = '';
  if (inboundViewData) {
    const statusOrder = { 'unloading_in_progress': 0, 'ready_for_unload': 1, 'load_arrived': 2, 'loading_paused': 3, 'completed': 4, 'scheduled': 5 };
    const sorted = [...inboundViewData.loads].sort((a, b) => {
      const sa = (a.load?.status || '').toLowerCase();
      const sb = (b.load?.status || '').toLowerCase();
      return (statusOrder[sa] ?? 99) - (statusOrder[sb] ?? 99);
    });
    const rows = sorted.map(entry => {
      const vrId = entry.load?.vrId || '?';
      const status = entry.load?.status || '?';
      const route = entry.load?.route || '?';
      const door = (entry.resource || []).map(r => r.label).join(', ') || '—';
      const equip = entry.load?.equipmentType || '';
      const size = equip.includes('TWENTY_SIX') ? '26ft' : '53ft';
      const statusColor = status === 'UNLOADING_IN_PROGRESS' ? '#5cd65c' : status === 'READY_FOR_UNLOAD' ? '#f0e040' : status === 'LOADING_PAUSED' ? '#888' : '#666';
      return `<div style="font-size:11px; margin:2px 0; padding:3px 4px; border-left:3px solid ${statusColor}; background:rgba(255,255,255,0.05);">
        <span style="font-weight:bold;">${vrId}</span> <span style="color:#999;">${size}</span><br>
        <span style="color:${statusColor};">${status.replace(/_/g, ' ')}</span> — ${door}<br>
        <span style="color:#888;">${route}</span>
      </div>`;
    }).join('');
    trailerList = `
      <div style="margin-top:10px; border-top:1px solid var(--border-color); padding-top:10px;">
        <span style="font-weight:bold; font-size:13px;">Loads (${sorted.length})</span>
        <div style="max-height:400px; overflow-y:auto; margin-top:6px;">${rows}</div>
      </div>
      <button id="inbound-view-clear" class="button" style="width:100%; margin-top:8px; background:#dc3545; color:#fff;">✕ Clear Inbound View</button>
    `;
  }

  sidebarContainer.innerHTML = `
    <h2>📦 Inbound View</h2>
    <div class="tool-section">
      <div style="display:flex; gap:6px; margin-bottom:8px;">
        <div style="flex:1;">
          <label style="font-size:11px;">Start:</label>
          <input type="datetime-local" id="inbound-view-start" value="${toLocalISO(yesterday)}" class="api-input" style="font-size:12px; width:100%;">
        </div>
        <div style="flex:1;">
          <label style="font-size:11px;">End:</label>
          <input type="datetime-local" id="inbound-view-end" value="${toLocalISO(tomorrow)}" class="api-input" style="font-size:12px; width:100%;">
        </div>
      </div>
      <button id="inbound-view-run" class="button" style="width:100%; background:#555; color:#fff; font-weight:bold;">🚀 Fetch Inbound</button>
      <div id="inbound-view-status" style="margin-top:8px; font-size:12px; color:var(--text-secondary);"></div>
      ${trailerList}
    </div>
  `;
}

async function runInboundView() {
  const statusDiv = document.getElementById('inbound-view-status');
  const status = msg => { if (statusDiv) statusDiv.innerHTML = `<p style="color:#666; margin:4px 0;">${msg}</p>`; };

  try {
    status('Fetching inbound dock view...');
    const startInput = document.getElementById('inbound-view-start')?.value;
    const endInput = document.getElementById('inbound-view-end')?.value;
    const startDate = new Date(startInput).getTime();
    const endDate = new Date(endInput).getTime();

    const ibBody = [
      'entity=getInboundDockView',
      `nodeId=${encodeURIComponent(selectedNodeId)}`,
      `startDate=${startDate}`,
      `endDate=${endDate}`,
      `loadCategories=${encodeURIComponent('inboundScheduled,inboundArrived,inboundCompleted')}`,
      `shippingPurposeType=${encodeURIComponent('TRANSSHIPMENT,NON-TRANSSHIPMENT,SHIP_WITH_AMAZON')}`
    ].join('&');

    const ibResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'include', body: ibBody
    });
    if (!ibResp.ok) throw new Error(`HTTP ${ibResp.status}`);
    const loads = (await ibResp.json())?.ret?.aaData || [];

    inboundViewData = { loads };
    clearInboundTrailers();
    drawInboundTrailers();
    showInboundViewControls();
    status(`✅ ${loads.length} loads fetched`);
  } catch (error) {
    console.error('❌ Inbound view failed:', error);
    status(`❌ ${error.message}`);
  }
}

function drawInboundTrailers() {
  if (!inboundViewData || !interactiveLayer) return;

  // Build map: dock door label -> load entry (only loads assigned to a door)
  const doorToLoad = {};
  for (const entry of inboundViewData.loads) {
    const resources = entry.resource || [];
    for (const r of resources) {
      if (r.label) doorToLoad[r.label] = entry;
    }
  }

  // Find all dock door entities on the map
  const dockDoors = allMapEntities.filter(e => e.type === 'dockDoor');
  if (dockDoors.length === 0) return;

  // Get map bounding box from all entities (excluding dock doors themselves for better edge detection)
  let mapMinX = Infinity, mapMaxX = -Infinity, mapMinY = Infinity, mapMaxY = -Infinity;
  for (const e of allMapEntities) {
    if (!e.absTrans?.pt) continue;
    const ex = e.absTrans.pt.x * SCALE;
    const ey = e.absTrans.pt.y * SCALE;
    if (ex < mapMinX) mapMinX = ex;
    if (ex > mapMaxX) mapMaxX = ex;
    if (ey < mapMinY) mapMinY = ey;
    if (ey > mapMaxY) mapMaxY = ey;
  }
  const mapCentX = (mapMinX + mapMaxX) / 2;
  const mapCentY = (mapMinY + mapMaxY) / 2;

  for (const dd of dockDoors) {
    const loadEntry = doorToLoad[dd.name];
    if (!loadEntry) continue;

    const ddShape = interactiveLayer.findOne('#' + dd.id);
    if (!ddShape) continue;

    const ddX = dd.absTrans.pt.x * SCALE;
    const ddY = dd.absTrans.pt.y * SCALE;
    const ddW = (dd.lodGeomMap[1].s.l || dd.lodGeomMap[1].s.x) * SCALE;
    const ddH = (dd.lodGeomMap[1].s.w || dd.lodGeomMap[1].s.y) * SCALE;

    // Per-door placement: determine which map edge THIS door is closest to
    // then place trailer outward (away from map center)
    // scaleY(-1) means min-Y in world coords is at the TOP of the screen,
    // so a door near min-Y should have its trailer extend further toward min-Y (above in world)
    const distTop = Math.abs(ddY - mapMinY);
    const distBottom = Math.abs(ddY - mapMaxY);
    const distLeft = Math.abs(ddX - mapMinX);
    const distRight = Math.abs(ddX - mapMaxX);
    const minDist = Math.min(distTop, distBottom, distLeft, distRight);

    let placement;
    if (minDist === distTop) placement = 'above';       // near min-Y edge → trailer extends outward (above in world / top on screen)
    else if (minDist === distBottom) placement = 'below'; // near max-Y edge → trailer extends outward (below in world / bottom on screen)
    else if (minDist === distLeft) placement = 'left';
    else placement = 'right';

    const equip = loadEntry.load?.equipmentType || '';
    const is26 = equip.includes('TWENTY_SIX');
    const ratio = is26 ? 2 : 4; // length:width ratio

    // Status-based color
    const status = (loadEntry.load?.status || '').toUpperCase();
    let trailerFill = '#888'; // default grey
    if (status === 'UNLOADING_IN_PROGRESS') trailerFill = '#5cd65c';
    else if (status === 'READY_FOR_UNLOAD') trailerFill = '#f0e040';
    else if (status === 'LOADING_PAUSED') trailerFill = '#888';

    // Compute trailer dimensions and position based on placement direction
    let tW, tH, tX, tY;
    const gap = 2; // small gap between door and trailer

    if (placement === 'above' || placement === 'below') {
      // Trailer extends vertically from the dock door, width matches door width
      tW = ddW;
      tH = ddW * ratio;
      tX = ddX;
      tY = placement === 'above' ? ddY - (ddH / 2) - gap - tH / 2 : ddY + (ddH / 2) + gap + tH / 2;
    } else {
      // Trailer extends horizontally from the dock door, height matches door height
      tH = ddH;
      tW = ddH * ratio;
      tX = placement === 'left' ? ddX - (ddW / 2) - gap - tW / 2 : ddX + (ddW / 2) + gap + tW / 2;
      tY = ddY;
    }

    const vrId = loadEntry.load?.vrId || '?';
    const route = loadEntry.load?.route || '?';
    const pkgCount = loadEntry.load?.packageCount || '?';
    const trailerId = 'trailer-' + dd.name;

    const rect = new Konva.Rect({
      x: tX, y: tY, width: tW, height: tH,
      offsetX: tW / 2, offsetY: tH / 2,
      fill: trailerFill, stroke: '#333', strokeWidth: 0.5,
      opacity: 0.9, cornerRadius: 1,
      id: trailerId,
      shadowForStrokeEnabled: false, perfectDrawEnabled: false
    });

    // Store metadata on the shape for tooltip
    rect._trailerMeta = {
      dockDoor: dd.name, vrId, route, status: loadEntry.load?.status || '?',
      equipType: is26 ? '26ft' : '53ft'
    };

    rect.on('mouseenter', (e) => {
      const m = rect._trailerMeta;
      // Build package breakdown from heatMapData if available
      let pkgs = '';
      if (heatMapData && heatMapData.packageCountByVrid && heatMapData.packageCountByVrid[m.vrId] != null) {
        const total = heatMapData.packageCountByVrid[m.vrId] || 0;
        const fluid = (heatMapData.fluidCountByVrid && heatMapData.fluidCountByVrid[m.vrId]) || 0;
        const containerized = (heatMapData.containerizedCountByVrid && heatMapData.containerizedCountByVrid[m.vrId]) || 0;
        const containers = (heatMapData.containerCountByVrid && heatMapData.containerCountByVrid[m.vrId]) || 0;
        const nonCon = (heatMapData.nonConCountByVrid && heatMapData.nonConCountByVrid[m.vrId]) || 0;
        const smalls = (heatMapData.smallsCountByVrid && heatMapData.smallsCountByVrid[m.vrId]) || 0;
        pkgs = `\n📦 ${total} packages`;
        pkgs += `\n   Fluid: ${fluid}`;
        pkgs += `\n   Containerized: ${containerized}`;
        if (containers > 0) pkgs += `\n📥 ${containers} containers`;
        pkgs += `\n✅ Smalls: ${smalls}`;
        pkgs += `\n🚫 Non-Con: ${nonCon}`;
      }
      const tip = `🚛 ${m.equipType} Trailer\nDock Door: ${m.dockDoor}\nVRID: ${m.vrId}\nRoute: ${m.route}\nStatus: ${m.status.replace(/_/g, ' ')}${pkgs}`;
      activeTooltipShape = rect;
      showTooltip(tip, e.evt.clientX, e.evt.clientY);
    });
    rect.on('mouseleave', () => {
      if (activeTooltipShape === rect) activeTooltipShape = null;
      hideTooltip();
    });
    rect.on('mousemove', (e) => {
      tooltipLastActive = Date.now();
      positionTooltip(e.evt.clientX, e.evt.clientY);
    });

    interactiveLayer.add(rect);
    inboundTrailerShapes.push(rect);
  }

  if (stage) stage.batchDraw();
}

function clearInboundTrailers() {
  for (const shape of inboundTrailerShapes) {
    shape.destroy();
  }
  inboundTrailerShapes = [];
  if (stage) stage.batchDraw();
}

function clearInboundView() {
  clearInboundTrailers();
  inboundViewData = null;
}

// ==================== HEAT MAP ====================

function showHeatMapControls() {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(startOfDay.getTime() - 24 * 60 * 60 * 1000);
  const tomorrow = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000);
  const pad = n => String(n).padStart(2, '0');
  const toLocalISO = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());

  let vridSection = '';
  if (heatMapData) {
    const vrids = heatMapData.vrids || [];
    const activeVrids = heatMapData.activeVrids || new Set(vrids);
    const statusOrder = { 'unloading in progress': 0, 'ready for unload': 1, 'load arrived': 2, 'completed': 3, 'scheduled': 4 };
    const sortedVrids = [...vrids].sort((a, b) => {
      const sa = (heatMapData.loadInfo[a]?.status || '').toLowerCase();
      const sb = (heatMapData.loadInfo[b]?.status || '').toLowerCase();
      return (statusOrder[sa] ?? 99) - (statusOrder[sb] ?? 99);
    });
    const vridCheckboxes = sortedVrids.map(v => {
      const info = heatMapData.loadInfo[v] || {};
      const pkgCount = heatMapData.packageCountByVrid[v] || 0;
      const checked = activeVrids.has(v) ? 'checked' : '';
      return `<label style="display:block; font-size:12px; margin:2px 0; cursor:pointer;">
        <input type="checkbox" class="heatmap-vrid-cb" value="${v}" ${checked}> ${v} — ${info.route || '?'} (${pkgCount} pkgs, ${info.status || '?'})
      </label>`;
    }).join('');

    // Compute stats for active VRIDs
    let totalPkgs = 0, totalFluid = 0, totalContainerized = 0, totalContainers = 0;
    let totalNonCon = 0, totalSmalls = 0, totalNoDims = 0, totalDrawn = 0, totalCuft = 0;
    for (const v of activeVrids) {
      totalPkgs += heatMapData.packageCountByVrid[v] || 0;
      totalFluid += (heatMapData.fluidCountByVrid && heatMapData.fluidCountByVrid[v]) || 0;
      totalContainerized += (heatMapData.containerizedCountByVrid && heatMapData.containerizedCountByVrid[v]) || 0;
      totalContainers += (heatMapData.containerCountByVrid && heatMapData.containerCountByVrid[v]) || 0;
      totalNonCon += (heatMapData.nonConCountByVrid && heatMapData.nonConCountByVrid[v]) || 0;
      totalSmalls += (heatMapData.smallsCountByVrid && heatMapData.smallsCountByVrid[v]) || 0;
      totalNoDims += (heatMapData.noDimsCountByVrid && heatMapData.noDimsCountByVrid[v]) || 0;
    }
    // Total drawn = packages that ended up on stacking areas (from countByLabel in applyHeatMapColors)
    if (heatMapData.countByLabel) {
      totalDrawn = Math.round(Object.values(heatMapData.countByLabel).reduce((a, b) => a + b, 0));
    }
    if (heatMapData.cuftByLabel) {
      totalCuft = Object.values(heatMapData.cuftByLabel).reduce((a, b) => a + b, 0);
    }

    const statsSection = `
      <div style="margin-top:10px; border-top:1px solid var(--border-color); padding-top:10px;">
        <span style="font-weight:bold; font-size:13px;">📊 Volume Stats</span>
        <div style="font-size:12px; margin-top:6px; line-height:1.6;">
          <div style="display:flex; justify-content:space-between;"><span>Total Packages (Tantei):</span><span style="font-weight:bold;">${totalPkgs.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; padding-left:10px; color:#aaa;"><span>Fluid:</span><span>${totalFluid.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; padding-left:10px; color:#aaa;"><span>Containerized:</span><span>${totalContainerized.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; padding-left:10px; color:#aaa;"><span>Containers:</span><span>${totalContainers.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; margin-top:4px;"><span>Drawn on Map:</span><span style="font-weight:bold;">${totalDrawn.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between;"><span>Not Drawn:</span><span style="font-weight:bold; color:#f0ad4e;">${(totalPkgs - totalDrawn).toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; margin-top:4px;"><span>Total Volume:</span><span style="font-weight:bold;">${totalCuft > 0 ? totalCuft.toFixed(1) + ' ft³' : '—'}</span></div>
          <div style="display:flex; justify-content:space-between; margin-top:4px;"><span>Smalls:</span><span style="font-weight:bold; color:#5cd65c;">${totalSmalls.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between;"><span>Non-Con:</span><span style="font-weight:bold; color:#dc3545;">${totalNonCon.toLocaleString()}</span></div>
          <div style="display:flex; justify-content:space-between; color:#888;"><span>No Dimensions:</span><span>${totalNoDims.toLocaleString()}</span></div>
        </div>
        <button id="heatmap-export-undrawn" class="button" style="width:100%; margin-top:8px; background:#f0ad4e; color:#000; font-size:12px;">📥 Export Undrawn Packages CSV</button>
      </div>
    `;

    vridSection = `
      <div style="margin-top:10px; border-top:1px solid var(--border-color); padding-top:10px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <span style="font-weight:bold; font-size:13px;">VRIDs (${vrids.length})</span>
          <span>
            <button id="heatmap-select-all" class="button" style="font-size:11px; padding:2px 6px;">All</button>
            <button id="heatmap-deselect-all" class="button" style="font-size:11px; padding:2px 6px;">None</button>
          </span>
        </div>
        <div style="max-height:300px; overflow-y:auto; border:1px solid var(--border-color); border-radius:4px; padding:4px;">
          ${vridCheckboxes}
        </div>
      </div>
      ${statsSection}
      <button id="heatmap-refresh-inbound" class="button" style="width:100%; margin-top:8px; background:#28a745; color:#fff;">🔄 Refresh Inbound Positions</button>
      <button id="heatmap-clear" class="button" style="width:100%; margin-top:6px; background:#dc3545; color:#fff;">✕ Clear Heat Map</button>
    `;
  }

  sidebarContainer.innerHTML = `
    <h2>🔥 Heat Map</h2>
    <div class="tool-section">
      <div style="margin-bottom:6px;">
        <label style="font-size:11px; color:#999;">API Date Range (broad fetch window):</label>
        <div style="display:flex; gap:6px; margin-top:2px;">
          <div style="flex:1;">
            <label style="font-size:11px;">Start:</label>
            <input type="datetime-local" id="heatmap-start" value="${toLocalISO(yesterday)}" class="api-input" style="font-size:12px; width:100%;">
          </div>
          <div style="flex:1;">
            <label style="font-size:11px;">End:</label>
            <input type="datetime-local" id="heatmap-end" value="${toLocalISO(tomorrow)}" class="api-input" style="font-size:12px; width:100%;">
          </div>
        </div>
      </div>
      <div style="margin-bottom:8px; border-top:1px solid var(--border-color); padding-top:6px;">
        <label style="font-size:11px; color:#999;">Scheduled Arrival Filter:</label>
        <div style="display:flex; gap:6px; margin-top:2px;">
          <div style="flex:1;">
            <label style="font-size:11px;">From:</label>
            <input type="datetime-local" id="heatmap-arrival-start" value="${toLocalISO(startOfDay)}" class="api-input" style="font-size:12px; width:100%;">
          </div>
          <div style="flex:1;">
            <label style="font-size:11px;">To:</label>
            <input type="datetime-local" id="heatmap-arrival-end" value="${toLocalISO(tomorrow)}" class="api-input" style="font-size:12px; width:100%;">
          </div>
        </div>
      </div>
      <button id="heatmap-run" class="button" style="width:100%; background:#555; color:#fff; font-weight:bold;">🚀 Run Heat Map Pipeline</button>
      <div id="heatmap-progress-wrap" style="display:none; margin-top:8px;">
        <div style="background:#333; border-radius:4px; overflow:hidden; height:18px; position:relative;">
          <div id="heatmap-progress-bar" style="background:linear-gradient(90deg,#28a745,#ffc107,#dc3545); height:100%; width:0%; transition:width 0.3s ease; border-radius:4px;"></div>
          <span id="heatmap-progress-text" style="position:absolute; top:0; left:0; right:0; text-align:center; font-size:11px; line-height:18px; color:#fff; font-weight:bold;"></span>
        </div>
      </div>
      <div id="heatmap-status" style="margin-top:8px; font-size:12px; color:var(--text-secondary);"></div>
      ${vridSection}
    </div>
  `;
}

async function runHeatMapPipeline() {
  const statusDiv = document.getElementById('heatmap-status');
  const status = msg => { if (statusDiv) statusDiv.innerHTML = `<p style="color:#666; margin:4px 0;">${msg}</p>`; };
  const nodeId = selectedNodeId;

  // Progress bar helpers
  const progressWrap = document.getElementById('heatmap-progress-wrap');
  const progressBar = document.getElementById('heatmap-progress-bar');
  const progressText = document.getElementById('heatmap-progress-text');
  function setProgress(pct, label) {
    if (progressWrap) progressWrap.style.display = 'block';
    if (progressBar) progressBar.style.width = Math.min(pct, 100) + '%';
    if (progressText) progressText.textContent = label || Math.round(pct) + '%';
  }

  try {
    // Step 1: Inbound Dock View
    setProgress(1, 'Step 1/4 — Dock View...');
    status('Step 1/4: Fetching inbound dock view...');
    const startInput = document.getElementById('heatmap-start')?.value;
    const endInput = document.getElementById('heatmap-end')?.value;
    const startDate = new Date(startInput).getTime();
    const endDate = new Date(endInput).getTime();

    const ibBody = [
      'entity=getInboundDockView',
      `nodeId=${encodeURIComponent(nodeId)}`,
      `startDate=${startDate}`,
      `endDate=${endDate}`,
      `loadCategories=${encodeURIComponent('inboundScheduled,inboundArrived,inboundCompleted')}`,
      `shippingPurposeType=${encodeURIComponent('TRANSSHIPMENT,NON-TRANSSHIPMENT,SHIP_WITH_AMAZON')}`
    ].join('&');

    const ibResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'include', body: ibBody
    });
    if (!ibResp.ok) throw new Error(`Inbound HTTP ${ibResp.status}`);
    const allLoads = (await ibResp.json())?.ret?.aaData || [];
    if (allLoads.length === 0) { status('⚠️ No inbound loads found.'); setProgress(0, ''); if (progressWrap) progressWrap.style.display = 'none'; return; }
    console.log(`📦 Heat map step 1: ${allLoads.length} loads from API`);

    // Filter by scheduledArrivalTime
    const arrStartInput = document.getElementById('heatmap-arrival-start')?.value;
    const arrEndInput = document.getElementById('heatmap-arrival-end')?.value;
    const arrStart = arrStartInput ? new Date(arrStartInput).getTime() : null;
    const arrEnd = arrEndInput ? new Date(arrEndInput).getTime() : null;

    const loads = allLoads.filter(entry => {
      const sat = entry.load?.scheduledArrivalTime;
      if (!sat) return true; // keep loads with no scheduled arrival (already arrived, etc.)
      const satMs = new Date(sat).getTime();
      if (isNaN(satMs)) return true;
      if (arrStart && satMs < arrStart) return false;
      if (arrEnd && satMs > arrEnd) return false;
      return true;
    });
    console.log(`📦 Heat map step 1: ${loads.length} loads after scheduledArrivalTime filter (${allLoads.length} total)`);
    if (loads.length === 0) { status('⚠️ No loads match the scheduled arrival filter.'); setProgress(0, ''); if (progressWrap) progressWrap.style.display = 'none'; return; }

    // Integrate inbound view: draw trailers on the map for filtered loads
    inboundViewData = { loads };
    clearInboundTrailers();
    drawInboundTrailers();
    setProgress(5, 'Step 2/4 — Containers...');

    // Step 2: Container hierarchy per load (concurrent, max 10 at a time)
    const packagesByVrid = {};
    const loadInfo = {};
    const packageCountByVrid = {};
    let completed = 0;

    // Pre-populate loadInfo for all loads
    const validLoads = [];
    for (const entry of loads) {
      const planId = entry.load?.planId;
      const vrId = entry.load?.vrId || '';
      if (!planId || !vrId) continue;
      loadInfo[vrId] = {
        route: entry.load?.route || '', status: entry.load?.status || '',
        carrier: entry.load?.carrier || '', dockDoor: (entry.resource || []).map(r => r.label).join('; '),
        planId
      };
      validLoads.push({ vrId, planId });
    }

    async function fetchContainerHierarchy(vrId, planId) {
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const cResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'include',
            body: `entity=getInboundLoadContainerHierarchy&inboundLoadId=${encodeURIComponent(planId)}&nodeId=${encodeURIComponent(nodeId)}&containerStatus=InTrailer`
          });
          if (cResp.status === 429) { await new Promise(r => setTimeout(r, 2000 * (attempt + 1))); continue; }
          if (!cResp.ok) return;
          const children = (await cResp.json())?.ret?.aaData?.[0]?.hierarchy?.childContainers || [];
          if (children.length > 0) {
            packagesByVrid[vrId] = children.map(child => {
              const c = child.container || {};
              const props = c.properties || {};
              let length = 0, width = 0, height = 0, weight = 0;
              try { const b = JSON.parse(props.BOXED_SIZE || '{}'); length = parseFloat(b.length?.value) || 0; width = parseFloat(b.width?.value) || 0; height = parseFloat(b.height?.value) || 0; } catch(e){}
              try { const w = JSON.parse(props.WEIGHT || '{}'); weight = parseFloat(w.weight?.value) || 0; } catch(e){}
              return { label: c.label || '', containerType: c.containerType || '', containerId: c.containerId || '', length, width, height, weight };
            });
          }
          return;
        } catch (err) { if (attempt < 2) await new Promise(r => setTimeout(r, 1000)); }
      }
    }

    // Run with concurrency limit of 10
    const CONCURRENCY = 10;
    for (let i = 0; i < validLoads.length; i += CONCURRENCY) {
      const chunk = validLoads.slice(i, i + CONCURRENCY);
      const pct = 5 + Math.round((Math.min(i + CONCURRENCY, validLoads.length) / validLoads.length) * 35);
      setProgress(pct, `Step 2/4 — ${Math.min(i + CONCURRENCY, validLoads.length)}/${validLoads.length}`);
      status(`Step 2/4: Containers ${Math.min(i + CONCURRENCY, validLoads.length)}/${validLoads.length}...`);
      await Promise.all(chunk.map(({ vrId, planId }) => fetchContainerHierarchy(vrId, planId)));
    }

    const NESTED_PREFIXES = ['CART_', 'PALLET_', 'GAYLORD_', 'BAG_'];
    const isNested = label => NESTED_PREFIXES.some(p => label.toUpperCase().startsWith(p));
    const vridsWithPkgs = Object.keys(packagesByVrid);
    console.log(`📋 Heat map step 2: ${vridsWithPkgs.length} VRIDs with children`);

    if (vridsWithPkgs.length === 0) { status('⚠️ No VRIDs with packages.'); return; }

    // Collect nested container labels
    const nestedLabels = [];
    const nestedToVrid = {};
    // Build dimension lookup: packageLabel -> { length, width, height, weight }
    const dimsByLabel = {};
    for (const vrId of vridsWithPkgs) {
      for (const pkg of packagesByVrid[vrId]) {
        if (isNested(pkg.label)) { nestedLabels.push(pkg.label); nestedToVrid[pkg.label] = vrId; }
        if (pkg.length > 0 || pkg.width > 0 || pkg.height > 0) {
          dimsByLabel[pkg.label] = { length: pkg.length, width: pkg.width, height: pkg.height, weight: pkg.weight };
        }
      }
    }

    // Step 3: Tantei
    setProgress(40, 'Step 3/4 — Tantei CSRF...');
    status('Step 3/4: Fetching Tantei CSRF...');
    const csrfResult = await new Promise(resolve => {
      chrome.runtime.sendMessage({ type: 'fetchTanteiCSRF', nodeId }, r => {
        if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
        else if (!r) resolve({ success: false, error: 'No response' });
        else resolve(r);
      });
    });
    if (!csrfResult.success) throw new Error('Tantei CSRF failed: ' + csrfResult.error);
    const csrfToken = csrfResult.token;

    const gqlQuery = `query ($queryInput: [SearchTermInput!]!, $startIndex: String) {
  searchEntities(searchTerms: $queryInput) {
    searchTerm { nodeId searchId }
    contents(pageSize: 60, startIndex: $startIndex, forwardNavigate: true) {
      contents { containerId containerLabel containerType stackingFilter }
      endToken
    }
  }
}`;

    const BATCH = 5, BDELAY = 100, PDELAY = 100, RDELAY = 2000, MAXR = 5;
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    async function gql(variables) {
      for (let a = 0; a <= MAXR; a++) {
        const res = await new Promise(resolve => {
          chrome.runtime.sendMessage({ type: 'tanteiGraphQL', csrfToken, query: gqlQuery, variables, nodeId }, r => {
            if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
            else if (!r) resolve({ success: false, error: 'No response' });
            else resolve(r);
          });
        });
        if (!res.success && res.error?.includes('429') && a < MAXR) { await sleep(RDELAY * (a + 1)); continue; }
        return res;
      }
    }

    // 3a: Tantei for VRIDs — build filter→count per VRID
    // packagesByFilter: { vrId -> { stackingFilter -> count } }
    const packagesByFilterPerVrid = {};
    const cubicFeetByFilterPerVrid = {};
    const nonConByFilterPerVrid = {};
    const fluidCountByVrid = {};
    let tanteiTotal = 0;

    // Non-Con check helper using dimension lookup
    function isNonConDims(dims) {
      if (!dims) return false;
      if (dims.weight > 49) return true;
      const sorted = [dims.length, dims.width, dims.height].filter(d => d > 0).sort((a, b) => a - b);
      if (sorted.length === 0) return false;
      const largest = sorted[sorted.length - 1];
      const smallest = sorted[0];
      if (largest > 46) return true;
      if (largest > 36 && smallest > 24) return true;
      return false;
    }

    for (let i = 0; i < vridsWithPkgs.length; i += BATCH) {
      const batch = vridsWithPkgs.slice(i, i + BATCH);
      if (i > 0) await sleep(BDELAY);
      const pct = 42 + Math.round((Math.min(i + BATCH, vridsWithPkgs.length) / vridsWithPkgs.length) * 35);
      setProgress(pct, `Step 3/4 — VRIDs ${Math.floor(i/BATCH)+1}/${Math.ceil(vridsWithPkgs.length/BATCH)}`);
      status(`Step 3/4: Tantei VRIDs ${Math.floor(i/BATCH)+1}/${Math.ceil(vridsWithPkgs.length/BATCH)}...`);

      let startIndex = '0', hasMore = true;
      while (hasMore) {
        const result = await gql({ queryInput: batch.map(v => ({ nodeId, searchId: v, searchIdType: 'UNKNOWN' })), startIndex });
        if (!result.success) throw new Error('Tantei failed: ' + result.error);
        let pageMore = false;
        (result.data?.data?.searchEntities || []).forEach(entity => {
          const sid = entity.searchTerm?.searchId || '';
          const contents = entity.contents?.contents || [];
          const endToken = entity.contents?.endToken || null;
          if (!packagesByFilterPerVrid[sid]) packagesByFilterPerVrid[sid] = {};
          if (!cubicFeetByFilterPerVrid[sid]) cubicFeetByFilterPerVrid[sid] = {};
          if (!nonConByFilterPerVrid[sid]) nonConByFilterPerVrid[sid] = {};
          if (!fluidCountByVrid[sid]) fluidCountByVrid[sid] = 0;
          contents.forEach(item => {
            const sf = (item.stackingFilter || '').replace(/-C-/g, '-');
            if (sf) {
              packagesByFilterPerVrid[sid][sf] = (packagesByFilterPerVrid[sid][sf] || 0) + 1;
              const dims = dimsByLabel[item.containerLabel];
              if (dims && dims.length > 0 && dims.width > 0 && dims.height > 0) {
                const cuft = (dims.length * dims.width * dims.height) / 1728;
                cubicFeetByFilterPerVrid[sid][sf] = (cubicFeetByFilterPerVrid[sid][sf] || 0) + cuft;
              }
              if (isNonConDims(dims)) {
                nonConByFilterPerVrid[sid][sf] = (nonConByFilterPerVrid[sid][sf] || 0) + 1;
              }
            }
            fluidCountByVrid[sid]++;
          });
          tanteiTotal += contents.length;
          if (endToken && contents.length > 0) { pageMore = true; startIndex = endToken; }
        });
        hasMore = pageMore;
        if (hasMore) await sleep(PDELAY);
      }
    }

    // 3b: Tantei for nested containers (recursive — handles containers within containers)
    const containerizedCountByVrid = {};
    const containerCountByVrid = {};
    const processedNestedLabels = new Set(); // avoid re-processing the same container
    let pendingNestedLabels = [...nestedLabels];
    let nestedDepth = 0;

    while (pendingNestedLabels.length > 0) {
      nestedDepth++;
      const currentBatch = pendingNestedLabels;
      pendingNestedLabels = []; // will be filled with any newly discovered nested containers
      console.log(`📦 Nested depth ${nestedDepth}: ${currentBatch.length} containers to search`);

      for (let i = 0; i < currentBatch.length; i += BATCH) {
        const batch = currentBatch.slice(i, i + BATCH);
        if (i > 0) await sleep(BDELAY);
        const pct = 78 + Math.round((Math.min(i + BATCH, currentBatch.length) / currentBatch.length) * 17);
        setProgress(pct, `Step 3/4 — Nested L${nestedDepth} ${Math.floor(i/BATCH)+1}/${Math.ceil(currentBatch.length/BATCH)}`);
        status(`Step 3/4: Tantei nested L${nestedDepth} ${Math.floor(i/BATCH)+1}/${Math.ceil(currentBatch.length/BATCH)}...`);

        let startIndex = '0', hasMore = true;
        while (hasMore) {
          const result = await gql({ queryInput: batch.map(l => ({ nodeId, searchId: l, searchIdType: 'UNKNOWN' })), startIndex });
          if (!result.success) throw new Error('Tantei nested failed: ' + result.error);
          let pageMore = false;
          (result.data?.data?.searchEntities || []).forEach(entity => {
            const parentLabel = entity.searchTerm?.searchId || '';
            const vrId = nestedToVrid[parentLabel] || '';
            const contents = entity.contents?.contents || [];
            const endToken = entity.contents?.endToken || null;
            if (vrId && !packagesByFilterPerVrid[vrId]) packagesByFilterPerVrid[vrId] = {};
            if (vrId && !cubicFeetByFilterPerVrid[vrId]) cubicFeetByFilterPerVrid[vrId] = {};
            if (vrId && !nonConByFilterPerVrid[vrId]) nonConByFilterPerVrid[vrId] = {};
            if (vrId && !containerizedCountByVrid[vrId]) containerizedCountByVrid[vrId] = 0;
            contents.forEach(item => {
              const itemLabel = item.containerLabel || '';
              // Check if this item is itself a nested container
              if (isNested(itemLabel) && !processedNestedLabels.has(itemLabel)) {
                processedNestedLabels.add(itemLabel);
                nestedToVrid[itemLabel] = vrId; // track parent VRID
                pendingNestedLabels.push(itemLabel);
                // Count it as a container for the VRID
                containerCountByVrid[vrId] = (containerCountByVrid[vrId] || 0) + 1;
              } else {
                // It's a leaf package — count it
                const sf = (item.stackingFilter || '').replace(/-C-/g, '-');
                if (sf && vrId) {
                  packagesByFilterPerVrid[vrId][sf] = (packagesByFilterPerVrid[vrId][sf] || 0) + 1;
                  const dims = dimsByLabel[itemLabel];
                  if (dims && dims.length > 0 && dims.width > 0 && dims.height > 0) {
                    const cuft = (dims.length * dims.width * dims.height) / 1728;
                    cubicFeetByFilterPerVrid[vrId][sf] = (cubicFeetByFilterPerVrid[vrId][sf] || 0) + cuft;
                  }
                  if (isNonConDims(dims)) {
                    nonConByFilterPerVrid[vrId][sf] = (nonConByFilterPerVrid[vrId][sf] || 0) + 1;
                  }
                }
                if (vrId) containerizedCountByVrid[vrId]++;
                tanteiTotal++;
              }
            });
            if (endToken && contents.length > 0) { pageMore = true; startIndex = endToken; }
          });
          hasMore = pageMore;
          if (hasMore) await sleep(PDELAY);
        }
      }

      // Safety: prevent infinite loops from circular references
      if (nestedDepth >= 5) {
        console.warn(`⚠️ Nested container depth limit (${nestedDepth}) reached, stopping recursion`);
        break;
      }
    }

    console.log(`🔍 Heat map step 3: ${tanteiTotal} Tantei records (nested depth reached: ${nestedDepth})`);

    // Compute per-VRID package counts
    for (const vrId of vridsWithPkgs) {
      const filters = packagesByFilterPerVrid[vrId] || {};
      packageCountByVrid[vrId] = Object.values(filters).reduce((a, b) => a + b, 0);
    }

    // Compute container count per VRID (number of nested containers like CART_, PALLET_, etc.)
    // Add top-level containers from step 2 (already in nestedToVrid from initial collection)
    for (const [label, vrId] of Object.entries(nestedToVrid)) {
      containerCountByVrid[vrId] = (containerCountByVrid[vrId] || 0) + 1;
    }

    // Classify packages: Non-Con vs Smalls
    // Non-Con: weight > 49 lbs, OR largest dim > 36" AND smallest dim > 24", OR largest dim > 46"
    function isNonCon(pkg) {
      if (pkg.weight > 49) return true;
      const dims = [pkg.length, pkg.width, pkg.height].filter(d => d > 0).sort((a, b) => a - b);
      if (dims.length === 0) return false;
      const largest = dims[dims.length - 1];
      const smallest = dims[0];
      if (largest > 46) return true;
      if (largest > 36 && smallest > 24) return true;
      return false;
    }

    const nonConCountByVrid = {};
    const smallsCountByVrid = {};
    const noDimsCountByVrid = {};
    for (const vrId of vridsWithPkgs) {
      let nc = 0, sm = 0, nd = 0;
      for (const pkg of (packagesByVrid[vrId] || [])) {
        if (isNested(pkg.label)) continue; // skip containers themselves
        const hasDims = pkg.length > 0 || pkg.width > 0 || pkg.height > 0 || pkg.weight > 0;
        if (!hasDims) { nd++; continue; }
        if (isNonCon(pkg)) nc++;
        else sm++;
      }
      nonConCountByVrid[vrId] = nc;
      smallsCountByVrid[vrId] = sm;
      noDimsCountByVrid[vrId] = nd;
    }

    // Step 4: Store and apply
    setProgress(96, 'Step 4/4 — Applying...');
    heatMapData = {
      packagesByFilterPerVrid,
      cubicFeetByFilterPerVrid,
      nonConByFilterPerVrid,
      loadInfo,
      vrids: vridsWithPkgs,
      activeVrids: new Set(vridsWithPkgs),
      packageCountByVrid,
      fluidCountByVrid,
      containerizedCountByVrid,
      containerCountByVrid,
      nonConCountByVrid,
      smallsCountByVrid,
      noDimsCountByVrid
    };

    applyHeatMapColors();
    showHeatMapControls(); // re-render sidebar with VRID checkboxes
    status(`✅ Heat map applied: ${tanteiTotal} packages across ${vridsWithPkgs.length} VRIDs`);

    // Cache heat map data to chrome.storage.local
    try {
      // Only cache essential pipeline data (computed fields like countByLabel are rebuilt by applyHeatMapColors)
      const cacheData = {
        packagesByFilterPerVrid: heatMapData.packagesByFilterPerVrid,
        cubicFeetByFilterPerVrid: heatMapData.cubicFeetByFilterPerVrid,
        nonConByFilterPerVrid: heatMapData.nonConByFilterPerVrid,
        loadInfo: heatMapData.loadInfo,
        vrids: heatMapData.vrids,
        activeVrids: [...heatMapData.activeVrids],
        packageCountByVrid: heatMapData.packageCountByVrid,
        fluidCountByVrid: heatMapData.fluidCountByVrid,
        containerizedCountByVrid: heatMapData.containerizedCountByVrid,
        containerCountByVrid: heatMapData.containerCountByVrid,
        nonConCountByVrid: heatMapData.nonConCountByVrid,
        smallsCountByVrid: heatMapData.smallsCountByVrid,
        noDimsCountByVrid: heatMapData.noDimsCountByVrid,
        timestamp: Date.now()
      };
      const sizeKB = (JSON.stringify(cacheData).length / 1024).toFixed(1);
      console.log(`💾 Heat map cache size: ${sizeKB} KB`);
      await chrome.storage.local.set({ [`heatMapCache_${nodeId}`]: cacheData });
      console.log('💾 Heat map data cached to chrome.storage.local');
    } catch (cacheErr) {
      console.warn('⚠️ Failed to cache heat map data:', cacheErr.message);
    }
    // Progress bar: show 100% briefly then hide
    const pw = document.getElementById('heatmap-progress-wrap');
    const pb = document.getElementById('heatmap-progress-bar');
    const pt = document.getElementById('heatmap-progress-text');
    if (pw && pb && pt) { pb.style.width = '100%'; pt.textContent = '✅ Done'; setTimeout(() => pw.style.display = 'none', 2000); }
    console.log('✅ Heat map pipeline complete');

  } catch (error) {
    console.error('❌ Heat map pipeline failed:', error);
    if (document.getElementById('heatmap-status')) {
      document.getElementById('heatmap-status').innerHTML = `<p style="color:red;">❌ ${error.message}</p>`;
    }
    const pw = document.getElementById('heatmap-progress-wrap');
    if (pw) pw.style.display = 'none';
  }
}

function applyHeatMapColors() {
  if (!heatMapData) return;

  // Build reverse lookup: stackingFilter -> [stacking area labels]
  const filterToLabels = {};
  for (const [label, filters] of Object.entries(stackingFilterMap)) {
    for (const f of filters) {
      if (!filterToLabels[f]) filterToLabels[f] = [];
      if (!filterToLabels[f].includes(label)) filterToLabels[f].push(label);
    }
  }

  // Build set of D2C stacking area labels
  const d2cLabels = new Set();
  for (const [label, info] of Object.entries(chuteConnectionMap)) {
    if (info.containerizeOption === 'directToContainer') d2cLabels.add(label);
  }

  // Aggregate active VRID package counts per stacking filter
  const activeFilters = {};
  const activeCuft = {};
  const activeNonCon = {};
  for (const vrId of heatMapData.activeVrids) {
    const filters = heatMapData.packagesByFilterPerVrid[vrId] || {};
    for (const [sf, count] of Object.entries(filters)) {
      activeFilters[sf] = (activeFilters[sf] || 0) + count;
    }
    const cuftFilters = (heatMapData.cubicFeetByFilterPerVrid && heatMapData.cubicFeetByFilterPerVrid[vrId]) || {};
    for (const [sf, cuft] of Object.entries(cuftFilters)) {
      activeCuft[sf] = (activeCuft[sf] || 0) + cuft;
    }
    const ncFilters = (heatMapData.nonConByFilterPerVrid && heatMapData.nonConByFilterPerVrid[vrId]) || {};
    for (const [sf, count] of Object.entries(ncFilters)) {
      activeNonCon[sf] = (activeNonCon[sf] || 0) + count;
    }
  }

  // Helper: check if a stacking area label is a Non-Con location
  // NC can appear as a segment separated by dashes, e.g. "AREA-NC-1" or "AREA-NC"
  const isNcLabel = label => /(^|-)NC(-|$)/i.test(label);

  // Distribute packages to stacking area labels
  // For each filter, find matching stacking areas and divide evenly
  // NC stacking areas only receive non-con packages; non-NC areas receive the rest
  // Strip -SMALL/-LARGE for non-D2C matching, keep -SMALL for D2C matching
  // CYCLE1-PARENT: if filter contains "CYCLE1" and doesn't end in "-SMALL", also match -PARENT suffix
  const countByLabel = {};
  const cuftByLabel = {};
  for (const [sf, totalCount] of Object.entries(activeFilters)) {
    const hasSuffix = sf.endsWith('-SMALL') || sf.endsWith('-LARGE');
    const baseSf = hasSuffix ? sf.replace(/-(SMALL|LARGE)$/, '') : sf;

    // Try exact match first (works for D2C -SMALL filters and base filters)
    let labels = filterToLabels[sf] || [];

    if (hasSuffix) {
      // For -SMALL: also check D2C chutes that have the -SMALL filter
      // For -LARGE/-SMALL: match base filter on non-D2C chutes
      const baseLabels = (filterToLabels[baseSf] || []).filter(l => !d2cLabels.has(l));
      const d2cExact = labels.filter(l => d2cLabels.has(l));
      // Non-D2C chutes match on base filter; D2C chutes match on exact -SMALL filter
      labels = [...baseLabels, ...d2cExact];
    }

    // CYCLE1-PARENT: if filter includes "CYCLE1" and doesn't end in "-SMALL",
    // also search for stacking locations ending with that filter + "-PARENT"
    const effectiveSf = hasSuffix ? baseSf : sf;
    if (effectiveSf.includes('CYCLE1') && !sf.endsWith('-SMALL')) {
      const parentLabels = filterToLabels[effectiveSf + '-PARENT'] || [];
      for (const pl of parentLabels) {
        if (!labels.includes(pl)) labels.push(pl);
      }
    }

    if (labels.length === 0) continue;

    // Split labels into NC and non-NC
    const ncLabels = labels.filter(l => isNcLabel(l));
    const regularLabels = labels.filter(l => !isNcLabel(l));
    const ncCount = activeNonCon[sf] || 0;
    const regularCount = totalCount - ncCount;
    const cuftTotal = activeCuft[sf] || 0;

    // Distribute non-con packages to NC labels (if any NC labels exist)
    if (ncLabels.length > 0 && ncCount > 0) {
      const perNc = ncCount / ncLabels.length;
      const cuftPerNc = cuftTotal > 0 ? (cuftTotal * (ncCount / totalCount)) / ncLabels.length : 0;
      for (const label of ncLabels) {
        countByLabel[label] = (countByLabel[label] || 0) + perNc;
        if (cuftPerNc > 0) cuftByLabel[label] = (cuftByLabel[label] || 0) + cuftPerNc;
      }
    }

    // Distribute regular packages to non-NC labels
    if (regularLabels.length > 0 && regularCount > 0) {
      const perReg = regularCount / regularLabels.length;
      const cuftPerReg = cuftTotal > 0 ? (cuftTotal * (regularCount / totalCount)) / regularLabels.length : 0;
      for (const label of regularLabels) {
        countByLabel[label] = (countByLabel[label] || 0) + perReg;
        if (cuftPerReg > 0) cuftByLabel[label] = (cuftByLabel[label] || 0) + cuftPerReg;
      }
    }

    // Fallback: if no NC labels exist, non-con goes to regular labels; if no regular labels, regular goes to NC
    if (ncLabels.length === 0 && ncCount > 0 && regularLabels.length > 0) {
      const perLabel = ncCount / regularLabels.length;
      const cuftPer = cuftTotal > 0 ? (cuftTotal * (ncCount / totalCount)) / regularLabels.length : 0;
      for (const label of regularLabels) {
        countByLabel[label] = (countByLabel[label] || 0) + perLabel;
        if (cuftPer > 0) cuftByLabel[label] = (cuftByLabel[label] || 0) + cuftPer;
      }
    }
    if (regularLabels.length === 0 && regularCount > 0 && ncLabels.length > 0) {
      const perLabel = regularCount / ncLabels.length;
      const cuftPer = cuftTotal > 0 ? (cuftTotal * (regularCount / totalCount)) / ncLabels.length : 0;
      for (const label of ncLabels) {
        countByLabel[label] = (countByLabel[label] || 0) + perLabel;
        if (cuftPer > 0) cuftByLabel[label] = (cuftByLabel[label] || 0) + cuftPer;
      }
    }
  }

  // Group stacking areas by waterspider zone and compute per-zone max
  // D2C stacking areas get their own separate range ('__D2C__')
  const D2C_ZONE = '__D2C__';
  const zoneMaxes = {};
  const labelToZone = {};
  for (const [label, info] of Object.entries(chuteConnectionMap)) {
    const zone = d2cLabels.has(label) ? D2C_ZONE : (info.waterspiderZone || 'UNKNOWN');
    labelToZone[label] = zone;
    const count = countByLabel[label] || 0;
    if (!zoneMaxes[zone] || count > zoneMaxes[zone]) zoneMaxes[zone] = count;
  }

  // Color function: green (0) -> yellow (0.5) -> red (1)
  function heatColor(ratio) {
    const r = ratio < 0.5 ? Math.round(255 * (ratio * 2)) : 255;
    const g = ratio < 0.5 ? 255 : Math.round(255 * (1 - (ratio - 0.5) * 2));
    return `rgb(${r},${g},0)`;
  }

  // Store package counts for tooltip enrichment
  heatMapData.countByLabel = countByLabel;
  heatMapData.cuftByLabel = cuftByLabel;

  // Apply colors to shapes
  const stackingAreas = allMapEntities.filter(e => e.type === 'stackingArea');
  for (const entity of stackingAreas) {
    const shape = interactiveLayer.findOne('#' + entity.id);
    if (!shape) continue;

    // Save original color
    if (!heatMapOriginalColors[entity.id]) {
      heatMapOriginalColors[entity.id] = shape.fill();
    }

    const count = countByLabel[entity.name] || 0;
    const zone = labelToZone[entity.name] || 'UNKNOWN';
    const zoneMax = zoneMaxes[zone] || 1;

    const hasFilter = stackingFilterMap[entity.name] && stackingFilterMap[entity.name].length > 0;
    if (count > 0) {
      const ratio = Math.min(count / zoneMax, 1);
      shape.fill(heatColor(ratio));
      shape.opacity(0.85);
    } else if (!hasFilter) {
      // No stacking filter assigned — dark grey to distinguish from zero-package areas
      shape.fill('#3a3a3a');
      shape.opacity(0.5);
    } else {
      shape.fill('#ddd');
      shape.opacity(0.4);
    }
  }

  // --- Draw package count labels on stacking areas ---
  // Remove any previous heat map count labels
  (textLayer.find('.heatmap-count-label') || []).forEach(l => l.destroy());

  for (const entity of stackingAreas) {
    const count = countByLabel[entity.name] || 0;
    if (count <= 0) continue;
    const shape = interactiveLayer.findOne('#' + entity.id);
    if (!shape) continue;

    const width = Math.abs(shape.width() * (shape.scaleX ? shape.scaleX() : 1));
    const height = Math.abs(shape.height() * (shape.scaleY ? shape.scaleY() : 1));

    let fontSize = Math.min(width * 0.6, height * 0.6, 8);
    const countText = new Konva.Text({
      text: String(Math.round(count)),
      fontSize: fontSize,
      fill: '#000',
      fontStyle: 'bold',
      name: 'heatmap-count-label',
      listening: false
    });

    // Shrink to fit
    while (countText.width() > width * 0.9 && fontSize > 1) {
      fontSize -= 0.5;
      countText.fontSize(fontSize);
    }

    // Always upright: just center on the shape and flip Y to counteract scaleY(-1)
    countText.x(shape.x());
    countText.y(shape.y());
    countText.scaleY(-1);
    countText.offsetX(countText.width() / 2);
    countText.offsetY(countText.height() / 2);

    textLayer.add(countText);
  }

  // --- Chute coloring (per waterspider zone range; D2C chutes use D2C range) ---
  const countByChute = {};
  const chuteToZone = {};
  const chuteBreakdown = {}; // chuteName -> [{ label, count, cuft }]
  const chutes = allMapEntities.filter(e => e.type === 'chute');
  for (const entity of chutes) {
    const fullChuteId = chuteLabelToIdMap[entity.name];
    if (!fullChuteId || !chuteToStackingMap[fullChuteId]) continue;
    const prefixes = chuteToStackingMap[fullChuteId];
    // Expand prefixes to actual stacking area names and sum their counts
    let total = 0;
    let totalCuft = 0;
    let zone = 'UNKNOWN';
    let allD2C = true;
    const breakdown = [];
    for (const prefix of prefixes) {
      for (const [label, count] of Object.entries(countByLabel)) {
        if (label.startsWith(prefix)) {
          total += count;
          const cuft = cuftByLabel[label] || 0;
          totalCuft += cuft;
          breakdown.push({ label, count, cuft });
        }
      }
      // Check if connected stacking areas are D2C
      for (const [label, info] of Object.entries(chuteConnectionMap)) {
        if (label.startsWith(prefix)) {
          if (info.containerizeOption !== 'directToContainer') allD2C = false;
          if (zone === 'UNKNOWN' && info.waterspiderZone) zone = info.waterspiderZone;
        }
      }
    }
    // D2C chutes use the D2C range
    if (allD2C) zone = D2C_ZONE;
    countByChute[entity.name] = total;
    chuteToZone[entity.name] = zone;
    chuteBreakdown[entity.name] = breakdown.sort((a, b) => b.count - a.count);
    // Include chute totals in zone maxes so they share the same scale
    if (!zoneMaxes[zone] || total > zoneMaxes[zone]) zoneMaxes[zone] = total;
  }
  heatMapData.countByChute = countByChute;
  heatMapData.chuteBreakdown = chuteBreakdown;

  for (const entity of chutes) {
    const shape = interactiveLayer.findOne('#' + entity.id);
    if (!shape) continue;

    // Save original color (cyan)
    if (!heatMapOriginalColors[entity.id]) {
      heatMapOriginalColors[entity.id] = shape.fill();
    }

    const count = countByChute[entity.name] || 0;
    const zone = chuteToZone[entity.name] || 'UNKNOWN';
    const zoneMax = zoneMaxes[zone] || 1;
    if (count > 0) {
      const ratio = Math.min(count / zoneMax, 1);
      shape.fill(heatColor(ratio));
      shape.opacity(0.9);
    } else {
      shape.fill('#ddd');
      shape.opacity(0.4);
    }
  }

  // --- Zone glow under stacking areas ---
  // Remove previous glow shapes
  (backgroundLayer.find('.zone-glow') || []).forEach(g => g.destroy());

  // Collect all unique zones for settings discovery
  const discoveredZones = new Set();
  const NC_ZONE = '__NC__';

  for (const entity of stackingAreas) {
    const shape = interactiveLayer.findOne('#' + entity.id);
    if (!shape) continue;

    // Determine zone: NC label overrides waterspider zone
    const isNc = /(^|-)NC(-|$)/i.test(entity.name);
    let zone;
    if (isNc) {
      zone = NC_ZONE;
    } else {
      const connInfo = chuteConnectionMap[entity.name];
      zone = connInfo?.waterspiderZone || null;
    }
    if (!zone) continue;
    discoveredZones.add(zone);

    const color = zoneGlowColors[zone];
    if (!color) continue;

    const w = Math.abs(shape.width() * (shape.scaleX ? shape.scaleX() : 1));
    const h = Math.abs(shape.height() * (shape.scaleY ? shape.scaleY() : 1));
    const pad = Math.max(w, h) * 0.15;

    const glow = new Konva.Rect({
      x: shape.x(),
      y: shape.y(),
      width: w + pad * 2,
      height: h + pad * 2,
      offsetX: (w + pad * 2) / 2,
      offsetY: (h + pad * 2) / 2,
      fill: color,
      opacity: 0.18,
      cornerRadius: 2,
      name: 'zone-glow',
      listening: false,
      perfectDrawEnabled: false
    });
    backgroundLayer.add(glow);
  }

  // Store discovered zones for settings UI
  heatMapData.discoveredZones = [...discoveredZones].sort((a, b) => {
    if (a === NC_ZONE) return -1;
    if (b === NC_ZONE) return 1;
    return a.localeCompare(b);
  });

  // Ensure discovered zones have default colors if not set
  for (const z of discoveredZones) {
    if (!zoneGlowColors[z]) {
      // Auto-assign a color from a palette
      const palette = ['#4dc9f6','#f67019','#537bc4','#acc236','#166a8f','#00a950','#8549ba','#e6194b'];
      const idx = Object.keys(zoneGlowColors).length % palette.length;
      zoneGlowColors[z] = palette[idx];
      saveZoneColors();
    }
  }

  if (backgroundLayer) backgroundLayer.cache();
  if (stage) stage.batchDraw();
}

function clearHeatMap() {
  // Restore original colors and opacity
  for (const [shapeId, originalFill] of Object.entries(heatMapOriginalColors)) {
    const shape = interactiveLayer.findOne('#' + shapeId);
    if (shape) {
      shape.fill(originalFill);
      // Stacking areas default to 0.6 opacity, chutes default to 1
      const entity = allMapEntities.find(e => e.id === shapeId);
      shape.opacity(entity && entity.type === 'chute' ? 1 : 0.6);
    }
  }
  heatMapOriginalColors = {};
  heatMapData = null;
  // Remove heat map count labels from stacking areas
  (textLayer.find('.heatmap-count-label') || []).forEach(l => l.destroy());
  // Remove zone glow shapes
  (backgroundLayer.find('.zone-glow') || []).forEach(g => g.destroy());
  if (backgroundLayer) backgroundLayer.cache();
  // Clear cached heat map data
  if (selectedNodeId) {
    chrome.storage.local.remove([`heatMapCache_${selectedNodeId}`]);
    console.log('🗑️ Heat map cache cleared');
  }
  if (stage) stage.batchDraw();
}

function exportUndrawnPackages() {
  if (!heatMapData) return;

  // Replicate the same filter→label matching logic from applyHeatMapColors
  const filterToLabels = {};
  for (const [label, filters] of Object.entries(stackingFilterMap)) {
    for (const f of filters) {
      if (!filterToLabels[f]) filterToLabels[f] = [];
      if (!filterToLabels[f].includes(label)) filterToLabels[f].push(label);
    }
  }

  const d2cLabels = new Set();
  for (const [label, info] of Object.entries(chuteConnectionMap)) {
    if (info.containerizeOption === 'directToContainer') d2cLabels.add(label);
  }

  function getMatchingLabels(sf) {
    const hasSuffix = sf.endsWith('-SMALL') || sf.endsWith('-LARGE');
    const baseSf = hasSuffix ? sf.replace(/-(SMALL|LARGE)$/, '') : sf;
    let labels = filterToLabels[sf] || [];
    if (hasSuffix) {
      const baseLabels = (filterToLabels[baseSf] || []).filter(l => !d2cLabels.has(l));
      const d2cExact = labels.filter(l => d2cLabels.has(l));
      labels = [...baseLabels, ...d2cExact];
    }
    const effectiveSf = hasSuffix ? baseSf : sf;
    if (effectiveSf.includes('CYCLE1') && !sf.endsWith('-SMALL')) {
      const parentLabels = filterToLabels[effectiveSf + '-PARENT'] || [];
      for (const pl of parentLabels) {
        if (!labels.includes(pl)) labels.push(pl);
      }
    }
    return labels;
  }

  // Collect undrawn: filters with no matching stacking area labels
  const rows = [];
  for (const vrId of heatMapData.activeVrids) {
    const filters = heatMapData.packagesByFilterPerVrid[vrId] || {};
    const info = heatMapData.loadInfo[vrId] || {};
    for (const [sf, count] of Object.entries(filters)) {
      const labels = getMatchingLabels(sf);
      if (labels.length === 0) {
        rows.push({
          vrId,
          route: info.route || '',
          status: info.status || '',
          carrier: info.carrier || '',
          dockDoor: info.dockDoor || '',
          stackingFilter: sf,
          packageCount: count,
          reason: !sf ? 'No stacking filter' : 'No matching stacking area'
        });
      }
    }
  }

  if (rows.length === 0) {
    alert('No undrawn packages found — all packages matched a stacking area.');
    return;
  }

  const columns = Object.keys(rows[0]);
  const esc = v => {
    if (v == null || v === '') return '';
    const s = String(v);
    return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  let csv = columns.map(c => esc(c)).join(',') + '\n';
  rows.forEach(row => { csv += columns.map(c => esc(row[c])).join(',') + '\n'; });

  const totalUndrawn = rows.reduce((a, r) => a + r.packageCount, 0);
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `undrawn_packages_${selectedNodeId}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  console.log(`📥 Exported ${rows.length} undrawn filter rows (${Math.round(totalUndrawn)} packages)`);
}

function showChuteDetailModal(chuteName) {
  if (!heatMapData || !heatMapData.chuteBreakdown) return;
  const breakdown = heatMapData.chuteBreakdown[chuteName] || [];
  const totalPkgs = breakdown.reduce((a, b) => a + b.count, 0);
  const totalCuft = breakdown.reduce((a, b) => a + b.cuft, 0);

  // Build pie chart as inline SVG
  const PIE_R = 80, PIE_CX = 100, PIE_CY = 100;
  const colors = ['#4dc9f6','#f67019','#f53794','#537bc4','#acc236','#166a8f','#00a950','#58595b','#8549ba','#e6194b','#3cb44b','#ffe119','#4363d8','#f58231','#911eb4','#42d4f4'];
  let pieSlices = '';
  let legendRows = '';

  if (breakdown.length > 0 && totalPkgs > 0) {
    let cumAngle = 0;
    breakdown.forEach((item, i) => {
      const frac = item.count / totalPkgs;
      const angle = frac * 360;
      const startRad = (cumAngle - 90) * Math.PI / 180;
      const endRad = (cumAngle + angle - 90) * Math.PI / 180;
      const largeArc = angle > 180 ? 1 : 0;
      const x1 = PIE_CX + PIE_R * Math.cos(startRad);
      const y1 = PIE_CY + PIE_R * Math.sin(startRad);
      const x2 = PIE_CX + PIE_R * Math.cos(endRad);
      const y2 = PIE_CY + PIE_R * Math.sin(endRad);
      const color = colors[i % colors.length];

      if (breakdown.length === 1) {
        pieSlices += `<circle cx="${PIE_CX}" cy="${PIE_CY}" r="${PIE_R}" fill="${color}" />`;
      } else {
        pieSlices += `<path d="M${PIE_CX},${PIE_CY} L${x1},${y1} A${PIE_R},${PIE_R} 0 ${largeArc},1 ${x2},${y2} Z" fill="${color}" />`;
      }
      cumAngle += angle;

      const pct = (frac * 100).toFixed(1);
      const cuftStr = item.cuft > 0 ? item.cuft.toFixed(1) + ' ft³' : '—';
      legendRows += `<tr>
        <td style="padding:3px 6px;"><span style="display:inline-block;width:12px;height:12px;background:${color};border-radius:2px;vertical-align:middle;"></span></td>
        <td style="padding:3px 6px;font-size:12px;">${item.label}</td>
        <td style="padding:3px 6px;text-align:right;font-size:12px;">${Math.round(item.count)}</td>
        <td style="padding:3px 6px;text-align:right;font-size:12px;">${pct}%</td>
        <td style="padding:3px 6px;text-align:right;font-size:12px;">${cuftStr}</td>
      </tr>`;
    });
  } else {
    pieSlices = `<circle cx="${PIE_CX}" cy="${PIE_CY}" r="${PIE_R}" fill="#555" />`;
    pieSlices += `<text x="${PIE_CX}" y="${PIE_CY}" text-anchor="middle" dy="5" fill="#aaa" font-size="14">No data</text>`;
  }

  const backdrop = document.createElement('div');
  backdrop.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:9999999;';

  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--bg-primary,#1e1e1e);color:var(--text-primary,#eee);border:2px solid var(--border-color,#444);border-radius:10px;padding:0;min-width:480px;max-width:650px;max-height:80vh;z-index:10000000;box-shadow:0 8px 32px rgba(0,0,0,0.4);overflow:hidden;display:flex;flex-direction:column;';

  modal.innerHTML = `
    <div style="background:var(--bg-secondary,#2a2a2a);padding:12px 20px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color,#444);flex-shrink:0;">
      <span style="font-weight:bold;font-size:16px;">📦 ${chuteName}</span>
      <button id="chute-modal-close" style="background:rgba(255,255,255,0.1);border:none;color:var(--text-primary,#eee);font-size:22px;cursor:pointer;line-height:1;padding:5px 10px;border-radius:3px;">✕</button>
    </div>
    <div style="padding:20px;overflow-y:auto;flex:1;">
      <div style="display:flex;gap:20px;align-items:flex-start;">
        <svg width="200" height="200" viewBox="0 0 200 200" style="flex-shrink:0;">${pieSlices}</svg>
        <div style="flex:1;">
          <div style="font-size:13px;margin-bottom:8px;">
            <span style="color:#aaa;">Total Packages:</span> <span style="font-weight:bold;">${Math.round(totalPkgs).toLocaleString()}</span><br>
            <span style="color:#aaa;">Total Volume:</span> <span style="font-weight:bold;">${totalCuft > 0 ? totalCuft.toFixed(1) + ' ft³' : '—'}</span><br>
            <span style="color:#aaa;">Stacking Areas:</span> <span style="font-weight:bold;">${breakdown.length}</span>
          </div>
        </div>
      </div>
      <div style="margin-top:16px;max-height:250px;overflow-y:auto;">
        <table style="width:100%;border-collapse:collapse;">
          <thead><tr style="border-bottom:1px solid var(--border-color,#444);color:#aaa;font-size:11px;">
            <th style="padding:4px 6px;"></th>
            <th style="padding:4px 6px;text-align:left;">Stacking Area</th>
            <th style="padding:4px 6px;text-align:right;">Pkgs</th>
            <th style="padding:4px 6px;text-align:right;">%</th>
            <th style="padding:4px 6px;text-align:right;">Volume</th>
          </tr></thead>
          <tbody>${legendRows || '<tr><td colspan="5" style="text-align:center;padding:12px;color:#888;">No stacking areas</td></tr>'}</tbody>
        </table>
      </div>
    </div>
  `;

  const ryanRoot = document.getElementById('ryan-console-root');
  (ryanRoot || document.body).appendChild(backdrop);
  (ryanRoot || document.body).appendChild(modal);

  const close = () => { modal.remove(); backdrop.remove(); };
  modal.querySelector('#chute-modal-close').addEventListener('click', close);
  backdrop.addEventListener('click', close);
}

function updateHeatMapFromCheckboxes() {
  if (!heatMapData) return;
  const checked = new Set();
  document.querySelectorAll('.heatmap-vrid-cb:checked').forEach(cb => checked.add(cb.value));
  heatMapData.activeVrids = checked;
  applyHeatMapColors();
}

async function refreshInboundPositions() {
  if (!heatMapData) return;
  const statusDiv = document.getElementById('heatmap-status');
  const status = msg => { if (statusDiv) statusDiv.innerHTML = `<p style="color:#666; margin:4px 0;">${msg}</p>`; };

  try {
    status('Refreshing inbound positions...');
    const startInput = document.getElementById('heatmap-start')?.value;
    const endInput = document.getElementById('heatmap-end')?.value;
    const startDate = new Date(startInput).getTime();
    const endDate = new Date(endInput).getTime();

    const ibBody = [
      'entity=getInboundDockView',
      `nodeId=${encodeURIComponent(selectedNodeId)}`,
      `startDate=${startDate}`,
      `endDate=${endDate}`,
      `loadCategories=${encodeURIComponent('inboundScheduled,inboundArrived,inboundCompleted')}`,
      `shippingPurposeType=${encodeURIComponent('TRANSSHIPMENT,NON-TRANSSHIPMENT,SHIP_WITH_AMAZON')}`
    ].join('&');

    const ibResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'include', body: ibBody
    });
    if (!ibResp.ok) throw new Error(`HTTP ${ibResp.status}`);
    const loads = (await ibResp.json())?.ret?.aaData || [];

    // Update load info (status, dock door) for existing VRIDs
    for (const entry of loads) {
      const vrId = entry.load?.vrId || '';
      if (vrId && heatMapData.loadInfo[vrId]) {
        heatMapData.loadInfo[vrId].status = entry.load?.status || '';
        heatMapData.loadInfo[vrId].dockDoor = (entry.resource || []).map(r => r.label).join('; ');
      }
    }

    showHeatMapControls(); // re-render with updated statuses
    status('✅ Inbound positions refreshed');
  } catch (error) {
    console.error('❌ Refresh failed:', error);
    status(`❌ ${error.message}`);
  }
}

function renderMapViewSidebar() {
  currentView = 'mapView';
  // If heat map is active, show heat map controls instead
  if (heatMapData) {
    showHeatMapControls();
    return;
  }
  // If inbound view is active, show inbound view controls
  if (inboundViewData) {
    showInboundViewControls();
    return;
  }
  sidebarContainer.innerHTML = `
    <h2>Ryan's Console</h2>
    
    <div class="tool-section">
      <h3>Tools</h3>
      <p style="color: #666; font-size: 14px;">Select a utility below:</p>
      <button id="tool-inbound-view" class="button" style="width: 100%; margin-bottom: 10px;">📦 Inbound View</button>
      <button id="tool-heat-map" class="button" style="width: 100%; margin-bottom: 10px;">🔥 Heat Map</button>
      <button class="button" style="width: 100%; margin-bottom: 10px;" disabled>🔧 Tool 3 (Coming Soon)</button>
    </div>
  `;
}

function renderLoadingView() {
  mapContainer.innerHTML = `
    <div class="loading-view" style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--text-primary);">
      <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
      <h3 style="margin: 0; color: var(--text-primary);">Loading Map...</h3>
    </div>
  `;
}

function showDomainHopLoadingScreen(nodeId) {
  mapContainer.innerHTML = `
    <div class="domain-hop-loading">
      <div class="loading-spinner"></div>
      <h2>Loading Map Data for ${nodeId}</h2>
      <div class="loading-steps">
        <div class="loading-step active">
          <span class="step-icon">🌐</span>
          <span class="step-text">Navigating to API domain...</span>
        </div>
        <div class="loading-step">
          <span class="step-icon">🔐</span>
          <span class="step-text">Authenticating...</span>
        </div>
        <div class="loading-step">
          <span class="step-icon">📡</span>
          <span class="step-text">Fetching map data...</span>
        </div>
        <div class="loading-step">
          <span class="step-icon">⚙️</span>
          <span class="step-text">Processing data...</span>
        </div>
        <div class="loading-step">
          <span class="step-icon">✅</span>
          <span class="step-text">Returning to editor...</span>
        </div>
      </div>
      <p class="loading-note">This usually takes 3-5 seconds</p>
    </div>
  `;
}

function renderAddEquipmentUI(resourceType, title) {
  const uiContainer = document.getElementById('add-equipment-ui');
  if (!uiContainer) return;
  
  uiContainer.innerHTML = `
    <h4>Add ${title}</h4>
    <input type="text" id="equipment-search-bar" placeholder="Search by label...">
    <div id="equipment-search-results"></div>
  `;
}

function renderEquipmentList(items) {
  const resultsContainer = document.getElementById('equipment-search-results');
  if (!resultsContainer) return;
  
  if (!items || items.length === 0) {
    resultsContainer.innerHTML = `<p style="padding: 10px; color: #777;">No items found.</p>`;
    return;
  }
  
  resultsContainer.innerHTML = items.map(item => `
    <div class="search-result-item" draggable="true" data-resource-id="${item.resourceId}">
      ${item.label}
    </div>
  `).join('');
}

// --- 4. Data Loading & Persistence ---



// 🔧 FIX: Sync all shape transforms back to entity data before saving
function syncShapeTransformsToEntities() {
  interactiveLayer.find('.editable-shape').forEach(shape => {
    const shapeId = shape.id();
    const entity = allMapEntities.find(e => e.id === shapeId);
    
    if (entity) {
      // Get current shape position and size
      const x = shape.x();
      const y = shape.y();
      const width = shape.width() * shape.scaleX();
      const height = shape.height() * shape.scaleY();
      
      // Update entity data (convert back from scaled canvas coords)
      entity.absTrans.pt.x = x / SCALE;
      entity.absTrans.pt.y = y / SCALE;
      entity.lodGeomMap[1].s.l = width / SCALE;
      entity.lodGeomMap[1].s.w = height / SCALE;
      
      console.log(`📍 Synced ${shapeId}: pos=(${entity.absTrans.pt.x.toFixed(2)}, ${entity.absTrans.pt.y.toFixed(2)}), size=(${entity.lodGeomMap[1].s.l.toFixed(2)} x ${entity.lodGeomMap[1].s.w.toFixed(2)})`);
    }
  });
}

function saveMapToStorage(nodeId) {
  // 🔧 FIX: Sync transforms before saving
  syncShapeTransformsToEntities();
  
  const mapData = {
    nodeId: nodeId,
    entities: allMapEntities,
    timestamp: Date.now()
  };
  
  try {
    const jsonString = JSON.stringify(mapData);
    localStorage.setItem(STORAGE_KEY_PREFIX + nodeId, jsonString);
    lastSaveTime = mapData.timestamp;
    console.log(`✅ Map saved to localStorage (${(jsonString.length / 1024).toFixed(2)} KB)`);
    console.log('   Storage key:', STORAGE_KEY_PREFIX + nodeId);
    console.log('   Entities saved:', allMapEntities.length);
    return true;
  } catch (err) {
    console.error('❌ Failed to save map:', err);
    alert('Failed to save map. Storage may be full.');
    return false;
  }
}

function loadMapFromStorage(nodeId) {
  try {
    const stored = localStorage.getItem(STORAGE_KEY_PREFIX + nodeId);
    if (stored) {
      const mapData = JSON.parse(stored);
      console.log('✅ Map loaded from localStorage');
      console.log('   Storage key:', STORAGE_KEY_PREFIX + nodeId);
      console.log('   Entities loaded:', mapData.entities.length);
      console.log('   Last saved:', new Date(mapData.timestamp).toLocaleString());
      return mapData;
    } else {
      console.log('ℹ️ No saved map found for:', STORAGE_KEY_PREFIX + nodeId);
    }
  } catch (err) {
    console.error('❌ Failed to load map from storage:', err);
  }
  return null;
}

function exportMapToFile(nodeId) {
  // 🔧 FIX: Sync before export
  syncShapeTransformsToEntities();
  
  const mapData = {
    nodeId: nodeId,
    entities: allMapEntities,
    exportDate: new Date().toISOString(),
    version: '1.0'
  };
  
  const jsonString = JSON.stringify(mapData, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `map_${nodeId}_${Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log('✅ Map exported to file');
}

async function importMapFromFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const mapData = JSON.parse(e.target.result);
        
        if (!mapData.nodeId || !mapData.entities || !Array.isArray(mapData.entities)) {
          throw new Error('Invalid map file format');
        }
        
        console.log('✅ Map imported from file');
        resolve(mapData);
      } catch (err) {
        reject(err);
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}

function calculateMissingResources() {
  const drawnLabels = new Set(allMapEntities.map(e => e.name));
  
  missingResources = {};
  
  allApiResources.forEach(resource => {
    if (!drawnLabels.has(resource.label)) {
      const type = resource.resourceType;
      
      if (!missingResources[type]) {
        missingResources[type] = [];
      }
      
      missingResources[type].push(resource);
    }
  });
  
  console.log('✅ Missing resources calculated:', missingResources);
}

async function loadMapData(nodeId, forceReload = false) {
  if (!forceReload) {
    const savedMap = loadMapFromStorage(nodeId);
    if (savedMap) {
      console.log('📦 Using saved map from storage');
      allMapEntities = savedMap.entities;
      lastSaveTime = savedMap.timestamp;
      const resourceStorage = await chrome.storage.local.get([`apiResult3_${nodeId}`]);
      const resourceResult = resourceStorage[`apiResult3_${nodeId}`];
      if (resourceResult && resourceResult.success) {
        allApiResources = resourceResult.data[0].data.resources || [];
        calculateMissingResources();
      } else {
        console.warn('⚠️ No cached resources data for', nodeId);
      }
      // Load stacking filter data from cached reservations
      const reservationStorage = await chrome.storage.local.get([`apiResult4_${nodeId}`]);
      const reservationResult = reservationStorage[`apiResult4_${nodeId}`];
      if (reservationResult && reservationResult.success) {
        buildStackingFilterMap(reservationResult.data);
      } else {
        console.warn('⚠️ No cached reservations data for', nodeId);
      }
      // Load VSM data
      const vsmStorage = await chrome.storage.local.get([`apiResult5_${nodeId}`]);
      const vsmResult = vsmStorage[`apiResult5_${nodeId}`];
      if (vsmResult && vsmResult.success) {
        buildVsmMap(vsmResult.data);
      } else {
        console.warn('⚠️ No cached VSM data for', nodeId);
      }
      // Load chute connection data
      const chuteStorage = await chrome.storage.local.get([`apiResult6_${nodeId}`]);
      const chuteResult = chuteStorage[`apiResult6_${nodeId}`];
      if (chuteResult && chuteResult.success) {
        buildChuteConnectionMap(chuteResult.data);
      } else {
        console.warn('⚠️ No cached chute connection data for', nodeId);
      }
      // Load chute label map
      const chuteLabelStorage = await chrome.storage.local.get([`apiResult7_${nodeId}`]);
      const chuteLabelResult = chuteLabelStorage[`apiResult7_${nodeId}`];
      if (chuteLabelResult && chuteLabelResult.success) {
        buildChuteLabelMap(chuteLabelResult.data);
      } else {
        console.warn('⚠️ No cached chute label data for', nodeId);
      }
      // Restore cached heat map data
      const heatMapStorage = await chrome.storage.local.get([`heatMapCache_${nodeId}`]);
      const heatMapCache = heatMapStorage[`heatMapCache_${nodeId}`];
      if (heatMapCache) {
        heatMapData = {
          ...heatMapCache,
          activeVrids: new Set(heatMapCache.activeVrids) // Array -> Set
        };
        delete heatMapData.timestamp;
        console.log(`🔥 Restored cached heat map data (${heatMapCache.vrids?.length || 0} VRIDs, cached ${new Date(heatMapCache.timestamp).toLocaleString()})`);
      }
      return allMapEntities;
    }
  }
  console.log('🚀 Loading map data from API for Node:', nodeId);
  const storageKey1 = `apiResult1_${nodeId}`;
  const storageKey2 = `apiResult2_${nodeId}`;
  const storageKey3 = `apiResult3_${nodeId}`;
  const storageKey4 = `apiResult4_${nodeId}`;
  const storageKey5 = `apiResult5_${nodeId}`;
  const storageKey6 = `apiResult6_${nodeId}`;
  const storageKey7 = `apiResult7_${nodeId}`;
  const storage = await chrome.storage.local.get([storageKey1, storageKey2, storageKey3, storageKey4, storageKey5, storageKey6, storageKey7]);
  
  if (!storage[storageKey1] || !storage[storageKey2] || !storage[storageKey3] || !storage[storageKey4] || !storage[storageKey5] || !storage[storageKey6] || !storage[storageKey7]) {
    // Safety check: prevent infinite hop loops
    const hopAttemptKey = `hopAttempts_${nodeId}`;
    const hopAttempts = parseInt(localStorage.getItem(hopAttemptKey) || '0', 10);
    
    if (hopAttempts >= 2) {
      console.error('🛑 Max domain hop attempts reached for', nodeId, '- aborting to prevent infinite loop');
      localStorage.removeItem(hopAttemptKey);
      localStorage.removeItem('pendingMapLoad');
      await chrome.storage.local.remove(['lastUsedNode']);
      showErrorModal('Please try again or review your permissions.');
      throw new Error(`Failed to load map data for ${nodeId} after multiple attempts. The API may be unavailable or you may not have permission to access this node.`);
    }
    
    console.log('📡 No cached API data for', nodeId, `- initiating domain hop (attempt ${hopAttempts + 1})`);
    localStorage.setItem(hopAttemptKey, String(hopAttempts + 1));
    localStorage.setItem('pendingMapLoad', nodeId);
    await initiateMapDataHop(nodeId);
    throw new Error('DOMAIN_HOP_INITIATED'); // Special error to indicate hop started
  }
  
  // Check if any API call failed
  const allKeys = [storageKey1, storageKey2, storageKey3, storageKey4, storageKey5, storageKey6, storageKey7];
  const failCleanup = async (msg) => {
    await chrome.storage.local.remove(allKeys);
    localStorage.removeItem('pendingMapLoad');
    localStorage.removeItem(`hopAttempts_${nodeId}`);
    await chrome.storage.local.remove(['lastUsedNode']);
    showErrorModal('Please try again or review your permissions.');
    throw new Error(msg + '\n\nPlease try loading the map again.');
  };
  
  if (!storage[storageKey1].success) {
    console.error('❌ API Call 1 failed previously:', storage[storageKey1].error);
    await failCleanup('API Call 1 failed: ' + storage[storageKey1].error);
  }
  if (!storage[storageKey2].success) {
    console.error('❌ API Call 2 failed previously:', storage[storageKey2].error);
    await failCleanup('API Call 2 failed: ' + storage[storageKey2].error);
  }
  if (!storage[storageKey3].success) {
    console.error('❌ API Call 3 (Resources) failed previously:', storage[storageKey3].error);
    await failCleanup('Resources API failed: ' + storage[storageKey3].error);
  }
  if (!storage[storageKey4].success) {
    console.error('❌ API Call 4 (Reservations) failed previously:', storage[storageKey4].error);
    await failCleanup('Reservations API failed: ' + storage[storageKey4].error);
  }
  if (!storage[storageKey5].success) {
    console.error('❌ API Call 5 (VSM) failed previously:', storage[storageKey5].error);
    await failCleanup('VSM API failed: ' + storage[storageKey5].error);
  }
  if (!storage[storageKey6].success) {
    console.error('❌ API Call 6 (Connected Resources) failed previously:', storage[storageKey6].error);
    await failCleanup('Connected Resources API failed: ' + storage[storageKey6].error);
  }
  if (!storage[storageKey7].success) {
    console.error('❌ API Call 7 (Chutes) failed previously:', storage[storageKey7].error);
    await failCleanup('Chutes API failed: ' + storage[storageKey7].error);
  }
  
  console.log('✅ Found cached API results for', nodeId, ', processing...');
  
  // Clear hop attempt counter on success
  localStorage.removeItem(`hopAttempts_${nodeId}`);
  
  const json1 = storage[storageKey1].data;
  const json2 = storage[storageKey2].data;
  
  
  if (!json1 || !Array.isArray(json1) || json1.length === 0) {
    await chrome.storage.local.remove([storageKey1, storageKey2]);
    throw new Error('Invalid API result 1: Expected non-empty array. Please try loading the map again.');
  }
  
  if (!json2 || !Array.isArray(json2) || json2.length === 0) {
    await chrome.storage.local.remove([storageKey1, storageKey2]);
    throw new Error('Invalid API result 2: Expected non-empty array. Please try loading the map again.');
  }
  
  const innerMapString1 = json1[0]?.data?.digitalTwin2dMap;
  const innerMapString2 = json2[0]?.data?.mapDeployment?.mapContents;
  
  if (!innerMapString1) {
    await chrome.storage.local.remove([storageKey1, storageKey2]);
    throw new Error('digitalTwin2dMap not found in API result 1. Please try loading the map again.');
  }
  
  if (!innerMapString2) {
    await chrome.storage.local.remove([storageKey1, storageKey2]);
    console.error('❌ json2[0].data:', json2[0]?.data);
    console.error('❌ json2[0].data.mapDeployment:', json2[0]?.data?.mapDeployment);
    throw new Error('mapContents not found in API result 2. Please try loading the map again.');
  }
  
  const innerMap1 = JSON.parse(innerMapString1);
  const innerMap2 = JSON.parse(innerMapString2);
  const mapEntities1 = innerMap1.e || [];
  const mapEntities2 = innerMap2.e || [];
  const uniqueEntitiesMap = new Map();
  // Normalize compact entities (short keys) back to full format
  const normalize = (e) => {
    if (e.name !== undefined) return e; // already full format
    return {
      id: e.id,
      name: e.n,
      type: e.t,
      absTrans: { pt: { x: e.x, y: e.y } },
      lodGeomMap: e.s ? { 1: { s: e.s } } : {}
    };
  };
  mapEntities1.forEach(entity => uniqueEntitiesMap.set(entity.id, normalize(entity)));
  mapEntities2.forEach(entity => uniqueEntitiesMap.set(entity.id, normalize(entity)));
  allMapEntities = Array.from(uniqueEntitiesMap.values())
    .filter(entity => entity.type !== 'wirelessAccessPoint');
  console.log('✅ Parsed', allMapEntities.length, 'entities (filtered wirelessAccessPoint)');
  const json3 = storage[storageKey3].data;
  allApiResources = json3[0].data.resources || [];
  calculateMissingResources();
  
  // Build stacking filter map from reservations data
  const json4 = storage[storageKey4].data;
  buildStackingFilterMap(json4);
  
  // Build VSM map from visual sortation marker data
  const json5 = storage[storageKey5].data;
  buildVsmMap(json5);
  
  // Build chute connection map from connected resources data
  const json6 = storage[storageKey6].data;
  buildChuteConnectionMap(json6);
  
  // Build chute label-to-id map
  const json7 = storage[storageKey7].data;
  buildChuteLabelMap(json7);
  
  // DON'T remove API results - keep them cached for future loads
  // They will be cleared when user clicks "Reload Base Map"
  console.log('✅ Keeping API results cached in chrome.storage for future use');
  
  // Restore cached heat map data (same as savedMap path)
  const heatMapStorage2 = await chrome.storage.local.get([`heatMapCache_${nodeId}`]);
  const heatMapCache2 = heatMapStorage2[`heatMapCache_${nodeId}`];
  if (heatMapCache2) {
    heatMapData = {
      ...heatMapCache2,
      activeVrids: new Set(heatMapCache2.activeVrids)
    };
    delete heatMapData.timestamp;
    console.log(`🔥 Restored cached heat map data (${heatMapCache2.vrids?.length || 0} VRIDs, cached ${new Date(heatMapCache2.timestamp).toLocaleString()})`);
  }

  return allMapEntities;
}

// 🚀 PERFORMANCE: Viewport culling function
function isInViewport(shape) {
  if (!stage) return true;
  
  const viewport = {
    x: -stage.x() / stage.scaleX(),
    y: -stage.y() / stage.scaleY(),
    width: stage.width() / stage.scaleX(),
    height: stage.height() / stage.scaleY()
  };
  
  const shapeBox = shape.getClientRect({ relativeTo: stage });
  
  // Add padding to viewport for smoother experience
  const padding = 100;
  
  return !(shapeBox.x > viewport.x + viewport.width + padding ||
           shapeBox.x + shapeBox.width < viewport.x - padding ||
           shapeBox.y > viewport.y + viewport.height + padding ||
           shapeBox.y + shapeBox.height < viewport.y - padding);
}

// 🚀 PERFORMANCE: Update shape visibility based on viewport
function updateShapeVisibility() {
  if (!interactiveLayer || !textLayer) return;
  
  let visibleCount = 0;
  let hiddenCount = 0;
  
  interactiveLayer.find('.editable-shape').forEach(shape => {
    const visible = isInViewport(shape);
    shape.visible(visible);
    if (visible) visibleCount++;
    else hiddenCount++;
  });
  
  textLayer.find('Text').forEach(label => {
    const visible = isInViewport(label);
    label.visible(visible);
  });
  
  console.log(`🎯 Viewport culling: ${visibleCount} visible, ${hiddenCount} hidden`);
}

function initializeMap(isEditor = true) {
  mapContainer.innerHTML = '';
  
  const width = mapContainer.clientWidth;
  const height = mapContainer.clientHeight;

  stage = new Konva.Stage({
    container: 'map-container',
    width: width,
    height: height,
    draggable: isEditor,
  });

  backgroundLayer = new Konva.Layer();
  stage.add(backgroundLayer);

  interactiveLayer = new Konva.Layer({ 
    listening: isEditor,
    // 🚀 PERFORMANCE: Faster rendering without perfect pixel accuracy
    perfectDrawEnabled: false
  });
  stage.add(interactiveLayer);

  textLayer = new Konva.Layer({
    // 🚀 PERFORMANCE: Disable hit detection on text layer
    listening: false,
    // 🚀 PERFORMANCE: Faster text rendering
    perfectDrawEnabled: false
  });
  stage.add(textLayer);

  stage.y(stage.height()); 
  backgroundLayer.scaleY(-1);
  interactiveLayer.scaleY(-1);
  textLayer.scaleY(-1);

  // 🚀 PERFORMANCE: Cache static background layer only
  backgroundLayer.cache();

  // 🚀 PERFORMANCE: Throttled zoom with viewport culling
  let zoomTimeout;
  const MIN_SCALE = 0.1;
  const MAX_SCALE = 10;
  
  stage.on('wheel', (e) => {
    e.evt.preventDefault();
    
    // Disable listening during zoom for performance
    if (!isInteracting) {
      isInteracting = true;
      interactiveLayer.listening(false);
    }
    
    clearTimeout(zoomTimeout);
    
    const oldScale = stage.scaleX();
    const pointer = stage.getPointerPosition();
    const mousePointTo = {
      x: (pointer.x - stage.x()) / oldScale,
      y: (pointer.y - stage.y()) / oldScale,
    };
    
    // 🚀 PERFORMANCE: Clamp zoom level
    let newScale = e.evt.deltaY > 0 ? oldScale / 1.1 : oldScale * 1.1;
    newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, newScale));
    
    stage.scale({ x: newScale, y: newScale });
    const newPos = {
      x: pointer.x - mousePointTo.x * newScale,
      y: pointer.y - mousePointTo.y * newScale,
    };
    stage.position(newPos);
    
    // Update visibility after zoom
    updateShapeVisibility();
    
    // Re-enable after zoom completes
    zoomTimeout = setTimeout(() => {
      isInteracting = false;
      interactiveLayer.listening(true);
    }, 150);
  });
  
  // 🚀 PERFORMANCE: Optimize pan operations
  stage.on('dragstart', () => {
    if (!isInteracting) {
      isInteracting = true;
      interactiveLayer.listening(false);
    }
  });
  
  stage.on('dragmove', () => {
    // Update visibility during pan
    updateShapeVisibility();
  });
  
  stage.on('dragend', () => {
    setTimeout(() => {
      isInteracting = false;
      interactiveLayer.listening(true);
    }, 100);
  });

  if (isEditor) {
    transformer = new Konva.Transformer({
      nodes: [],
      keepRatio: false,
      enabledAnchors: ['top-left', 'top-right', 'bottom-left', 'bottom-right', 
                       'top-center', 'bottom-center', 'middle-left', 'middle-right'],
    });
    interactiveLayer.add(transformer);
  
    stage.on('click tap', (e) => {
      const shape = e.target;

      if (shape === stage) {
        if (currentTool === 'select') {
          transformer.nodes([]);
        }
        return;
      }

      if (shape.hasName('editable-shape')) {
        if (currentTool === 'select') {
          transformer.nodes([shape]);
          shape.setDraggable(true);
        } 
        else if (currentTool === 'delete') {
          const shapeId = shape.id();
          allMapEntities = allMapEntities.filter(e => e.id !== shapeId);
          console.log(`🗑️ Deleted entity ${shapeId} from data array`);
          
          const labelId = shape.id() + "_label";
          const label = textLayer.findOne(`#${labelId}`);
          if (label) {
            label.destroy();
          }
          
          shape.destroy();
          transformer.nodes([]);
          
          renderEditorTools();
        }
        else if (currentTool === 'add-label') {
          addLabelToShape(shape);
        }
      }
    });
    
    // 🔧 FIX: Update label position when shape is transformed
    transformer.on('transform', () => {
      const nodes = transformer.nodes();
      if (nodes.length === 1) {
        updateLabelPosition(nodes[0]);
      }
    });
    
    transformer.on('transformend', () => {
      const nodes = transformer.nodes();
      if (nodes.length === 1) {
        updateLabelPosition(nodes[0]);
        renderEditorTools();
      }
    });
    
    stage.on('dragend', (e) => {
      if (e.target.hasName('editable-shape')) {
        renderEditorTools();
      }
    });
  }

  // Hide tooltip when mouse leaves the canvas container entirely
  stage.container().addEventListener('mouseleave', () => {
    activeTooltipShape = null;
    hideTooltip();
  });
}

// 🔧 NEW: Update label position and size to match shape
function updateLabelPosition(shape) {
  const labelId = shape.id() + "_label";
  const label = textLayer.findOne(`#${labelId}`);
  
  if (!label) return;
  
  const width = shape.width() * shape.scaleX();
  const height = shape.height() * shape.scaleY();
  const isTall = height > width;
  
  const fitWidth = isTall ? height : width;
  const fitHeight = isTall ? width : height;
  
  let fontSize = Math.min(fitHeight * 0.8, fitWidth * 0.3, 10);
  label.fontSize(fontSize);
  
  while (label.width() > fitWidth * 0.9 && fontSize > 1) {
    fontSize -= 0.5;
    label.fontSize(fontSize);
  }
  
  label.x(shape.x());
  label.y(shape.y());
  
  if (isTall) {
    label.rotation(90);
    label.offsetX(label.width() / 2);
    label.offsetY(label.height() / 2);
  } else {
    label.rotation(0);
    label.offsetX(label.width() / 2);
    label.offsetY(label.height() / 2);
  }
  
  textLayer.batchDraw();
}

function drawMap(data) {
  let counts = { dockDoor: 0, chute: 0, areas: 0, wall: 0, other: 0 };
  
  data.forEach(item => {
    switch (item.type) {
      case 'dockDoor':
        drawDockDoor(item);
        counts.dockDoor++;
        break;
      case 'chute':
        drawChute(item);
        counts.chute++;
        break;
      case 'stagingArea':
      case 'generalArea':
        drawArea(item, true);
        counts.areas++;
        break;
      case 'stackingArea':
        drawArea(item, false);
        counts.areas++;
        break;
      case 'wall':
        drawWall(item);
        counts.wall++;
        break;
      default:
        drawOther(item);
        counts.other++;
    }
  });
  
  console.log('📍 Entities drawn:', counts);
  
  // 🚀 PERFORMANCE: Only cache background layer (static walls)
  // Don't cache interactive/text to avoid blur
  backgroundLayer.cache();
  
  // 🚀 PERFORMANCE: Initial viewport culling
  setTimeout(() => {
    updateShapeVisibility();
  }, 100);
  
  console.log('✅ Map rendering complete!');
}

// Helper: draw a single entity by type
function drawEntity(entity) {
  switch (entity.type) {
    case 'dockDoor':
      drawDockDoor(entity);
      break;
    case 'chute':
      drawChute(entity);
      break;
    case 'stagingArea':
    case 'generalArea':
      drawArea(entity, true);
      break;
    case 'stackingArea':
      drawArea(entity, false);
      break;
    case 'wall':
      drawWall(entity);
      break;
    default:
      drawOther(entity);
  }
}

// --- 6. Individual Shape Drawing Functions ---

function createEditableRect(options) {
  const rect = new Konva.Rect({
    ...options,
    // 🚀 PERFORMANCE: Disable shadow calculations
    shadowForStrokeEnabled: false,
    // 🚀 PERFORMANCE: Faster rendering
    perfectDrawEnabled: false
  });
  rect.name('editable-shape');
  rect.setDraggable(false);
  
  rect.on('mouseenter', (e) => {
    if (currentTool === 'select' || currentTool === 'delete' || currentTool === 'add-label') {
      stage.container().style.cursor = 'pointer';
    }
    
    const shapeId = rect.id();
    const entity = allMapEntities.find(ent => ent.id === shapeId);
    const name = entity ? entity.name : shapeId;
    
    // Build tooltip content — enrich stacking areas with filter + VSM + D2C info
    let tooltipText = name;
    let tooltipHasHtml = false;
    if (entity && (entity.type === 'stackingArea' || entity.type === 'stagingArea') && stackingFilterMap[name]) {
      const filters = stackingFilterMap[name];
      const lines = filters.map(f => {
        const marker = vsmMap[f];
        return marker ? `${f} [${marker}]` : f;
      });
      tooltipText = name + '\n' + lines.join('\n');
      
      // Add heat map package count if active
      if (heatMapData && heatMapData.countByLabel && heatMapData.countByLabel[name]) {
        const count = Math.round(heatMapData.countByLabel[name]);
        tooltipText += `\n📦 ${count} package${count !== 1 ? 's' : ''}`;
      }
      
      // Check if this is a D2C stacking area
      const connInfo = chuteConnectionMap[name];
      if (connInfo && connInfo.containerizeOption === 'directToContainer') {
        tooltipHasHtml = true;
      }
    }
    // Enrich chutes with connected stacking areas (resolve short label to full chuteId)
    else if (entity && entity.type === 'chute') {
      const fullChuteId = chuteLabelToIdMap[name];
      if (fullChuteId && chuteToStackingMap[fullChuteId]) {
        const directLabels = chuteToStackingMap[fullChuteId];
        // Direct labels (e.g. "AUTO-CHUTE215") are prefixes for actual map entities
        // (e.g. "AUTO-CHUTE215-1", "AUTO-CHUTE215-2"). Find all matching stacking areas.
        const matchedAreas = allMapEntities
          .filter(ent => ent.type === 'stackingArea' && directLabels.some(dl => ent.name && ent.name.startsWith(dl)))
          .map(ent => ent.name);
        if (matchedAreas.length > 0) {
          tooltipText = name + '\n→ ' + matchedAreas.join('\n→ ');
        } else if (directLabels.length > 0) {
          // Fallback: show the direct API labels if no map entities match
          tooltipText = name + '\n→ ' + directLabels.join('\n→ ');
        }
      }
      // Add heat map package count for chute if active
      if (heatMapData && heatMapData.countByChute && heatMapData.countByChute[name]) {
        const count = Math.round(heatMapData.countByChute[name]);
        tooltipText += `\n📦 ${count} package${count !== 1 ? 's' : ''}`;
      }
    }
    
    activeTooltipShape = rect;
    showTooltip(tooltipText, e.evt.clientX, e.evt.clientY, tooltipHasHtml);
  });
  
  rect.on('mouseleave', () => {
    stage.container().style.cursor = 'default';
    if (activeTooltipShape === rect) activeTooltipShape = null;
    hideTooltip();
  });
  
  rect.on('mousemove', (e) => {
    tooltipLastActive = Date.now();
    positionTooltip(e.evt.clientX, e.evt.clientY);
  });
  
  rect.on('dragmove', function() {
    updateLabelPosition(this);
  });

  // Double-click on chutes opens detail modal when heat map is active
  rect.on('dblclick dbltap', () => {
    if (!heatMapData || !heatMapData.chuteBreakdown) return;
    const shapeId = rect.id();
    const entity = allMapEntities.find(ent => ent.id === shapeId);
    if (entity && entity.type === 'chute') {
      showChuteDetailModal(entity.name);
    }
  });
  
  return rect;
}

// Tooltip management — uses raw browser mouse coords (evt.clientX/Y)
// so we never fight the inverted Konva Y axis.
let tooltipDiv = null;
let activeTooltipShape = null;
let tooltipLastActive = 0;
let tooltipFadeInterval = null;

function showTooltip(text, clientX, clientY, isD2C = false) {
  if (!tooltipDiv) {
    tooltipDiv = document.createElement('div');
    tooltipDiv.style.cssText = `
      position: fixed;
      background: rgba(240, 240, 240, 0.95);
      color: #222;
      padding: 6px 10px;
      border-radius: 4px;
      font-size: 12px;
      font-family: Arial, sans-serif;
      pointer-events: none;
      z-index: 2147483647;
      white-space: pre-line;
      box-shadow: 0 1px 4px rgba(0,0,0,0.18);
      border: 1px solid #ccc;
      max-width: 300px;
      opacity: 0;
      transition: opacity 0.15s ease;
    `;
    const ryanRoot = document.getElementById('ryan-console-root');
    (ryanRoot || document.body).appendChild(tooltipDiv);
  }
  
  if (isD2C) {
    tooltipDiv.innerHTML = text.replace(/\n/g, '<br>') + '<br><span style="color:#d4a017;font-weight:bold;">D2C</span>';
  } else {
    tooltipDiv.textContent = text;
  }
  tooltipDiv.style.display = 'block';
  // Force reflow then fade in
  void tooltipDiv.offsetWidth;
  tooltipDiv.style.opacity = '1';
  tooltipLastActive = Date.now();
  positionTooltip(clientX, clientY);
  
  // Start the fade-out watchdog if not already running
  if (!tooltipFadeInterval) {
    tooltipFadeInterval = setInterval(() => {
      // Only fade out if no shape is actively hovered AND timestamp is stale
      if (!activeTooltipShape && Date.now() - tooltipLastActive > 300) {
        tooltipDiv.style.opacity = '0';
        setTimeout(() => {
          if (tooltipDiv && tooltipDiv.style.opacity === '0') {
            tooltipDiv.style.display = 'none';
          }
        }, 150);
        clearInterval(tooltipFadeInterval);
        tooltipFadeInterval = null;
      }
    }, 100);
  }
}

function hideTooltip() {
  if (tooltipDiv) {
    tooltipDiv.style.opacity = '0';
    setTimeout(() => {
      if (tooltipDiv && tooltipDiv.style.opacity === '0') {
        tooltipDiv.style.display = 'none';
      }
    }, 150);
  }
  if (tooltipFadeInterval) {
    clearInterval(tooltipFadeInterval);
    tooltipFadeInterval = null;
  }
}

function positionTooltip(clientX, clientY) {
  if (!tooltipDiv) return;
  const offset = 12;
  let left = clientX + offset;
  let top = clientY + offset;
  
  // Keep tooltip on screen
  const rect = tooltipDiv.getBoundingClientRect();
  if (left + rect.width > window.innerWidth) {
    left = clientX - rect.width - offset;
  }
  if (top + rect.height > window.innerHeight) {
    top = clientY - rect.height - offset;
  }
  
  tooltipDiv.style.left = left + 'px';
  tooltipDiv.style.top = top + 'px';
}

function drawDockDoor(item) {
  const x = item.absTrans.pt.x * SCALE;
  const y = item.absTrans.pt.y * SCALE;
  const width = (item.lodGeomMap[1].s.l || item.lodGeomMap[1].s.x) * SCALE;
  const height = (item.lodGeomMap[1].s.w || item.lodGeomMap[1].s.y) * SCALE;

  const rect = createEditableRect({
    x, y, width, height,
    offsetX: width / 2, 
    offsetY: height / 2, 
    fill: '#b0b0b0',
    stroke: 'black',
    strokeWidth: 0.5,
    id: item.id
  });
  interactiveLayer.add(rect);
  
  addLabel(rect, item.name, item.id + "_label", item.type);
}

function drawChute(item) {
  const x = item.absTrans.pt.x * SCALE;
  const y = item.absTrans.pt.y * SCALE;
  const width = (item.lodGeomMap[1].s.l || item.lodGeomMap[1].s.x) * SCALE;
  const height = (item.lodGeomMap[1].s.w || item.lodGeomMap[1].s.y) * SCALE;

  const rect = createEditableRect({
    x, y, width, height,
    offsetX: width / 2,
    offsetY: height / 2,
    fill: 'cyan',
    stroke: 'black',
    strokeWidth: 0.2,
    id: item.id
  });
  interactiveLayer.add(rect);
  
  if (item.name) {
    addLabel(rect, item.name, item.id + "_label", item.type);
  }
}

function drawArea(item, showLabel = true) {
  const x = item.absTrans.pt.x * SCALE;
  const y = item.absTrans.pt.y * SCALE;
  const width = (item.lodGeomMap[1].s.l || item.lodGeomMap[1].s.x) * SCALE;
  const height = (item.lodGeomMap[1].s.w || item.lodGeomMap[1].s.y) * SCALE;

  const rect = createEditableRect({
    x, y, width, height,
    offsetX: width / 2,
    offsetY: height / 2,
    fill: 'lightgreen',
    stroke: 'black',
    strokeWidth: 0.2,
    opacity: 0.6,
    id: item.id
  });
  interactiveLayer.add(rect);
  
  if (showLabel) {
    addLabel(rect, item.name, item.id + "_label", item.type);
  }
}

function drawWall(item) {
  const baseX = item.absTrans.pt.x;
  const baseY = item.absTrans.pt.y;
  const points = item.lodGeomMap[1].s.pts.flatMap(p => [(baseX + p.x) * SCALE, (baseY + p.y) * SCALE]);
  const wallLine = new Konva.Line({
    points: points,
    stroke: 'black',
    strokeWidth: 1,
    closed: false
  });
  backgroundLayer.add(wallLine);
}

function drawOther(item) {
  try {
    const x = item.absTrans.pt.x * SCALE;
    const y = item.absTrans.pt.y * SCALE;
    const width = (item.lodGeomMap[1].s.l || item.lodGeomMap[1].s.x) * SCALE;
    const height = (item.lodGeomMap[1].s.w || item.lodGeomMap[1].s.y) * SCALE;
    if (!width || !height) return;

    const rect = createEditableRect({
      x, y, width, height,
      offsetX: width / 2,
      offsetY: height / 2,
      fill: 'gray',
      stroke: '#555',
      strokeWidth: 0.1,
      opacity: 0.6,
      id: item.id
    });
    interactiveLayer.add(rect);
    
    if (item.name) {
      addLabel(rect, item.name, item.id + "_label", item.type);
    }
  } catch (e) { }
}

// 🔧 UPDATED: Smart label positioning based on item type
function addLabel(shape, text, labelId, itemType) {
  const width = shape.width() * (shape.scaleX ? shape.scaleX() : 1);
  const height = shape.height() * (shape.scaleY ? shape.scaleY() : 1);
  const isTall = height > width;
  
  // The space available for text along its reading direction
  const fitWidth = isTall ? height : width;
  const fitHeight = isTall ? width : height;
  
  // Start with a font size proportional to the smaller dimension
  let fontSize = Math.min(fitHeight * 0.8, fitWidth * 0.3, 10);
  
  const label = new Konva.Text({
    text: text,
    fontSize: fontSize,
    fill: 'black',
    fontStyle: 'bold',
    id: labelId
  });
  
  // Shrink font until text fits within available width
  while (label.width() > fitWidth * 0.9 && fontSize > 1) {
    fontSize -= 0.5;
    label.fontSize(fontSize);
  }
  
  // Position: center of the shape
  label.x(shape.x());
  label.y(shape.y());
  
  // Flip Y for the inverted coordinate system
  label.scaleY(-1);
  
  if (isTall) {
    // Rotate 90° CCW so text reads bottom-to-top along the tall axis
    label.rotation(90);
    label.offsetX(label.width() / 2);
    label.offsetY(label.height() / 2);
  } else {
    label.rotation(0);
    label.offsetX(label.width() / 2);
    label.offsetY(label.height() / 2);
  }
  
  textLayer.add(label);
}

function addLabelToShape(shape) {
  if (shape.fill() !== 'gray') {
    console.log('Not a gray shape. Label tool only works on "other" elements.');
    return;
  }
  
  const entity = allMapEntities.find(item => item.id === shape.id());
  const currentText = entity ? entity.name : 'Label';
  
  const newText = window.prompt('Enter label text:', currentText);
  
  if (newText === null || newText.trim() === '') {
    console.log('Label cancelled or empty');
    return;
  }
  
  console.log(`Adding/updating label "${newText}" to shape ${shape.id()}`);
  
  if (entity) {
    entity.name = newText.trim();
  }

  const existingLabelId = shape.id() + "_label";
  const existingLabel = textLayer.findOne(`#${existingLabelId}`);
  
  if (existingLabel) {
    existingLabel.text(newText.trim());
    // Reposition using the same logic as addLabel
    updateLabelPosition(shape);
  } else {
    addLabel(shape, newText.trim(), existingLabelId, entity ? entity.type : null);
  }
  
  textLayer.batchDraw();
}

function drawNewItem(resource, position) {
  console.log(`  Placing ${resource.label} at world position (${position.x.toFixed(1)}, ${position.y.toFixed(1)})`);
  
  const size = equipmentSizes[resource.resourceType] || { l: 2, w: 2 };
  
  const mockItem = {
    id: resource.resourceId,
    name: resource.label,
    type: null,
    absTrans: {
      pt: {
        x: position.x / SCALE,
        y: position.y / SCALE
      }
    },
    lodGeomMap: {
      "1": { 
        s: { 
          type: 'rect',
          l: size.l,
          w: size.w
        } 
      }
    }
  };

  switch (resource.resourceType) {
    case 'STACKING_AREA':
      mockItem.type = 'stackingArea';
      drawArea(mockItem, false);
      break;
    case 'CHUTE':
      mockItem.type = 'chute';
      drawChute(mockItem);
      break;
    case 'GENERAL_AREA':
      mockItem.type = 'generalArea';
      drawArea(mockItem, true);
      break;
    case 'STAGING_AREA':
      mockItem.type = 'stagingArea';
      drawArea(mockItem, true);
      break;
    default:
      console.warn("Unknown resource type to draw:", resource.resourceType);
      return;
  }
  
  allMapEntities.push(mockItem);
  
  console.log(`✅ Drew ${resource.label} at (${position.x.toFixed(1)}, ${position.y.toFixed(1)})`);
  
  renderEditorTools();
}

// --- 7. Event Handlers ---

// API Testing Functions

// Domain-hopping mechanism
async function showLoadingOverlay(message = 'Loading...') {
  // Remove existing overlay if present
  if (domainHopState.loadingOverlay) {
    console.log('🗑️ Removing existing overlay');
    domainHopState.loadingOverlay.remove();
    domainHopState.loadingOverlay = null;
  }
  
  const overlay = document.createElement('div');
  overlay.id = 'domain-hop-overlay';
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.9);
    z-index: 9999999;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
  `;
  
  // Check if we're on stem and have a cat image
  const currentDomain = window.location.hostname;
  const isStem = currentDomain === 'stem-na.corp.amazon.com';
  
  console.log('🎨 showLoadingOverlay called');
  console.log('   Current domain:', currentDomain);
  console.log('   Is stem?', isStem);
  console.log('   Message:', message);
  
  let catImage = null;
  
  // If on stem, check chrome.storage for cat image
  if (isStem) {
    const result = await chrome.storage.local.get(['hopCatImage']);
    catImage = result.hopCatImage;
    console.log('   Cat image exists in chrome.storage?', !!catImage);
    console.log('   Cat image length:', catImage ? catImage.length : 0);
  }
  
  // Add keyframes animation to document head (not in overlay HTML)
  const styleId = 'loading-animation-style';
  if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
      @keyframes loading {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
      }
    `;
    document.head.appendChild(style);
  }
  
  if (isStem && catImage) {
    // Show cat on stem page
    console.log('🐱 Showing cat overlay on stem page!');
    overlay.innerHTML = `
      <div style="text-align: center; color: white; max-width: 600px; padding: 20px; margin: auto;">
        <h2 style="margin: 0 0 20px 0; font-size: 32px;">✨ Magic is happening ✨</h2>
        <p style="margin: 0 0 30px 0; font-size: 18px; opacity: 0.9;">Please enjoy this cat while you wait</p>
        <div style="border-radius: 12px; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.5); margin: 0 auto 30px auto; max-width: 500px;">
          <img src="${catImage}" style="width: 100%; height: auto; display: block;" alt="A cute cat">
        </div>
        <div style="margin-top: 20px;">
          <div style="font-size: 16px; opacity: 0.8; margin-bottom: 10px;">Fetching your map data...</div>
          <div style="width: 300px; height: 4px; background: rgba(255,255,255,0.2); border-radius: 2px; overflow: hidden; margin: 0 auto;">
            <div style="width: 100%; height: 100%; background: linear-gradient(90deg, #007bff, #00d4ff); animation: loading 1.5s infinite;"></div>
          </div>
        </div>
      </div>
    `;
  } else {
    // Regular loading overlay (not on stem or no cat)
    console.log('📦 Showing regular loading overlay');
    if (isStem && !catImage) {
      console.warn('⚠️ On stem but no cat image found in chrome.storage!');
    }
    overlay.innerHTML = `
      <div style="text-align: center; color: white;">
        <div style="font-size: 48px; margin-bottom: 20px;">🚀</div>
        <h2 style="margin: 0 0 10px 0;">${message}</h2>
        <div style="margin-top: 20px; width: 200px; height: 4px; background: rgba(255,255,255,0.2); border-radius: 2px; overflow: hidden; margin: 0 auto;">
          <div style="width: 100%; height: 100%; background: #007bff; animation: loading 1.5s infinite;"></div>
        </div>
      </div>
    `;
  }
  
  // Try to add to ryan-console-root first, fallback to body
  const ryanRoot = document.getElementById('ryan-console-root');
  if (ryanRoot) {
    console.log('✅ Adding overlay to ryan-console-root');
    ryanRoot.appendChild(overlay);
  } else {
    console.log('✅ Adding overlay to body');
    document.body.appendChild(overlay);
  }
  
  domainHopState.loadingOverlay = overlay;
  console.log('✅ Overlay added to DOM');
}

function hideLoadingOverlay() {
  if (domainHopState.loadingOverlay) {
    domainHopState.loadingOverlay.remove();
    domainHopState.loadingOverlay = null;
  }
}

function showErrorModal(message) {
  const backdrop = document.createElement('div');
  backdrop.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:9999999;';

  const modal = document.createElement('div');
  modal.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border:3px solid #dc3545;border-radius:10px;padding:0;min-width:380px;max-width:500px;z-index:10000000;box-shadow:0 8px 32px rgba(0,0,0,0.3);overflow:hidden;';

  modal.innerHTML = `
    <div style="background:#dc3545;color:#fff;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:nowrap;">
      <span style="font-weight:bold;font-size:16px;white-space:nowrap;">Error Occurred</span>
      <button id="error-modal-close" style="background:rgba(255,255,255,0.2);border:none;color:#fff;font-size:22px;cursor:pointer;line-height:1;padding:5px 10px;border-radius:3px;margin-left:auto;flex-shrink:0;">✕</button>
    </div>
    <div style="padding:25px 20px;text-align:center;">
      <p style="margin:0;font-size:15px;color:#333;">${message}</p>
    </div>
  `;

  const ryanRoot = document.getElementById('ryan-console-root');
  (ryanRoot || document.body).appendChild(backdrop);
  (ryanRoot || document.body).appendChild(modal);

  const close = () => { modal.remove(); backdrop.remove(); };
  modal.querySelector('#error-modal-close').addEventListener('click', close);
  backdrop.addEventListener('click', close);
}

async function initiateApiCallWithHop(apiType, nodeId) {
  const currentDomain = window.location.hostname;
  
  console.log('🚀 initiateApiCallWithHop called');
  console.log('   API Type:', apiType);
  console.log('   Node ID:', nodeId);
  console.log('   Current Domain:', currentDomain);
  
  // If already on API domain, just make the call directly
  if (currentDomain === 'stem-na.corp.amazon.com') {
    console.log('✅ Already on API domain, executing directly');
    if (apiType === 'api1') {
      await executeApiCall1(nodeId);
    } else {
      await executeApiCall2(nodeId);
    }
    return;
  }
  
  // Save state for domain hop
  const hopState = {
    apiType: apiType,
    nodeId: nodeId,
    returnUrl: window.location.href,
    timestamp: Date.now()
  };
  
  console.log('💾 Saving hop state:', hopState);
  localStorage.setItem('domainHopState', JSON.stringify(hopState));
  
  // Verify it was saved
  const saved = localStorage.getItem('domainHopState');
  console.log('✅ Hop state saved, verification:', saved);
  
  // Navigate to API domain with hash parameters (no loading overlay - will show on stem page)
  const hopParams = `#hop=${apiType}&node=${nodeId}&return=${encodeURIComponent(hopState.returnUrl)}&ts=${hopState.timestamp}`;
  const targetUrl = `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap${hopParams}`;
  
  console.log('🌐 Navigating to stem-na.corp.amazon.com with hop params...');
  console.log('🌐 Target URL:', targetUrl);
  
  setTimeout(() => {
    window.location.href = targetUrl;
  }, 100);
}

async function initiateApiCallBoth(nodeId) {
  const currentDomain = window.location.hostname;
  
  console.log('🚀 initiateApiCallBoth called - will fetch BOTH API calls');
  console.log('   Node ID:', nodeId);
  console.log('   Current Domain:', currentDomain);
  
  // If already on API domain, just make the calls directly
  if (currentDomain === 'stem-na.corp.amazon.com') {
    console.log('✅ Already on API domain, executing both calls directly');
    await executeApiCall1(nodeId);
    await executeApiCall2(nodeId);
    return;
  }
  
  // Preload a cat image before hopping
  console.log('🐱 Preloading cat image...');
  
  try {
    const catImageUrl = `https://cataas.com/cat?width=500&${Date.now()}`; // Add size limit and timestamp
    console.log('🐱 Fetching cat from:', catImageUrl);
    const response = await fetch(catImageUrl, { mode: 'cors' });
    console.log('🐱 Cat fetch response:', response.status, response.statusText);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch cat: ${response.status}`);
    }
    
    const blob = await response.blob();
    console.log('🐱 Cat blob size:', blob.size, 'bytes');
    
    // Convert to data URL for cross-domain storage
    const reader = new FileReader();
    const dataUrlPromise = new Promise((resolve, reject) => {
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
    });
    reader.readAsDataURL(blob);
    const catDataUrl = await dataUrlPromise;
    
    console.log('🐱 Cat data URL length:', catDataUrl.length);
    
    // Store cat image in chrome.storage (works across domains!)
    await chrome.storage.local.set({ 'hopCatImage': catDataUrl });
    console.log('✅ Cat image preloaded and stored in chrome.storage');
    
    // Verify it was stored
    const stored = await chrome.storage.local.get(['hopCatImage']);
    console.log('✅ Verified cat in chrome.storage:', stored.hopCatImage ? `${stored.hopCatImage.length} chars` : 'NOT FOUND');
  } catch (err) {
    console.error('❌ Failed to preload cat image:', err);
    console.error('❌ Error details:', err.message, err.stack);
    // Continue anyway - cat is optional
  }
  
  // Save state for domain hop
  const hopState = {
    apiType: 'both',  // Special type for both calls
    nodeId: nodeId,
    returnUrl: window.location.href,
    timestamp: Date.now()
  };
  
  console.log('💾 Saving hop state for BOTH calls:', hopState);
  localStorage.setItem('domainHopState', JSON.stringify(hopState));
  
  // Navigate to API domain with hash parameters (no loading overlay - will show on stem page)
  const hopParams = `#hop=both&node=${nodeId}&return=${encodeURIComponent(hopState.returnUrl)}&ts=${hopState.timestamp}`;
  const targetUrl = `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap${hopParams}`;
  
  console.log('🌐 Navigating to stem-na.corp.amazon.com to fetch both API calls...');
  console.log('🌐 Target URL:', targetUrl);
  
  setTimeout(() => {
    window.location.href = targetUrl;
  }, 100);
}

// Function to initiate map data fetch via domain hop
async function initiateMapDataHop(nodeId) {
  console.log('🗺️ Initiating map data hop for node:', nodeId);
  await initiateApiCallBoth(nodeId);
}

// Trim map entity data to only the fields we need, reducing chrome.storage size
function trimMapEntityData(apiData, mapStringPath) {
  try {
    const innerString = mapStringPath(apiData);
    if (!innerString) return null;
    
    const innerMap = JSON.parse(innerString);
    const entities = innerMap.e || [];
    
    // Ultra-compact: short keys, minimal data
    const trimmed = entities
      .filter(e => e.type !== 'wirelessAccessPoint')
      .map(e => {
        const slim = {
          id: e.id,
          n: e.name,
          t: e.type,
          x: e.absTrans?.pt?.x,
          y: e.absTrans?.pt?.y
        };
        if (e.lodGeomMap && e.lodGeomMap[1] && e.lodGeomMap[1].s) {
          const s = e.lodGeomMap[1].s;
          slim.s = {};
          if (s.l !== undefined) slim.s.l = s.l;
          if (s.w !== undefined) slim.s.w = s.w;
          if (s.x !== undefined) slim.s.x = s.x;
          if (s.y !== undefined) slim.s.y = s.y;
          if (s.pts) slim.s.pts = s.pts;
          if (s.type) slim.s.type = s.type;
        }
        return slim;
      });
    
    // Return just the trimmed array as JSON — no wrapper object
    return JSON.stringify({ e: trimmed });
  } catch (err) {
    console.warn('⚠️ Failed to trim map data, storing raw:', err);
    return null;
  }
}

async function executeApiCall1(nodeId) {
  const resultDiv = document.getElementById('api-result-1');
  if (resultDiv) {
    resultDiv.innerHTML = '<p style="color: #666;">Making API call...</p>';
  }
  
  try {
    // Extract CSRF token from multiple possible locations
    let csrfToken = null;
    
    // PRIORITY 1: Try the hidden input field (most reliable)
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) {
      csrfToken = tokenInput.value;
      console.log('✅ Found CSRF token in hidden input __token_:', csrfToken);
    }
    
    // PRIORITY 2: Try the meta tag
    if (!csrfToken) {
      let csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) {
        csrfToken = csrfMeta.getAttribute('content');
        console.log('✅ Found CSRF token in tcp-header-csrf-token meta tag:', csrfToken);
      }
    }
    
    // PRIORITY 3: Try alternative meta tag
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) {
        csrfToken = csrfMeta.getAttribute('content');
        console.log('✅ Found CSRF token in anti-csrftoken-a2z meta tag:', csrfToken);
      }
    }
    
    // PRIORITY 4: Try cookie
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          console.log('✅ Found CSRF token in cookie:', csrfToken);
          break;
        }
      }
    }
    
    // PRIORITY 5: Try to find it in page scripts/data
    if (!csrfToken) {
      const scripts = document.querySelectorAll('script');
      for (let script of scripts) {
        const content = script.textContent;
        const match = content.match(/csrfToken['":\s]+['"]([^'"]+)['"]/i);
        if (match) {
          csrfToken = match[1];
          console.log('✅ Found CSRF token in script:', csrfToken);
          break;
        }
      }
    }
    
    if (!csrfToken) {
      console.warn('⚠️ No CSRF token found - API call may fail');
    }
    
    const headers = { 
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    
    if (csrfToken) {
      headers['anti-csrftoken-a2z'] = csrfToken;
      console.log('🔐 Added CSRF token to anti-csrftoken-a2z header');
    }
    
    console.log('📤 Making API call with headers:', headers);
    
    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "DigitalTwin2dMap",
        variables: { nodeId: nodeId },
        query: "query DigitalTwin2dMap($nodeId: String!) {\n  digitalTwin2dMap(nodeId: $nodeId)\n}\n"
      }])
    });
    
    console.log('📥 Response status:', response.status, response.statusText);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Response error:', errorText);
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }
    
    const data = await response.json();
    
    // Trim map data before storing to stay within chrome.storage quota
    const trimmedMap = trimMapEntityData(data, d => d[0]?.data?.digitalTwin2dMap);
    const storableData = JSON.parse(JSON.stringify(data));
    if (trimmedMap && storableData[0]?.data) {
      storableData[0].data.digitalTwin2dMap = trimmedMap;
    }
    
    const result = {
      success: true,
      data: storableData,
      timestamp: Date.now()
    };
    
    console.log('💾 Saving trimmed result to chrome.storage with key: apiResult1_' + nodeId);
    await chrome.storage.local.set({ [`apiResult1_${nodeId}`]: result });
    console.log('✅ Result saved to chrome.storage');
    
    if (resultDiv) {
      resultDiv.innerHTML = `<div style="color: green;"><strong>✅ Success!</strong><pre>${JSON.stringify(data, null, 2)}</pre></div>`;
    }
    
    return data;
  } catch (error) {
    console.error('❌ API call failed:', error);
    
    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };
    
    console.log('💾 Saving error to chrome.storage...');
    await chrome.storage.local.set({ [`apiResult1_${nodeId}`]: errorResult });
    
    if (resultDiv) {
      resultDiv.innerHTML = `<div style="color: red;"><strong>❌ Error:</strong><p>${error.message}</p></div>`;
    }
    
    throw error;
  }
}

async function executeApiCall2(nodeId) {
  const resultDiv = document.getElementById('api-result-2');
  if (resultDiv) {
    resultDiv.innerHTML = '<p style="color: #666;">Making API call...</p>';
  }
  
  try {
    // Extract CSRF token from multiple possible locations
    let csrfToken = null;
    
    // PRIORITY 1: Try the hidden input field (most reliable)
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) {
      csrfToken = tokenInput.value;
      console.log('✅ Found CSRF token in hidden input __token_:', csrfToken);
    }
    
    // PRIORITY 2: Try the meta tag
    if (!csrfToken) {
      let csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) {
        csrfToken = csrfMeta.getAttribute('content');
        console.log('✅ Found CSRF token in tcp-header-csrf-token meta tag:', csrfToken);
      }
    }
    
    // PRIORITY 3: Try alternative meta tag
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) {
        csrfToken = csrfMeta.getAttribute('content');
        console.log('✅ Found CSRF token in anti-csrftoken-a2z meta tag:', csrfToken);
      }
    }
    
    // PRIORITY 4: Try cookie
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          console.log('✅ Found CSRF token in cookie:', csrfToken);
          break;
        }
      }
    }
    
    // PRIORITY 5: Try to find it in page scripts/data
    if (!csrfToken) {
      const scripts = document.querySelectorAll('script');
      for (let script of scripts) {
        const content = script.textContent;
        const match = content.match(/csrfToken['":\s]+['"]([^'"]+)['"]/i);
        if (match) {
          csrfToken = match[1];
          console.log('✅ Found CSRF token in script:', csrfToken);
          break;
        }
      }
    }
    
    if (!csrfToken) {
      console.warn('⚠️ No CSRF token found - API call may fail');
    }
    
    const headers = { 
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    
    if (csrfToken) {
      headers['anti-csrftoken-a2z'] = csrfToken;
      console.log('🔐 Added CSRF token to anti-csrftoken-a2z header');
    }
    
    console.log('📤 Making API call with headers:', headers);
    
    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "MapDeployment",
        variables: {
          deploymentInput: {
            nodeId: nodeId,
            deploymentToFetch: "LATEST"
          }
        },
        query: "query MapDeployment($deploymentInput: DigitalTwin2dMapDeploymentInput!) {\n  mapDeployment(deploymentInput: $deploymentInput) {\n    mapRevision\n    createdBy\n    createdOn\n    mapContents\n    __typename\n  }\n}\n"
      }])
    });
    
    console.log('📥 Response status:', response.status, response.statusText);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Response error:', errorText);
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }
    
    const data = await response.json();
    
    // Trim map data before storing to stay within chrome.storage quota
    const trimmedMap = trimMapEntityData(data, d => d[0]?.data?.mapDeployment?.mapContents);
    const storableData = JSON.parse(JSON.stringify(data));
    if (trimmedMap && storableData[0]?.data?.mapDeployment) {
      storableData[0].data.mapDeployment.mapContents = trimmedMap;
    }
    
    const result = {
      success: true,
      data: storableData,
      timestamp: Date.now()
    };
    
    console.log('💾 Saving trimmed result to chrome.storage with key: apiResult2_' + nodeId);
    await chrome.storage.local.set({ [`apiResult2_${nodeId}`]: result });
    console.log('✅ Result saved to chrome.storage');
    
    if (resultDiv) {
      resultDiv.innerHTML = `<div style="color: green;"><strong>✅ Success!</strong><pre>${JSON.stringify(data, null, 2)}</pre></div>`;
    }
    
    return data;
  } catch (error) {
    console.error('❌ API call failed:', error);
    
    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };
    
    console.log('💾 Saving error to chrome.storage...');
    await chrome.storage.local.set({ [`apiResult2_${nodeId}`]: errorResult });
    
    if (resultDiv) {
      resultDiv.innerHTML = `<div style="color: red;"><strong>❌ Error:</strong><p>${error.message}</p></div>`;
    }
    
    throw error;
  }
}

async function executeApiCall3(nodeId) {
  try {
    let csrfToken = null;
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) {
      csrfToken = tokenInput.value;
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          break;
        }
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    if (csrfToken) {
      headers['anti-csrftoken-a2z'] = csrfToken;
    }

    console.log('📤 Making Resources API call for node:', nodeId);

    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "Resources",
        variables: { nodeId: nodeId },
        query: "query Resources($nodeId: String!) {\n  resources(nodeId: $nodeId) {\n    __typename\n    resourceId\n    resourceType\n    label\n    status\n    resourceAttributes {\n      __typename\n      key\n      value\n    }\n    userLogin\n    lastUpdateTime\n    resourceGroup\n  }\n}\n"
      }])
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }

    const data = await response.json();

    // Trim to only the fields we need to stay within chrome.storage quota
    const fullResources = data[0]?.data?.resources || [];
    const trimmedResources = fullResources.map(r => ({
      resourceId: r.resourceId,
      resourceType: r.resourceType,
      label: r.label,
      status: r.status
    }));

    const result = {
      success: true,
      data: [{ data: { resources: trimmedResources } }],
      timestamp: Date.now()
    };

    console.log(`💾 Saving result to chrome.storage with key: apiResult3_${nodeId} (${trimmedResources.length} resources, trimmed)`);
    await chrome.storage.local.set({ [`apiResult3_${nodeId}`]: result });
    console.log('✅ Resources API call completed');

    return data;
  } catch (error) {
    console.error('❌ Resources API call failed:', error);

    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [`apiResult3_${nodeId}`]: errorResult });
    throw error;
  }
}

async function executeApiCall4(nodeId) {
  try {
    let csrfToken = null;
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) {
      csrfToken = tokenInput.value;
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          break;
        }
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    if (csrfToken) {
      headers['anti-csrftoken-a2z'] = csrfToken;
    }

    console.log('📤 Making Reservations API call for node:', nodeId);

    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "Reservations",
        variables: { nodeId: nodeId, cached: true },
        query: "query Reservations($nodeId: String!, $cached: Boolean!) {\n  reservations(nodeId: $nodeId, cached: $cached) {\n    __typename\n    reservationId\n    stackingFilters\n    startTime\n    endTime\n    lastUpdateTime\n    userLogin\n    reservationProperties {\n      __typename\n      key\n      value\n    }\n    resources {\n      __typename\n      resourceId\n      label\n      resourceType\n    }\n  }\n}\n"
      }])
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }

    const data = await response.json();

    // Trim aggressively: only keep what buildStackingFilterMap needs (label + filters)
    // Skip reservations with no stacking filters — they're useless for the map
    const reservations = data[0]?.data?.reservations || [];
    const trimmed = reservations
      .filter(r => r.stackingFilters && r.stackingFilters.length > 0)
      .map(r => ({
        stackingFilters: r.stackingFilters,
        resources: (r.resources || []).map(res => ({ label: res.label }))
      }));

    const result = {
      success: true,
      data: trimmed,
      timestamp: Date.now()
    };

    console.log(`💾 Saving result to chrome.storage with key: apiResult4_${nodeId} (${trimmed.length} reservations, trimmed)`);
    await chrome.storage.local.set({ [`apiResult4_${nodeId}`]: result });
    console.log('✅ Reservations API call completed');

    return data;
  } catch (error) {
    console.error('❌ Reservations API call failed:', error);

    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [`apiResult4_${nodeId}`]: errorResult });
    throw error;
  }
}

// Build a lookup: resource label -> array of stacking filter strings
function buildStackingFilterMap(reservations) {
  stackingFilterMap = {};
  reservations.forEach(r => {
    const filters = r.stackingFilters || [];
    (r.resources || []).forEach(res => {
      if (!stackingFilterMap[res.label]) {
        stackingFilterMap[res.label] = [];
      }
      filters.forEach(f => {
        if (!stackingFilterMap[res.label].includes(f)) {
          stackingFilterMap[res.label].push(f);
        }
      });
    });
  });
  console.log('✅ Stacking filter map built:', Object.keys(stackingFilterMap).length, 'resources mapped');
}

async function executeApiCall5(nodeId) {
  try {
    let csrfToken = null;
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) csrfToken = tokenInput.value;
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          break;
        }
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    if (csrfToken) headers['anti-csrftoken-a2z'] = csrfToken;

    console.log('📤 Making VSM API call for node:', nodeId);

    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "VisualSortationMarkerBatches",
        variables: { nodeId: nodeId },
        query: "query VisualSortationMarkerBatches($nodeId: String!) {\n  visualSortationMarkerBatches(nodeId: $nodeId) {\n    __typename\n    flattenedStackingFiltersToMarkers {\n      __typename\n      stackingFilter\n      marker\n    }\n    vsmBatchStartTimeInMillis\n    vsmBatchEndTimeInMillis\n    reservationBatchLabel\n    status\n    userLogin\n    reservationBatchId\n    reservationBatchType\n  }\n}\n"
      }])
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }

    const data = await response.json();

    // Trim: only keep the stacking filter -> marker mappings (short keys)
    const batches = data[0]?.data?.visualSortationMarkerBatches || [];
    const trimmed = [];
    // Deduplicate into a direct lookup object (stackingFilter -> marker)
    // This is MUCH smaller than storing 4786+ individual {s, m} objects
    const vsmLookup = {};
    batches.forEach(batch => {
      (batch.flattenedStackingFiltersToMarkers || []).forEach(m => {
        if (m.stackingFilter && !vsmLookup[m.stackingFilter]) {
          vsmLookup[m.stackingFilter] = m.marker;
        }
      });
    });

    const result = {
      success: true,
      data: vsmLookup,
      timestamp: Date.now()
    };

    const entryCount = Object.keys(vsmLookup).length;
    console.log(`💾 Saving result to chrome.storage with key: apiResult5_${nodeId} (${entryCount} unique VSM mappings, deduplicated)`);
    await chrome.storage.local.set({ [`apiResult5_${nodeId}`]: result });
    console.log('✅ VSM API call completed');

    return data;
  } catch (error) {
    console.error('❌ VSM API call failed:', error);

    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [`apiResult5_${nodeId}`]: errorResult });
    throw error;
  }
}

// Build a lookup: stacking filter string -> VSM marker
function buildVsmMap(data) {
  vsmMap = {};
  if (Array.isArray(data)) {
    // Legacy array format: [{s, m}, ...]
    data.forEach(m => {
      const sf = m.s || m.stackingFilter;
      const mk = m.m || m.marker;
      if (sf && !vsmMap[sf]) vsmMap[sf] = mk;
    });
  } else if (data && typeof data === 'object') {
    // New deduplicated object format: { stackingFilter: marker, ... }
    Object.assign(vsmMap, data);
  }
  console.log('✅ VSM map built:', Object.keys(vsmMap).length, 'stacking filters mapped to markers');
}

async function executeApiCall6(nodeId) {
  try {
    let csrfToken = null;
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) csrfToken = tokenInput.value;
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          break;
        }
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    if (csrfToken) headers['anti-csrftoken-a2z'] = csrfToken;

    console.log('📤 Making Connected Resources API call for node:', nodeId);

    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "GetAllConnectedResources",
        variables: { nodeId: nodeId },
        query: "query GetAllConnectedResources($nodeId: String!) {\n  getAllConnectedResources(nodeId: $nodeId) {\n    __typename\n    chuteId\n    resources {\n      __typename\n      resourceId\n      resourceType\n      label\n      resourceAttributes {\n        __typename\n        key\n        value\n      }\n    }\n  }\n}\n"
      }])
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }

    const data = await response.json();

    // Trim aggressively: only keep what buildChuteConnectionMap needs
    const connections = data[0]?.data?.getAllConnectedResources || [];
    const trimmed = connections.map(conn => {
      const resources = (conn.resources || [])
        .filter(res => res.resourceType === 'STACKING_AREA')
        .map(res => {
          let co = null, wz = null;
          (res.resourceAttributes || []).forEach(a => {
            if (a.key === 'containerizeOption') co = a.value;
            else if (a.key === 'WaterspiderZone') wz = a.value;
          });
          return { l: res.label, c: co, w: wz };
        });
      return { id: conn.chuteId, r: resources };
    });

    const result = {
      success: true,
      data: trimmed,
      timestamp: Date.now()
    };

    console.log(`💾 Saving result to chrome.storage with key: apiResult6_${nodeId} (${trimmed.length} chute connections, trimmed)`);
    await chrome.storage.local.set({ [`apiResult6_${nodeId}`]: result });
    console.log('✅ Connected Resources API call completed');

    return data;
  } catch (error) {
    console.error('❌ Connected Resources API call failed:', error);

    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [`apiResult6_${nodeId}`]: errorResult });
    throw error;
  }
}

// Build lookup: stacking area label -> { chutes, containerizeOption, waterspiderZone }
function buildChuteConnectionMap(connections) {
  chuteConnectionMap = {};
  chuteToStackingMap = {};
  connections.forEach(conn => {
    (conn.r || []).forEach(res => {
      if (!chuteConnectionMap[res.l]) {
        chuteConnectionMap[res.l] = { chutes: [], containerizeOption: null, waterspiderZone: null };
      }
      const entry = chuteConnectionMap[res.l];
      if (!entry.chutes.includes(conn.id)) {
        entry.chutes.push(conn.id);
      }
      if (res.c) entry.containerizeOption = res.c;
      if (res.w) entry.waterspiderZone = res.w;
      // Build reverse lookup: chute -> stacking areas
      if (!chuteToStackingMap[conn.id]) {
        chuteToStackingMap[conn.id] = [];
      }
      if (!chuteToStackingMap[conn.id].includes(res.l)) {
        chuteToStackingMap[conn.id].push(res.l);
      }
    });
  });
  console.log('✅ Chute connection map built:', Object.keys(chuteConnectionMap).length, 'stacking areas mapped');
  console.log('✅ Chute-to-stacking map built:', Object.keys(chuteToStackingMap).length, 'chutes mapped');
}

async function executeApiCall7(nodeId) {
  try {
    let csrfToken = null;
    const tokenInput = document.querySelector('input[name="__token_"]');
    if (tokenInput) csrfToken = tokenInput.value;
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="tcp-header-csrf-token"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const csrfMeta = document.querySelector('meta[name="anti-csrftoken-a2z"]');
      if (csrfMeta) csrfToken = csrfMeta.getAttribute('content');
    }
    if (!csrfToken) {
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'anti-csrftoken-a2z' || name.includes('csrf')) {
          csrfToken = value;
          break;
        }
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      'Accept': '*/*',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin'
    };
    if (csrfToken) headers['anti-csrftoken-a2z'] = csrfToken;

    console.log('📤 Making Connected Chutes API call for node:', nodeId);

    const response = await fetch('https://stem-na.corp.amazon.com/sortcenter/equipmentmanagement/graphql', {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      referrer: `https://stem-na.corp.amazon.com/node/${nodeId}/2DMap`,
      body: JSON.stringify([{
        operationName: "GetAllConnectedChutes",
        variables: { nodeId: nodeId },
        query: "query GetAllConnectedChutes($nodeId: String!) {\n  getAllConnectedChutes(nodeId: $nodeId) {\n    __typename\n    sorterToChutesConnection {\n      __typename\n      sorterId\n      chutes {\n        __typename\n        id\n        label\n        attributes {\n          __typename\n          key\n          value\n        }\n      }\n    }\n  }\n}\n"
      }])
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
    }

    const data = await response.json();

    // Flatten all chutes across sorters, keep id, label, status, and sorterId
    const sorters = data[0]?.data?.getAllConnectedChutes?.sorterToChutesConnection || [];
    const trimmed = [];
    sorters.forEach(s => {
      (s.chutes || []).forEach(c => {
        const status = (c.attributes || []).find(a => a.key === 'Status');
        trimmed.push({ id: c.id, label: c.label, sorterId: s.sorterId, status: status?.value || null });
      });
    });

    const result = {
      success: true,
      data: trimmed,
      timestamp: Date.now()
    };

    console.log(`💾 Saving result to chrome.storage with key: apiResult7_${nodeId} (${trimmed.length} chutes, trimmed)`);
    await chrome.storage.local.set({ [`apiResult7_${nodeId}`]: result });
    console.log('✅ Connected Chutes API call completed');

    return data;
  } catch (error) {
    console.error('❌ Connected Chutes API call failed:', error);

    const errorResult = {
      success: false,
      error: error.message,
      timestamp: Date.now()
    };

    await chrome.storage.local.set({ [`apiResult7_${nodeId}`]: errorResult });
    throw error;
  }
}


// Build lookup: chute short label -> full chuteId
function buildChuteLabelMap(chutes) {
  chuteLabelToIdMap = {};
  chutes.forEach(c => {
    // Primary: exact label match
    chuteLabelToIdMap[c.label] = c.id;
    // Secondary: extract short suffix after last "->" for nodes like BWI5
    // e.g. "BWI5->BWI5-ShippingSorter3->S0352" → key "S0352"
    if (c.label && c.label.includes('->')) {
      const shortName = c.label.split('->').pop();
      if (shortName && !chuteLabelToIdMap[shortName]) {
        chuteLabelToIdMap[shortName] = c.id;
      }
    }
  });
  console.log('✅ Chute label map built:', Object.keys(chuteLabelToIdMap).length, 'entries (including short suffixes)');
}

// Fetch inbound dock view and export to Excel (CSV)
async function fetchInboundAndExport(nodeId) {
  const resultDiv = document.getElementById('api-result-inbound');
  if (resultDiv) resultDiv.innerHTML = '<p style="color: #666;">Fetching inbound data...</p>';

  try {
    const response = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include',
      body: `entity=getPrioritizedInboundDockView&nodeId=${encodeURIComponent(nodeId)}&isILPRankGroupingEnabled=true`
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    const json = await response.json();
    const rows = json?.ret?.aaData || [];

    if (rows.length === 0) {
      if (resultDiv) resultDiv.innerHTML = '<p style="color: orange;">No inbound data returned.</p>';
      return;
    }

    // Build CSV
    const columns = [
      { header: 'VR ID', get: r => r.load?.vrId },
      { header: 'Status', get: r => r.load?.status },
      { header: 'Route', get: r => r.load?.route },
      { header: 'Carrier', get: r => r.load?.carrier },
      { header: 'Carrier Group', get: r => r.load?.carrierGroup },
      { header: 'Sub Carrier', get: r => r.load?.subCarrier },
      { header: 'Equipment Type', get: r => r.load?.equipmentType },
      { header: 'Scheduled Arrival', get: r => r.load?.scheduledArrivalTime },
      { header: 'Actual Arrival', get: r => r.load?.actualArrivalTime },
      { header: 'Scheduled Departure', get: r => r.load?.scheduledDepartureTime },
      { header: 'Actual Departure', get: r => r.load?.actualDepartureTime },
      { header: 'SPT Start', get: r => r.load?.sptStartDisplay },
      { header: 'SPT End', get: r => r.load?.sptEndDisplay },
      { header: 'Ranking', get: r => r.load?.ranking },
      { header: 'Priority', get: r => r.priority },
      { header: 'Time Slot', get: r => r.load?.timeSlot },
      { header: 'Dwell Time (min)', get: r => r.load?.dwellTime },
      { header: 'Business Type', get: r => r.load?.businessType },
      { header: 'Facility', get: r => r.load?.facilityId },
      { header: 'Cross Dock', get: r => r.load?.isCrossDock },
      { header: 'Demand Intents', get: r => (r.load?.demandIntents || []).join('; ') },
      { header: 'Shipping Purpose', get: r => r.load?.shippingPurposeType },
      { header: 'Dock Door', get: r => (r.resource || []).map(res => res.label).join('; ') },
      { header: 'TDR Status', get: r => (r.resource || []).map(res => res.tdrStatus).join('; ') },
      { header: 'Trailer Number', get: r => r.trailer?.trailerNumber },
      { header: 'Trailer Location', get: r => r.trailer?.location },
      { header: 'Late Arrival', get: r => r.load?.alertStatus?.isLateArrival },
      { header: 'Late Arrival Risk', get: r => r.load?.alertStatus?.isInboundLateArrivalRisk },
      { header: 'Dwelling', get: r => r.load?.alertStatus?.isInboundDwelling },
      { header: 'Late Departing', get: r => r.load?.alertStatus?.isLateDeparting },
      { header: 'Seal ID', get: r => r.load?.sealId },
      { header: 'Plan ID', get: r => r.load?.planId },
      { header: 'Last Update', get: r => r.load?.lastUpdateTime }
    ];

    const esc = v => {
      if (v == null || v === '') return '';
      const s = String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };

    let csv = columns.map(c => esc(c.header)).join(',') + '\n';
    rows.forEach(row => {
      csv += columns.map(c => esc(c.get(row))).join(',') + '\n';
    });

    // Trigger download
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inbound_${nodeId}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (resultDiv) resultDiv.innerHTML = `<p style="color: green;">✅ Exported ${rows.length} inbound loads to CSV.</p>`;
    console.log(`✅ Inbound export complete: ${rows.length} rows`);
  } catch (error) {
    console.error('❌ Inbound fetch failed:', error);
    if (resultDiv) resultDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

// Fetch full raw inbound dock view and export ALL fields to Excel (CSV)
async function fetchFullRawInboundAndExport(nodeId, startDate, endDate) {
  const resultDiv = document.getElementById('api-result-fullraw');
  if (resultDiv) resultDiv.innerHTML = '<p style="color: #666;">Fetching full raw inbound data...</p>';

  try {
    const loadCategories = 'inboundScheduled,inboundArrived,inboundCompleted';
    const shippingPurposeType = 'TRANSSHIPMENT,NON-TRANSSHIPMENT,SHIP_WITH_AMAZON';

    const body = [
      `entity=getInboundDockView`,
      `nodeId=${encodeURIComponent(nodeId)}`,
      `startDate=${startDate}`,
      `endDate=${endDate}`,
      `loadCategories=${encodeURIComponent(loadCategories)}`,
      `shippingPurposeType=${encodeURIComponent(shippingPurposeType)}`
    ].join('&');

    console.log('📤 POST body:', body);

    const response = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include',
      body: body
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    const json = await response.json();
    const rows = json?.ret?.aaData || [];

    if (rows.length === 0) {
      if (resultDiv) resultDiv.innerHTML = '<p style="color: orange;">No inbound data returned.</p>';
      return;
    }

    // Collect every unique key path across all rows to build columns dynamically
    const keySet = new Set();
    const getValue = (obj, path) => {
      let cur = obj;
      for (const k of path) {
        if (cur == null) return '';
        cur = cur[k];
      }
      if (cur == null) return '';
      if (Array.isArray(cur)) return cur.map(v => typeof v === 'object' ? JSON.stringify(v) : String(v)).join('; ');
      if (typeof cur === 'object') return JSON.stringify(cur);
      return String(cur);
    };

    const walk = (obj, prefix) => {
      if (obj == null || typeof obj !== 'object') return;
      if (Array.isArray(obj)) {
        // For arrays of primitives or objects, store as a single flattened column
        keySet.add(prefix.join('.'));
        return;
      }
      for (const key of Object.keys(obj)) {
        const child = obj[key];
        const path = [...prefix, key];
        if (child != null && typeof child === 'object' && !Array.isArray(child)) {
          walk(child, path);
        } else {
          keySet.add(path.join('.'));
        }
      }
    };

    rows.forEach(row => walk(row, []));

    // Sort columns for consistent ordering — group by top-level key
    const columns = Array.from(keySet).sort((a, b) => {
      const pa = a.split('.');
      const pb = b.split('.');
      // Sort by top-level group first, then by sub-key
      if (pa[0] !== pb[0]) return pa[0].localeCompare(pb[0]);
      return a.localeCompare(b);
    });

    const esc = v => {
      if (v == null || v === '') return '';
      const s = String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };

    let csv = columns.map(c => esc(c)).join(',') + '\n';
    rows.forEach(row => {
      csv += columns.map(col => {
        const path = col.split('.');
        return esc(getValue(row, path));
      }).join(',') + '\n';
    });

    // Trigger download
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inbound_fullraw_${nodeId}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (resultDiv) resultDiv.innerHTML = `<p style="color: green;">✅ Exported ${rows.length} rows × ${columns.length} columns to CSV.</p>`;
    console.log(`✅ Full raw inbound export complete: ${rows.length} rows, ${columns.length} columns`);
  } catch (error) {
    console.error('❌ Full raw inbound fetch failed:', error);
    if (resultDiv) resultDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

// ==================== FULL INBOUND PIPELINE ====================
// Dock View → Container Hierarchy → Tantei, merged into one CSV
async function runFullInboundPipeline(nodeId, startDate, endDate) {
  const resultDiv = document.getElementById('api-result-pipeline');
  const status = msg => { if (resultDiv) resultDiv.innerHTML = `<p style="color: #666;">${msg}</p>`; };

  try {
    // ── Step 1: Inbound Dock View (getInboundDockView with date range) ──
    status('Step 1/3: Fetching inbound dock view...');
    const loadCategories = 'inboundScheduled,inboundArrived,inboundCompleted';
    const shippingPurposeType = 'TRANSSHIPMENT,NON-TRANSSHIPMENT,SHIP_WITH_AMAZON';
    const ibBody = [
      `entity=getInboundDockView`,
      `nodeId=${encodeURIComponent(nodeId)}`,
      `startDate=${startDate}`,
      `endDate=${endDate}`,
      `loadCategories=${encodeURIComponent(loadCategories)}`,
      `shippingPurposeType=${encodeURIComponent(shippingPurposeType)}`
    ].join('&');

    const ibResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include',
      body: ibBody
    });
    if (!ibResp.ok) throw new Error(`Inbound fetch HTTP ${ibResp.status}`);
    const ibJson = await ibResp.json();
    const loads = ibJson?.ret?.aaData || [];

    if (loads.length === 0) {
      status('⚠️ No inbound loads found for this date range.');
      return;
    }
    console.log(`📦 Step 1 done: ${loads.length} loads`);

    // ── Step 2: Container Hierarchy for each load ──
    // packagesByVrid: { vrId -> [ {label, containerId, containerType, length, width, height, weight} ] }
    const packagesByVrid = {};
    const loadInfoByVrid = {};
    let completed = 0;

    for (const entry of loads) {
      const planId = entry.load?.planId;
      const vrId = entry.load?.vrId || '';
      if (!planId || !vrId) { completed++; continue; }

      loadInfoByVrid[vrId] = {
        route: entry.load?.route || '',
        status: entry.load?.status || '',
        carrier: entry.load?.carrier || '',
        carrierGroup: entry.load?.carrierGroup || '',
        equipmentType: entry.load?.equipmentType || '',
        scheduledArrivalTime: entry.load?.scheduledArrivalTime || '',
        actualArrivalTime: entry.load?.actualArrivalTime || '',
        dockDoor: (entry.resource || []).map(r => r.label).join('; '),
        planId
      };

      status(`Step 2/3: Fetching containers ${++completed}/${loads.length} (${vrId})...`);

      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const cResp = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
              'Accept': 'application/json, text/javascript, */*; q=0.01',
              'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'include',
            body: `entity=getInboundLoadContainerHierarchy&inboundLoadId=${encodeURIComponent(planId)}&nodeId=${encodeURIComponent(nodeId)}&containerStatus=InTrailer`
          });
          if (cResp.status === 429) {
            const wait = 2000 * (attempt + 1);
            console.warn(`⏳ Container 429 for ${vrId}, retry in ${wait}ms`);
            status(`Step 2/3: Rate limited on ${vrId} — waiting ${Math.round(wait/1000)}s...`);
            await new Promise(r => setTimeout(r, wait));
            continue;
          }
          if (!cResp.ok) break;
          const cJson = await cResp.json();
          const children = cJson?.ret?.aaData?.[0]?.hierarchy?.childContainers || [];

          if (children.length > 0) {
            packagesByVrid[vrId] = children.map(child => {
              const c = child.container || {};
              const props = c.properties || {};
              let length = '', width = '', height = '', weight = '';
              try { const b = JSON.parse(props.BOXED_SIZE || '{}'); length = b.length?.value || ''; width = b.width?.value || ''; height = b.height?.value || ''; } catch(e){}
              try { const w = JSON.parse(props.WEIGHT || '{}'); weight = w.weight?.value || ''; } catch(e){}
              return {
                containerType: c.containerType || '',
                label: c.label || '',
                containerId: c.containerId || '',
                length, width, height, weight
              };
            });
          }
          break; // success, exit retry loop
        } catch (err) {
          console.warn(`⚠️ Container fetch failed for ${vrId} (attempt ${attempt+1}):`, err.message);
          if (attempt < 2) await new Promise(r => setTimeout(r, 1000));
        }
      }
    }

    const vridsWithPackages = Object.keys(packagesByVrid);
    console.log(`📋 Step 2 done: ${vridsWithPackages.length} VRIDs have children`);

    if (vridsWithPackages.length === 0) {
      status('⚠️ No VRIDs with packages found. Nothing to send to Tantei.');
      return;
    }

    // Separate direct packages from nested containers (carts, pallets, gaylords, bags)
    const NESTED_PREFIXES = ['CART_', 'PALLET_', 'GAYLORD_', 'BAG_'];
    const isNestedContainer = label => NESTED_PREFIXES.some(p => label.toUpperCase().startsWith(p));

    // nestedContainerLabels: labels we need to search in Tantei to get their child packages
    const nestedContainerLabels = [];
    // Track which VRID each nested container belongs to
    const nestedToVrid = {}; // containerLabel -> vrId

    for (const vrId of vridsWithPackages) {
      for (const pkg of packagesByVrid[vrId]) {
        if (isNestedContainer(pkg.label)) {
          nestedContainerLabels.push(pkg.label);
          nestedToVrid[pkg.label] = vrId;
        }
      }
    }
    console.log(`📦 Found ${nestedContainerLabels.length} nested containers to drill into`);

    // ── Step 3: Tantei for VRIDs + nested containers ──
    status(`Step 3/4: Fetching CSRF token for Tantei...`);

    const csrfResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'fetchTanteiCSRF', nodeId }, (response) => {
        if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
        else if (!response) resolve({ success: false, error: 'No response from background script' });
        else resolve(response);
      });
    });
    if (!csrfResult.success) throw new Error('Tantei CSRF failed: ' + csrfResult.error);
    const csrfToken = csrfResult.token;

    const graphqlQuery = `
query ($queryInput: [SearchTermInput!]!, $startIndex: String) {
  searchEntities(searchTerms: $queryInput) {
    searchTerm { nodeId nodeTimezone searchId searchIdType resolvedIdType }
    contents(pageSize: 60, startIndex: $startIndex, forwardNavigate: true) {
      contents {
        containerId containerLabel containerType stackingFilter
        criticalPullTime isEmpty isClosed isForcedMove
        associationReason associatedUser timeOfAssociation cleanupAllowed
      }
      endToken
    }
  }
}`;

    const BATCH_SIZE = 5;
    const BATCH_DELAY = 300;
    const PAGE_DELAY = 200;
    const RETRY_DELAY = 2000;
    const MAX_RETRIES = 5;
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    async function gqlRequest(variables) {
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        const res = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'tanteiGraphQL', csrfToken, query: graphqlQuery, variables, nodeId }, (r) => {
            if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
            else if (!r) resolve({ success: false, error: 'No response' });
            else resolve(r);
          });
        });
        if (!res.success && res.error?.includes('429') && attempt < MAX_RETRIES) {
          const wait = RETRY_DELAY * (attempt + 1);
          status(`Rate limited — waiting ${Math.round(wait/1000)}s (retry ${attempt+1}/${MAX_RETRIES})...`);
          await sleep(wait);
          continue;
        }
        return res;
      }
    }

    // tanteiByLabel: { containerLabel -> tantei row }  (from VRID searches)
    // nestedContentsByParent: { parentLabel -> [ tantei rows ] }  (from nested container searches)
    const tanteiByLabel = {};
    const nestedContentsByParent = {};
    let tanteiTotal = 0;

    // 3a: Search Tantei for VRIDs
    for (let i = 0; i < vridsWithPackages.length; i += BATCH_SIZE) {
      const batch = vridsWithPackages.slice(i, i + BATCH_SIZE);
      const batchNum = Math.floor(i / BATCH_SIZE) + 1;
      const totalBatches = Math.ceil(vridsWithPackages.length / BATCH_SIZE);

      if (i > 0) await sleep(BATCH_DELAY);
      status(`Step 3/4: Tantei VRIDs — batch ${batchNum}/${totalBatches} — ${tanteiTotal} items...`);

      let startIndex = '0';
      let hasMore = true;
      while (hasMore) {
        const queryInput = batch.map(vrid => ({ nodeId, searchId: vrid, searchIdType: 'UNKNOWN' }));
        const result = await gqlRequest({ queryInput, startIndex });
        if (!result.success) throw new Error('Tantei GraphQL failed: ' + result.error);

        let pageHasMore = false;
        (result.data?.data?.searchEntities || []).forEach(entity => {
          const searchId = entity.searchTerm?.searchId || '';
          const contents = entity.contents?.contents || [];
          const endToken = entity.contents?.endToken || null;
          contents.forEach(item => {
            tanteiByLabel[item.containerLabel] = {
              tantei_searchId: searchId,
              tantei_containerId: item.containerId,
              tantei_containerType: item.containerType,
              tantei_stackingFilter: (item.stackingFilter || '').replace(/-C-/g, '-'),
              tantei_criticalPullTime: item.criticalPullTime,
              tantei_isEmpty: item.isEmpty,
              tantei_isClosed: item.isClosed,
              tantei_isForcedMove: item.isForcedMove,
              tantei_associationReason: item.associationReason,
              tantei_associatedUser: item.associatedUser,
              tantei_timeOfAssociation: item.timeOfAssociation,
              tantei_cleanupAllowed: item.cleanupAllowed
            };
          });
          tanteiTotal += contents.length;
          if (endToken && contents.length > 0) { pageHasMore = true; startIndex = endToken; }
        });
        hasMore = pageHasMore;
        if (hasMore) await sleep(PAGE_DELAY);
      }
    }
    console.log(`🔍 Step 3a done: ${tanteiTotal} Tantei records from VRIDs`);

    // 3b: Search Tantei for nested containers (CART_, PALLET_, GAYLORD_, BAG_)
    if (nestedContainerLabels.length > 0) {
      let nestedTotal = 0;
      for (let i = 0; i < nestedContainerLabels.length; i += BATCH_SIZE) {
        const batch = nestedContainerLabels.slice(i, i + BATCH_SIZE);
        const batchNum = Math.floor(i / BATCH_SIZE) + 1;
        const totalBatches = Math.ceil(nestedContainerLabels.length / BATCH_SIZE);

        if (i > 0) await sleep(BATCH_DELAY);
        status(`Step 4/4: Tantei nested containers — batch ${batchNum}/${totalBatches} — ${nestedTotal} child items...`);

        let startIndex = '0';
        let hasMore = true;
        while (hasMore) {
          const queryInput = batch.map(label => ({ nodeId, searchId: label, searchIdType: 'UNKNOWN' }));
          const result = await gqlRequest({ queryInput, startIndex });
          if (!result.success) throw new Error('Tantei GraphQL (nested) failed: ' + result.error);

          let pageHasMore = false;
          (result.data?.data?.searchEntities || []).forEach(entity => {
            const parentLabel = entity.searchTerm?.searchId || '';
            const contents = entity.contents?.contents || [];
            const endToken = entity.contents?.endToken || null;
            if (!nestedContentsByParent[parentLabel]) nestedContentsByParent[parentLabel] = [];
            contents.forEach(item => {
              nestedContentsByParent[parentLabel].push({
                tantei_containerId: item.containerId,
                tantei_containerLabel: item.containerLabel,
                tantei_containerType: item.containerType,
                tantei_stackingFilter: (item.stackingFilter || '').replace(/-C-/g, '-'),
                tantei_criticalPullTime: item.criticalPullTime,
                tantei_isEmpty: item.isEmpty,
                tantei_isClosed: item.isClosed,
                tantei_isForcedMove: item.isForcedMove,
                tantei_associationReason: item.associationReason,
                tantei_associatedUser: item.associatedUser,
                tantei_timeOfAssociation: item.timeOfAssociation,
                tantei_cleanupAllowed: item.cleanupAllowed
              });
            });
            nestedTotal += contents.length;
            if (endToken && contents.length > 0) { pageHasMore = true; startIndex = endToken; }
          });
          hasMore = pageHasMore;
          if (hasMore) await sleep(PAGE_DELAY);
        }
      }
      tanteiTotal += nestedTotal;
      console.log(`🔍 Step 3b done: ${nestedTotal} child items from ${nestedContainerLabels.length} nested containers`);
    }
    console.log(`🔍 Tantei total: ${tanteiTotal} records, ${Object.keys(tanteiByLabel).length} VRID labels, ${Object.keys(nestedContentsByParent).length} nested containers`);

    // ── Step 4: Merge and export ──

    // ── Step 4: Merge and export ──
    const rows = [];
    for (const vrId of vridsWithPackages) {
      const info = loadInfoByVrid[vrId] || {};
      const pkgs = packagesByVrid[vrId] || [];
      for (const pkg of pkgs) {
        if (isNestedContainer(pkg.label)) {
          // This is a cart/pallet/gaylord/bag — expand its Tantei children
          const children = nestedContentsByParent[pkg.label] || [];
          if (children.length > 0) {
            for (const child of children) {
              rows.push({
                vrId,
                route: info.route,
                status: info.status,
                carrier: info.carrier,
                carrierGroup: info.carrierGroup,
                equipmentType: info.equipmentType,
                scheduledArrivalTime: info.scheduledArrivalTime,
                actualArrivalTime: info.actualArrivalTime,
                dockDoor: info.dockDoor,
                planId: info.planId,
                parentContainer: pkg.label,
                parentContainerType: pkg.containerType,
                pkg_label: child.tantei_containerLabel,
                pkg_containerId: child.tantei_containerId,
                pkg_containerType: child.tantei_containerType,
                pkg_length: pkg.length,
                pkg_width: pkg.width,
                pkg_height: pkg.height,
                pkg_weight: pkg.weight,
                tantei_stackingFilter: child.tantei_stackingFilter,
                tantei_criticalPullTime: child.tantei_criticalPullTime,
                tantei_isEmpty: child.tantei_isEmpty,
                tantei_isClosed: child.tantei_isClosed,
                tantei_isForcedMove: child.tantei_isForcedMove,
                tantei_associationReason: child.tantei_associationReason,
                tantei_associatedUser: child.tantei_associatedUser,
                tantei_timeOfAssociation: child.tantei_timeOfAssociation,
                tantei_cleanupAllowed: child.tantei_cleanupAllowed
              });
            }
          } else {
            // Nested container but Tantei returned no children — still include it
            rows.push({
              vrId,
              route: info.route,
              status: info.status,
              carrier: info.carrier,
              carrierGroup: info.carrierGroup,
              equipmentType: info.equipmentType,
              scheduledArrivalTime: info.scheduledArrivalTime,
              actualArrivalTime: info.actualArrivalTime,
              dockDoor: info.dockDoor,
              planId: info.planId,
              parentContainer: '',
              parentContainerType: '',
              pkg_label: pkg.label,
              pkg_containerId: pkg.containerId,
              pkg_containerType: pkg.containerType,
              pkg_length: pkg.length,
              pkg_width: pkg.width,
              pkg_height: pkg.height,
              pkg_weight: pkg.weight,
              ...(tanteiByLabel[pkg.label] || {})
            });
          }
        } else {
          // Direct package — join with Tantei data by label
          const tantei = tanteiByLabel[pkg.label] || {};
          rows.push({
            vrId,
            route: info.route,
            status: info.status,
            carrier: info.carrier,
            carrierGroup: info.carrierGroup,
            equipmentType: info.equipmentType,
            scheduledArrivalTime: info.scheduledArrivalTime,
            actualArrivalTime: info.actualArrivalTime,
            dockDoor: info.dockDoor,
            planId: info.planId,
            parentContainer: '',
            parentContainerType: '',
            pkg_label: pkg.label,
            pkg_containerId: pkg.containerId,
            pkg_containerType: pkg.containerType,
            pkg_length: pkg.length,
            pkg_width: pkg.width,
            pkg_height: pkg.height,
            pkg_weight: pkg.weight,
            tantei_stackingFilter: tantei.tantei_stackingFilter || '',
            tantei_criticalPullTime: tantei.tantei_criticalPullTime || '',
            tantei_isEmpty: tantei.tantei_isEmpty || '',
            tantei_isClosed: tantei.tantei_isClosed || '',
            tantei_isForcedMove: tantei.tantei_isForcedMove || '',
            tantei_associationReason: tantei.tantei_associationReason || '',
            tantei_associatedUser: tantei.tantei_associatedUser || '',
            tantei_timeOfAssociation: tantei.tantei_timeOfAssociation || '',
            tantei_cleanupAllowed: tantei.tantei_cleanupAllowed || ''
          });
        }
      }
    }

    if (rows.length === 0) {
      status('⚠️ No merged rows to export.');
      return;
    }

    const columns = Object.keys(rows[0]);
    const esc = v => {
      if (v == null || v === '') return '';
      const s = String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };
    let csv = columns.map(c => esc(c)).join(',') + '\n';
    rows.forEach(row => { csv += columns.map(c => esc(row[c])).join(',') + '\n'; });

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pipeline_${nodeId}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (resultDiv) resultDiv.innerHTML = `<p style="color: green;">✅ Exported ${rows.length} rows (${vridsWithPackages.length} VRIDs, ${tanteiTotal} Tantei records) to CSV.</p>`;
    console.log(`✅ Pipeline complete: ${rows.length} merged rows`);
  } catch (error) {
    console.error('❌ Pipeline failed:', error);
    if (resultDiv) resultDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

// Fetch Tantei container search results and export to CSV
async function fetchTanteiAndExport(nodeId, vrids) {
  const resultDiv = document.getElementById('api-result-tantei');
  if (resultDiv) resultDiv.innerHTML = '<p style="color: #666;">Step 1: Fetching CSRF token from Tantei...</p>';

  try {
    // Step 1: Get CSRF token via background script
    const csrfResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'fetchTanteiCSRF', nodeId }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, error: 'Background script error: ' + chrome.runtime.lastError.message });
        } else if (!response) {
          resolve({ success: false, error: 'No response from background script. Make sure you reloaded the extension after updating background.js (go to chrome://extensions and click the reload button).' });
        } else {
          resolve(response);
        }
      });
    });

    console.log('🔐 Tantei CSRF result:', csrfResult);

    if (!csrfResult.success) {
      const diag = csrfResult.diagnostics || {};
      const diagInfo = [
        diag.title ? `Title: ${diag.title}` : '',
        diag.csrfOccurrences?.length ? `CSRF occurrences in HTML: ${diag.csrfOccurrences.join(', ')}` : 'No "csrf" string found in HTML',
        diag.metaTags?.length ? `Meta tags: ${diag.metaTags.join(' | ')}` : 'No meta tags found',
        `HTML length: ${diag.htmlLength || '?'}`
      ].filter(Boolean).join('\n');
      throw new Error('Failed to get Tantei CSRF token: ' + csrfResult.error + '\n\n' + diagInfo);
    }

    const csrfToken = csrfResult.token;
    console.log('✅ Got Tantei CSRF token, length:', csrfToken.length);

    // Step 2: Build the GraphQL query
    const graphqlQuery = `
query ($queryInput: [SearchTermInput!]!, $startIndex: String) {
  searchEntities(searchTerms: $queryInput) {
    searchTerm {
      nodeId
      nodeTimezone
      searchId
      searchIdType
      resolvedIdType
    }
    contents(pageSize: 60, startIndex: $startIndex, forwardNavigate: true) {
      contents {
        containerId
        containerLabel
        containerType
        stackingFilter
        criticalPullTime
        isEmpty
        isClosed
        isForcedMove
        associationReason
        associatedUser
        timeOfAssociation
        cleanupAllowed
      }
      endToken
    }
  }
}
`;

    // Step 3: Batch VRIDs (5 at a time) and paginate each batch
    const BATCH_SIZE = 5;
    const BATCH_DELAY_MS = 300; // small delay between batches
    const PAGE_DELAY_MS = 200;  // small delay between pagination calls
    const RETRY_DELAY_MS = 2000; // back off on 429
    const MAX_RETRIES = 5;
    const allResults = [];
    let totalFetched = 0;

    const sleep = ms => new Promise(r => setTimeout(r, ms));

    // Helper: send a single GraphQL request with retry on 429
    async function tanteiGqlRequest(csrfToken, graphqlQuery, variables, nodeId) {
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        const result = await new Promise((resolve) => {
          chrome.runtime.sendMessage({
            type: 'tanteiGraphQL',
            csrfToken,
            query: graphqlQuery,
            variables,
            nodeId
          }, (response) => {
            if (chrome.runtime.lastError) {
              resolve({ success: false, error: 'Background script error: ' + chrome.runtime.lastError.message });
            } else if (!response) {
              resolve({ success: false, error: 'No response from background script for GraphQL call. Reload the extension.' });
            } else {
              resolve(response);
            }
          });
        });

        // If it's a 429, wait and retry
        if (!result.success && result.error && result.error.includes('429') && attempt < MAX_RETRIES) {
          const wait = RETRY_DELAY_MS * (attempt + 1);
          console.log(`⏳ 429 rate limited, retrying in ${wait}ms (attempt ${attempt + 1}/${MAX_RETRIES})`);
          if (resultDiv) resultDiv.innerHTML = `<p style="color: orange;">Rate limited — waiting ${Math.round(wait / 1000)}s before retry (${attempt + 1}/${MAX_RETRIES})...</p>`;
          await sleep(wait);
          continue;
        }

        return result;
      }
    }

    for (let i = 0; i < vrids.length; i += BATCH_SIZE) {
      const batch = vrids.slice(i, i + BATCH_SIZE);
      const batchNum = Math.floor(i / BATCH_SIZE) + 1;
      const totalBatches = Math.ceil(vrids.length / BATCH_SIZE);

      // Delay between batches (skip before the first one)
      if (i > 0) {
        if (resultDiv) resultDiv.innerHTML = `<p style="color: #666;">Waiting between batches to avoid rate limiting...</p>`;
        await sleep(BATCH_DELAY_MS);
      }

      if (resultDiv) resultDiv.innerHTML = `<p style="color: #666;">Step 2: Fetching batch ${batchNum}/${totalBatches} (${batch.join(', ')})...</p>`;

      // Paginate this batch
      let startIndex = '0';
      let hasMore = true;

      while (hasMore) {
        const queryInput = batch.map(vrid => ({
          nodeId: nodeId,
          searchId: vrid,
          searchIdType: 'UNKNOWN'
        }));

        const variables = { queryInput, startIndex };

        console.log(`📤 Tantei batch ${batchNum}, startIndex: ${startIndex}`);

        const result = await tanteiGqlRequest(csrfToken, graphqlQuery, variables, nodeId);

        if (!result.success) {
          throw new Error(`Tantei GraphQL failed: ${result.error}`);
        }

        const searchEntities = result.data?.data?.searchEntities || [];

        let pageHasMore = false;
        searchEntities.forEach(entity => {
          const searchTerm = entity.searchTerm || {};
          const contents = entity.contents?.contents || [];
          const endToken = entity.contents?.endToken || null;

          contents.forEach(item => {
            allResults.push({
              nodeId: searchTerm.nodeId,
              nodeTimezone: searchTerm.nodeTimezone,
              searchId: searchTerm.searchId,
              searchIdType: searchTerm.searchIdType,
              resolvedIdType: searchTerm.resolvedIdType,
              containerId: item.containerId,
              containerLabel: item.containerLabel,
              containerType: item.containerType,
              stackingFilter: (item.stackingFilter || '').replace(/-C-/g, '-'),
              criticalPullTime: item.criticalPullTime,
              isEmpty: item.isEmpty,
              isClosed: item.isClosed,
              isForcedMove: item.isForcedMove,
              associationReason: item.associationReason,
              associatedUser: item.associatedUser,
              timeOfAssociation: item.timeOfAssociation,
              cleanupAllowed: item.cleanupAllowed
            });
          });

          totalFetched += contents.length;

          // If any entity in this batch has an endToken, we need another page
          if (endToken && contents.length > 0) {
            pageHasMore = true;
            startIndex = endToken;
          }
        });

        hasMore = pageHasMore;

        if (resultDiv) resultDiv.innerHTML = `<p style="color: #666;">Step 2: Batch ${batchNum}/${totalBatches} — ${totalFetched} items so far...</p>`;

        // Delay between pagination calls to avoid 429
        if (hasMore) await sleep(PAGE_DELAY_MS);
      }
    }

    if (allResults.length === 0) {
      if (resultDiv) resultDiv.innerHTML = '<p style="color: orange;">No results found for the given VRID(s).</p>';
      return;
    }

    // Step 4: Export to CSV
    const columns = Object.keys(allResults[0]);

    const esc = v => {
      if (v == null || v === '') return '';
      const s = String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };

    let csv = columns.map(c => esc(c)).join(',') + '\n';
    allResults.forEach(row => {
      csv += columns.map(c => esc(row[c])).join(',') + '\n';
    });

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tantei_${nodeId}_${vrids.join('-')}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (resultDiv) resultDiv.innerHTML = `<p style="color: green;">✅ Exported ${allResults.length} containers from ${vrids.length} VRID(s) to CSV.</p>`;
    console.log(`✅ Tantei export complete: ${allResults.length} containers`);
  } catch (error) {
    console.error('❌ Tantei fetch failed:', error);
    if (resultDiv) resultDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

// Fetch all inbound loads, then drill into each for container hierarchy, export to CSV
async function fetchAllContainersAndExport(nodeId) {
  const resultDiv = document.getElementById('api-result-containers');
  if (resultDiv) resultDiv.innerHTML = '<p style="color: #666;">Step 1: Fetching inbound loads...</p>';

  try {
    // Step 1: Get all inbound loads
    const ibResponse = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest'
      },
      credentials: 'include',
      body: `entity=getPrioritizedInboundDockView&nodeId=${encodeURIComponent(nodeId)}&isILPRankGroupingEnabled=true`
    });
    if (!ibResponse.ok) throw new Error(`Inbound fetch HTTP ${ibResponse.status}`);
    const ibJson = await ibResponse.json();
    const loads = ibJson?.ret?.aaData || [];

    if (loads.length === 0) {
      if (resultDiv) resultDiv.innerHTML = '<p style="color: orange;">No inbound loads found.</p>';
      return;
    }

    // Step 2: For each load, fetch container hierarchy
    const allPackages = [];
    let completed = 0;

    for (const loadEntry of loads) {
      const planId = loadEntry.load?.planId;
      const vrId = loadEntry.load?.vrId || '';
      const route = loadEntry.load?.route || '';
      const status = loadEntry.load?.status || '';
      const dockDoor = (loadEntry.resource || []).map(r => r.label).join('; ');

      if (!planId) {
        completed++;
        continue;
      }

      if (resultDiv) resultDiv.innerHTML = `<p style="color: #666;">Step 2: Fetching containers ${completed + 1}/${loads.length} (${vrId})...</p>`;

      try {
        const cResponse = await fetch('https://www.amazonlogistics.com/ssp/dock/hrz/ib/fetchdata?', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest'
          },
          credentials: 'include',
          body: `entity=getInboundLoadContainerHierarchy&inboundLoadId=${encodeURIComponent(planId)}&nodeId=${encodeURIComponent(nodeId)}&containerStatus=InTrailer`
        });

        if (cResponse.ok) {
          const cJson = await cResponse.json();
          const hierarchy = cJson?.ret?.aaData?.[0]?.hierarchy;
          const children = hierarchy?.childContainers || [];

          children.forEach(child => {
            const c = child.container || {};
            const props = c.properties || {};

            let length = '', width = '', height = '', weightVal = '';
            try {
              const box = JSON.parse(props.BOXED_SIZE || '{}');
              length = box.length?.value || '';
              width = box.width?.value || '';
              height = box.height?.value || '';
            } catch (e) {}
            try {
              const w = JSON.parse(props.WEIGHT || '{}');
              weightVal = w.weight?.value || '';
            } catch (e) {}

            allPackages.push({
              vrId, route, status, dockDoor, planId,
              containerType: c.containerType || '',
              label: c.label || '',
              containerId: c.containerId || '',
              length, width, height, weight: weightVal
            });
          });
        }
      } catch (err) {
        console.warn(`⚠️ Container fetch failed for ${vrId}:`, err.message);
      }

      completed++;
    }

    if (allPackages.length === 0) {
      if (resultDiv) resultDiv.innerHTML = '<p style="color: orange;">No packages found across all loads.</p>';
      return;
    }

    // Step 3: Build CSV
    const columns = [
      { header: 'VR ID', get: r => r.vrId },
      { header: 'Route', get: r => r.route },
      { header: 'Status', get: r => r.status },
      { header: 'Dock Door', get: r => r.dockDoor },
      { header: 'Plan ID', get: r => r.planId },
      { header: 'Container Type', get: r => r.containerType },
      { header: 'Package Label', get: r => r.label },
      { header: 'Container ID', get: r => r.containerId },
      { header: 'Length (in)', get: r => r.length },
      { header: 'Width (in)', get: r => r.width },
      { header: 'Height (in)', get: r => r.height },
      { header: 'Weight (lb)', get: r => r.weight }
    ];

    const esc = v => {
      if (v == null || v === '') return '';
      const s = String(v);
      return s.includes(',') || s.includes('"') || s.includes('\n') ? '"' + s.replace(/"/g, '""') + '"' : s;
    };

    let csv = columns.map(c => esc(c.header)).join(',') + '\n';
    allPackages.forEach(row => {
      csv += columns.map(c => esc(c.get(row))).join(',') + '\n';
    });

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `containers_${nodeId}_${new Date().toISOString().slice(0, 16).replace(/[:-]/g, '')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (resultDiv) resultDiv.innerHTML = `<p style="color: green;">✅ Exported ${allPackages.length} packages from ${loads.length} loads to CSV.</p>`;
    console.log(`✅ Container export complete: ${allPackages.length} packages from ${loads.length} loads`);
  } catch (error) {
    console.error('❌ Container fetch failed:', error);
    if (resultDiv) resultDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

// Check if we just hopped to API domain
async function checkForDomainHop() {
  console.log('🔍 checkForDomainHop() called');
  console.log('🔍 Current URL:', window.location.href);
  console.log('🔍 Current hash:', window.location.hash);

  const currentDomain = window.location.hostname;
  const hash = window.location.hash;

  // Check for hop parameters in URL hash
  let hopState = null;

  // First check URL hash (more reliable for cross-domain)
  if (hash && hash.includes('hop=')) {
    console.log('🔍 Found hop params in URL hash');
    const params = new URLSearchParams(hash.substring(1));
    hopState = {
      apiType: params.get('hop'),
      nodeId: params.get('node'),
      returnUrl: decodeURIComponent(params.get('return') || ''),
      timestamp: parseInt(params.get('ts') || '0')
    };
    console.log('🔍 Parsed hop state from URL:', hopState);
  } else {
    // Fallback to localStorage
    const hopStateStr = localStorage.getItem('domainHopState');
    console.log('🔍 hopState from localStorage:', hopStateStr);

    if (hopStateStr) {
      hopState = JSON.parse(hopStateStr);
      console.log('🔍 Parsed hop state from localStorage:', hopState);
    }
  }

  if (!hopState) {
    console.log('ℹ️ No hop state found in URL or localStorage');
    return;
  }

  console.log('🔍 Current domain:', currentDomain);
  console.log('🔍 Hop state:', hopState);
  console.log('🔍 Is stem domain?', currentDomain === 'stem-na.corp.amazon.com');

  // If we're on the API domain and have a hop state
  if (currentDomain === 'stem-na.corp.amazon.com') {
    console.log('🚀 Domain hop detected! Executing API call...');
    console.log('🚀 Will execute API type:', hopState.apiType, 'for node:', hopState.nodeId);

    await showLoadingOverlay('Executing API call...');

    // Wait for page to fully load
    console.log('⏳ Waiting for page to load...');
    await new Promise(resolve => setTimeout(resolve, 2000));

    try {
      console.log('📞 About to execute API call type:', hopState.apiType);

      // Execute the API call(s)
      if (hopState.apiType === 'api1') {
        console.log('📞 Calling executeApiCall1...');
        await executeApiCall1(hopState.nodeId);
      } else if (hopState.apiType === 'api2') {
        console.log('📞 Calling executeApiCall2...');
        await executeApiCall2(hopState.nodeId);
      } else if (hopState.apiType === 'both') {
        console.log('📞 Calling ALL API calls...');
        console.log('📞 Step 1/7: Calling executeApiCall1...');
        await executeApiCall1(hopState.nodeId);
        console.log('✅ API Call 1 completed');
        console.log('📞 Step 2/7: Calling executeApiCall2...');
        await executeApiCall2(hopState.nodeId);
        console.log('✅ API Call 2 completed');
        console.log('📞 Step 3/7: Calling executeApiCall3 (Resources)...');
        await executeApiCall3(hopState.nodeId);
        console.log('✅ API Call 3 completed');
        console.log('📞 Step 4/7: Calling executeApiCall4 (Reservations)...');
        await executeApiCall4(hopState.nodeId);
        console.log('✅ API Call 4 completed');
        console.log('📞 Step 5/7: Calling executeApiCall5 (VSM)...');
        await executeApiCall5(hopState.nodeId);
        console.log('✅ API Call 5 completed');
        console.log('📞 Step 6/7: Calling executeApiCall6 (Connected Resources)...');
        await executeApiCall6(hopState.nodeId);
        console.log('✅ API Call 6 completed');
        console.log('📞 Step 7/7: Calling executeApiCall7 (Chutes)...');
        await executeApiCall7(hopState.nodeId);
        console.log('✅ API Call 7 completed');
      }

      // Log storage sizes for each API result to help diagnose quota issues
      try {
        const nid = hopState.nodeId;
        const sizeKeys = [`apiResult1_${nid}`, `apiResult2_${nid}`, `apiResult3_${nid}`, `apiResult4_${nid}`, `apiResult5_${nid}`, `apiResult6_${nid}`, `apiResult7_${nid}`];
        const sizeData = await chrome.storage.local.get(sizeKeys);
        const labels = ['Map(2dMap)', 'Map(Deploy)', 'Resources', 'Reservations', 'VSM', 'Connections', 'Chutes'];
        let totalBytes = 0;
        sizeKeys.forEach((k, i) => {
          const bytes = sizeData[k] ? JSON.stringify(sizeData[k]).length : 0;
          totalBytes += bytes;
          console.log(`📊 ${labels[i]}: ${(bytes / 1024).toFixed(1)} KB`);
        });
        console.log(`📊 TOTAL stored for ${nid}: ${(totalBytes / 1024).toFixed(1)} KB (limit ~5120 KB)`);
      } catch (sizeErr) {
        console.warn('⚠️ Could not measure storage sizes:', sizeErr);
      }

      console.log('✅ All API calls completed!');
      
      // Clear hop state, cat image, and hop attempt counter
      localStorage.removeItem('domainHopState');
      localStorage.removeItem(`hopAttempts_${hopState.nodeId}`);
      await chrome.storage.local.remove('hopCatImage');
      console.log('🗑️ Cleared domainHopState, hop counter, and cat image from storage');

      // Return to original domain
      await showLoadingOverlay('Returning to main app...');
      setTimeout(() => {
        console.log('🔙 Navigating back to:', hopState.returnUrl);
        window.location.href = hopState.returnUrl;
      }, 500);

    } catch (error) {
      console.error('❌ API call failed:', error);
      console.error('❌ Error stack:', error.stack);
      localStorage.removeItem('domainHopState');
      await chrome.storage.local.remove('hopCatImage');
      
      await showLoadingOverlay('Error occurred, returning...');
      setTimeout(() => {
        window.location.href = hopState.returnUrl;
      }, 1000);
    }
  }

  // If we're back on the original domain, show results
  if (currentDomain !== 'stem-na.corp.amazon.com') {
    console.log('🏠 Back on original domain, checking for results...');
    hideLoadingOverlay();

    // Display results if available
    setTimeout(() => {
      console.log('🏠 Back on original domain, hop complete');
    }, 500);
  }
}


function showSettingsModal() {
  // Create popup modal
  const modal = document.createElement('div');
  modal.id = 'settings-modal';
  modal.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90%;
    max-width: 900px;
    max-height: 85vh;
    background: var(--bg-secondary);
    border: 2px solid var(--border-color);
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    z-index: 1000000;
    display: flex;
    flex-direction: column;
    color: var(--text-primary);
  `;
  
  // Header
  const header = document.createElement('div');
  header.style.cssText = `
    padding: 15px 20px;
    background: var(--button-bg);
    color: white;
    border-radius: 6px 6px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: bold;
  `;
  header.innerHTML = `
    <span>⚙️ Settings</span>
    <button id="close-settings" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 5px 10px; cursor: pointer; border-radius: 3px;">✕</button>
  `;
  
  // Tab navigation
  const tabNav = document.createElement('div');
  tabNav.style.cssText = `
    display: flex;
    gap: 10px;
    padding: 15px 20px 0 20px;
    border-bottom: 2px solid var(--border-color);
  `;
  tabNav.innerHTML = `
    <button id="settings-tab-general" class="settings-tab-button active" style="padding: 10px 20px; background: var(--button-bg); color: white; border: none; border-radius: 4px 4px 0 0; cursor: pointer; font-size: 14px;">General</button>
    <button id="settings-tab-zones" class="settings-tab-button" style="padding: 10px 20px; background: var(--bg-tertiary); color: var(--text-primary); border: none; border-radius: 4px 4px 0 0; cursor: pointer; font-size: 14px;">Zones</button>
    <button id="settings-tab-storage" class="settings-tab-button" style="padding: 10px 20px; background: var(--bg-tertiary); color: var(--text-primary); border: none; border-radius: 4px 4px 0 0; cursor: pointer; font-size: 14px;">Storage</button>
    <button id="settings-tab-api" class="settings-tab-button" style="padding: 10px 20px; background: var(--bg-tertiary); color: var(--text-primary); border: none; border-radius: 4px 4px 0 0; cursor: pointer; font-size: 14px;">API Testing</button>
  `;
  
  // Content area
  const content = document.createElement('div');
  content.id = 'settings-content';
  content.style.cssText = `
    padding: 20px;
    overflow-y: auto;
    max-height: calc(85vh - 120px);
    flex: 1;
  `;
  
  // Get current theme
  const isDarkMode = document.body.classList.contains('dark-mode');
  
  // Initial content (General tab)
  content.innerHTML = getGeneralSettingsContent(isDarkMode);
  
  // Backdrop
  const backdrop = document.createElement('div');
  backdrop.id = 'settings-backdrop';
  backdrop.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0,0,0,0.5);
    z-index: 999999;
  `;
  
  // Assemble modal
  modal.appendChild(header);
  modal.appendChild(tabNav);
  modal.appendChild(content);
  
  // Add to page
  const ryanRoot = document.getElementById('ryan-console-root');
  if (ryanRoot) {
    ryanRoot.appendChild(backdrop);
    ryanRoot.appendChild(modal);
  } else {
    document.body.appendChild(backdrop);
    document.body.appendChild(modal);
  }
  
  // Event handlers
  const closeModal = () => {
    modal.remove();
    backdrop.remove();
  };
  
  document.getElementById('close-settings').addEventListener('click', closeModal);
  backdrop.addEventListener('click', closeModal);
  
  // Tab switching
  document.getElementById('settings-tab-general').addEventListener('click', () => {
    document.querySelectorAll('.settings-tab-button').forEach(btn => {
      btn.style.background = 'var(--bg-tertiary)';
      btn.style.color = 'var(--text-primary)';
      btn.classList.remove('active');
    });
    document.getElementById('settings-tab-general').style.background = 'var(--button-bg)';
    document.getElementById('settings-tab-general').style.color = 'white';
    document.getElementById('settings-tab-general').classList.add('active');
    content.innerHTML = getGeneralSettingsContent(document.body.classList.contains('dark-mode'));
    setupGeneralSettingsHandlers();
  });

  document.getElementById('settings-tab-zones').addEventListener('click', () => {
    document.querySelectorAll('.settings-tab-button').forEach(btn => {
      btn.style.background = 'var(--bg-tertiary)';
      btn.style.color = 'var(--text-primary)';
      btn.classList.remove('active');
    });
    document.getElementById('settings-tab-zones').style.background = 'var(--button-bg)';
    document.getElementById('settings-tab-zones').style.color = 'white';
    document.getElementById('settings-tab-zones').classList.add('active');
    content.innerHTML = getZoneSettingsContent();
    setupZoneSettingsHandlers();
  });
  
  document.getElementById('settings-tab-api').addEventListener('click', () => {
    document.querySelectorAll('.settings-tab-button').forEach(btn => {
      btn.style.background = 'var(--bg-tertiary)';
      btn.style.color = 'var(--text-primary)';
      btn.classList.remove('active');
    });
    document.getElementById('settings-tab-api').style.background = 'var(--button-bg)';
    document.getElementById('settings-tab-api').style.color = 'white';
    document.getElementById('settings-tab-api').classList.add('active');
    content.innerHTML = renderApiTestContent();
  });
  
  document.getElementById('settings-tab-storage').addEventListener('click', async () => {
    document.querySelectorAll('.settings-tab-button').forEach(btn => {
      btn.style.background = 'var(--bg-tertiary)';
      btn.style.color = 'var(--text-primary)';
      btn.classList.remove('active');
    });
    document.getElementById('settings-tab-storage').style.background = 'var(--button-bg)';
    document.getElementById('settings-tab-storage').style.color = 'white';
    document.getElementById('settings-tab-storage').classList.add('active');
    content.innerHTML = '<p style="color: var(--text-secondary);">Loading storage data...</p>';
    content.innerHTML = await renderStorageSettingsContent();
    setupStorageSettingsHandlers(content);
  });
  
  // Setup handlers for initial tab
  setupGeneralSettingsHandlers();
}

function getGeneralSettingsContent(isDarkMode) {
  return `
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 15px 0; color: var(--text-primary);">Appearance</h3>
      
      <div style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: var(--bg-tertiary); border-radius: 5px; margin-bottom: 15px;">
        <div>
          <div style="font-weight: bold; margin-bottom: 5px;">Theme</div>
          <div style="font-size: 14px; color: var(--text-secondary);">Choose between light and dark mode</div>
        </div>
        <label style="position: relative; display: inline-block; width: 60px; height: 30px;">
          <input type="checkbox" id="theme-toggle" ${isDarkMode ? 'checked' : ''} style="opacity: 0; width: 0; height: 0;">
          <span style="
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: ${isDarkMode ? '#007bff' : '#ccc'};
            transition: 0.3s;
            border-radius: 30px;
          ">
            <span style="
              position: absolute;
              content: '';
              height: 22px;
              width: 22px;
              left: ${isDarkMode ? '34px' : '4px'};
              bottom: 4px;
              background-color: white;
              transition: 0.3s;
              border-radius: 50%;
            "></span>
          </span>
        </label>
      </div>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 15px 0; color: var(--text-primary);">Navigation</h3>
      
      <div style="padding: 15px; background: var(--bg-tertiary); border-radius: 5px;">
        <button id="change-node-btn" class="button" style="width: 100%; padding: 12px; font-size: 16px; background: #6c757d;">
          🔄 Change Node
        </button>
        <p style="margin: 10px 0 0 0; font-size: 14px; color: var(--text-secondary); text-align: center;">Return to node selection screen</p>
        
        <button id="edit-map-btn" class="button" style="width: 100%; padding: 12px; font-size: 16px; background: #6c757d; margin-top: 15px;">
          ✏️ Edit Map
        </button>
        <p style="margin: 10px 0 0 0; font-size: 14px; color: var(--text-secondary); text-align: center;">Open the map editor for the current node</p>
      </div>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 15px 0; color: var(--text-primary);">About</h3>
      <div style="padding: 15px; background: var(--bg-tertiary); border-radius: 5px; font-size: 14px; color: var(--text-secondary);">
        <p style="margin: 0 0 10px 0;"><strong>Version:</strong> 1.0.0</p>
        <p style="margin: 0 0 10px 0;"><strong>Current Node:</strong> ${selectedNodeId || 'None'}</p>
        <p style="margin: 0;"><strong>Domain Hopping:</strong> Enabled</p>
      </div>
    </div>
  `;
}

function setupGeneralSettingsHandlers() {
  // Theme toggle handler
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('change', async (e) => {
      const isDark = e.target.checked;
      
      if (isDark) {
        document.body.classList.add('dark-mode');
      } else {
        document.body.classList.remove('dark-mode');
      }
      
      // Save preference to chrome.storage
      await chrome.storage.local.set({ theme: isDark ? 'dark' : 'light' });
      console.log('💾 Theme saved:', isDark ? 'dark' : 'light');
      
      // Update toggle appearance
      const slider = themeToggle.nextElementSibling;
      const knob = slider.querySelector('span');
      slider.style.backgroundColor = isDark ? '#007bff' : '#ccc';
      knob.style.left = isDark ? '34px' : '4px';
    });
  }
  
  // Change Node button handler
  const changeNodeBtn = document.getElementById('change-node-btn');
  if (changeNodeBtn) {
    changeNodeBtn.addEventListener('click', () => {
      // Close settings modal
      const modal = document.getElementById('settings-modal');
      const backdrop = document.getElementById('settings-backdrop');
      if (modal) modal.remove();
      if (backdrop) backdrop.remove();
      
      // Clear the stage if it exists
      if (stage) {
        stage.destroy();
        stage = null;
      }
      
      // Return to initial view
      console.log('🔄 Changing node - returning to initial view');
      renderInitialViewContent();
    });
  }
  
  // Edit Map button handler
  const editMapBtn = document.getElementById('edit-map-btn');
  if (editMapBtn) {
    editMapBtn.addEventListener('click', () => {
      if (!selectedNodeId || !stage) {
        alert('No map is currently loaded.');
        return;
      }
      
      // Close settings modal
      const modal = document.getElementById('settings-modal');
      const backdrop = document.getElementById('settings-backdrop');
      if (modal) modal.remove();
      if (backdrop) backdrop.remove();
      
      // Enter editor mode
      console.log('✏️ Entering editor mode for', selectedNodeId);
      currentView = 'editorActive';
      currentTool = 'select';
      
      stage.draggable(true);
      interactiveLayer.listening(true);
      
      renderEditorTools();
    });
  }
}

function getZoneSettingsContent() {
  // Collect all known zones from chuteConnectionMap + discovered zones from heat map
  const zones = new Set();
  zones.add('__NC__'); // always show NC
  for (const [label, info] of Object.entries(chuteConnectionMap)) {
    if (info.waterspiderZone) zones.add(info.waterspiderZone);
  }
  if (heatMapData && heatMapData.discoveredZones) {
    heatMapData.discoveredZones.forEach(z => zones.add(z));
  }

  const sortedZones = [...zones].sort((a, b) => {
    if (a === '__NC__') return -1;
    if (b === '__NC__') return 1;
    return a.localeCompare(b);
  });

  const rows = sortedZones.map(z => {
    const displayName = z === '__NC__' ? 'Non-Con (NC)' : z;
    const color = zoneGlowColors[z] || '#555555';
    return `<div style="display:flex; justify-content:space-between; align-items:center; padding:10px 15px; background:var(--bg-tertiary); border-radius:5px; margin-bottom:8px;">
      <div style="display:flex; align-items:center; gap:10px;">
        <span style="display:inline-block; width:16px; height:16px; border-radius:3px; background:${color}; opacity:0.5; border:1px solid var(--border-color);"></span>
        <span style="font-size:14px;">${displayName}</span>
      </div>
      <div style="display:flex; align-items:center; gap:8px;">
        <input type="color" class="zone-color-picker" data-zone="${z}" value="${color}" style="width:36px; height:28px; border:1px solid var(--border-color); border-radius:4px; cursor:pointer; background:none;">
        <button class="zone-clear-btn button" data-zone="${z}" style="font-size:11px; padding:4px 8px; background:#6c757d; color:#fff;">Clear</button>
      </div>
    </div>`;
  }).join('');

  return `
    <div style="margin-bottom:20px;">
      <h3 style="margin:0 0 15px 0; color:var(--text-primary);">Zone Glow Colors</h3>
      <p style="font-size:13px; color:var(--text-secondary); margin:0 0 15px 0;">Set the glow color shown under stacking areas for each waterspider zone. Clear removes the glow for that zone.</p>
      ${rows || '<p style="color:var(--text-secondary);">No zones discovered yet. Run the heat map pipeline first.</p>'}
    </div>
  `;
}

function setupZoneSettingsHandlers() {
  document.querySelectorAll('.zone-color-picker').forEach(picker => {
    picker.addEventListener('input', (e) => {
      const zone = e.target.dataset.zone;
      zoneGlowColors[zone] = e.target.value;
      saveZoneColors();
      // Update the preview swatch
      const swatch = e.target.closest('div[style*="justify-content"]')?.querySelector('span[style*="inline-block"]');
      if (swatch) swatch.style.background = e.target.value;
      // Re-apply heat map if active
      if (heatMapData) applyHeatMapColors();
    });
  });

  document.querySelectorAll('.zone-clear-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const zone = e.target.dataset.zone;
      delete zoneGlowColors[zone];
      saveZoneColors();
      // Update the picker and swatch
      const row = e.target.closest('div[style*="justify-content"]');
      const picker = row?.querySelector('.zone-color-picker');
      const swatch = row?.querySelector('span[style*="inline-block"]');
      if (picker) picker.value = '#555555';
      if (swatch) swatch.style.background = '#555555';
      // Re-apply heat map if active
      if (heatMapData) applyHeatMapColors();
    });
  });
}

async function renderStorageSettingsContent() {
  // TODO: Revisit edge cases in storage management:
  //   - Partial hop data (e.g. apiResult1 exists but not 2 or 3)
  //   - Orphaned hop state (hopAttempts_, pendingMapLoad, domainHopState)
  //   - chrome.storage quota approaching limit (show usage %)
  //   - Stale data from old/renamed nodes
  // Gather all node data from both localStorage and chrome.storage
  const nodes = new Map();

  // Scan localStorage for saved maps
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key.startsWith(STORAGE_KEY_PREFIX)) {
      const nodeId = key.replace(STORAGE_KEY_PREFIX, '');
      if (!nodes.has(nodeId)) nodes.set(nodeId, { nodeId });
      try {
        const data = JSON.parse(localStorage.getItem(key));
        nodes.get(nodeId).savedMap = true;
        nodes.get(nodeId).entityCount = data.entities ? data.entities.length : 0;
        nodes.get(nodeId).savedTimestamp = data.timestamp;
      } catch (e) {
        nodes.get(nodeId).savedMap = true;
      }
    }
  }

  // Scan chrome.storage for cached API results
  const allStorage = await chrome.storage.local.get(null);
  for (const key of Object.keys(allStorage)) {
    const match = key.match(/^apiResult([1234567])_(.+)$/);
    if (match) {
      const callNum = match[1];
      const nodeId = match[2];
      if (!nodes.has(nodeId)) nodes.set(nodeId, { nodeId });
      const node = nodes.get(nodeId);
      if (!node.apiCalls) node.apiCalls = {};
      node.apiCalls[callNum] = {
        success: allStorage[key].success,
        timestamp: allStorage[key].timestamp
      };
    }
  }

  const nodeList = Array.from(nodes.values());

  if (nodeList.length === 0) {
    return `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 15px 0; color: var(--text-primary);">Saved Data</h3>
        <p style="color: var(--text-secondary);">No saved data found.</p>
      </div>
    `;
  }

  let html = `
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 15px 0; color: var(--text-primary);">Saved Data</h3>
      <button id="storage-clear-all" style="background:#dc3545;color:#fff;border:none;padding:10px 20px;border-radius:4px;cursor:pointer;font-size:14px;margin-bottom:15px;">Clear All Data</button>
    </div>
  `;

  nodeList.forEach(node => {
    const apiLabels = { '1': 'Map (2dMap)', '2': 'Map (Deployment)', '3': 'Resources', '4': 'Reservations', '5': 'VSM', '6': 'Connections', '7': 'Chutes' };
    let detailRows = '';

    if (node.savedMap) {
      const ts = node.savedTimestamp ? new Date(node.savedTimestamp).toLocaleString() : 'Unknown';
      detailRows += `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-color);">
        <span style="font-size:13px;">Saved Map (${node.entityCount || '?'} entities) — ${ts}</span>
        <span style="font-size:12px;color:var(--text-secondary);">localStorage</span>
      </div>`;
    }

    if (node.apiCalls) {
      for (const num of ['1', '2', '3', '4', '5', '6', '7']) {
        if (node.apiCalls[num]) {
          const call = node.apiCalls[num];
          const status = call.success ? '✅' : '❌';
          const ts = call.timestamp ? new Date(call.timestamp).toLocaleString() : '';
          detailRows += `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-color);">
            <span style="font-size:13px;">${status} ${apiLabels[num]} — ${ts}</span>
            <span style="font-size:12px;color:var(--text-secondary);">chrome.storage</span>
          </div>`;
        }
      }
    }

    html += `
      <div style="padding:15px;background:var(--bg-tertiary);border-radius:5px;margin-bottom:10px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <span style="font-weight:bold;font-size:16px;color:var(--text-primary);">${node.nodeId}</span>
          <button class="storage-clear-node" data-node-id="${node.nodeId}" style="background:#dc3545;color:#fff;border:none;padding:6px 14px;border-radius:4px;cursor:pointer;font-size:13px;">Clear</button>
        </div>
        ${detailRows}
      </div>
    `;
  });

  return html;
}

function setupStorageSettingsHandlers(contentEl) {
  const clearAllBtn = document.getElementById('storage-clear-all');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', async () => {
      if (!confirm('Are you sure you want to clear ALL saved data for every node?')) return;

      // Clear localStorage maps
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key.startsWith(STORAGE_KEY_PREFIX)) keysToRemove.push(key);
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));

      // Clear chrome.storage API results
      const allStorage = await chrome.storage.local.get(null);
      const chromeKeys = Object.keys(allStorage).filter(k => /^apiResult[1234567]_/.test(k) || k.startsWith('heatMapCache_'));
      if (chromeKeys.length > 0) await chrome.storage.local.remove(chromeKeys);

      // Also clear lastUsedNode
      await chrome.storage.local.remove(['lastUsedNode']);

      console.log('🗑️ All saved data cleared');
      contentEl.innerHTML = await renderStorageSettingsContent();
      setupStorageSettingsHandlers(contentEl);
    });
  }

  document.querySelectorAll('.storage-clear-node').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const nodeId = e.target.dataset.nodeId;
      if (!confirm(`Clear all saved data for ${nodeId}?`)) return;

      // Clear localStorage map
      localStorage.removeItem(STORAGE_KEY_PREFIX + nodeId);

      // Clear chrome.storage API results
      await chrome.storage.local.remove([
        `apiResult1_${nodeId}`,
        `apiResult2_${nodeId}`,
        `apiResult3_${nodeId}`,
        `apiResult4_${nodeId}`,
        `apiResult5_${nodeId}`,
        `apiResult6_${nodeId}`,
        `apiResult7_${nodeId}`,
        `heatMapCache_${nodeId}`
      ]);

      console.log(`🗑️ Cleared all data for ${nodeId}`);
      contentEl.innerHTML = await renderStorageSettingsContent();
      setupStorageSettingsHandlers(contentEl);
    });
  });
}





async function onRootClick(e) {
  const target = e.target;
  
  // Settings icon
  if (target.id === 'settings-icon') {
    showSettingsModal();
    return;
  }

  // Inbound View tool
  if (target.id === 'tool-inbound-view') {
    showInboundViewControls();
    return;
  }

  // Inbound View: run fetch
  if (target.id === 'inbound-view-run') {
    await runInboundView();
    return;
  }

  // Inbound View: clear
  if (target.id === 'inbound-view-clear') {
    clearInboundView();
    renderMapViewSidebar();
    return;
  }

  // Heat Map tool
  if (target.id === 'tool-heat-map') {
    showHeatMapControls();
    return;
  }

  // Heat Map: run pipeline
  if (target.id === 'heatmap-run') {
    await runHeatMapPipeline();
    return;
  }

  // Heat Map: refresh inbound positions
  if (target.id === 'heatmap-refresh-inbound') {
    await refreshInboundPositions();
    return;
  }

  // Heat Map: VRID checkbox toggle
  if (target.classList.contains('heatmap-vrid-cb')) {
    updateHeatMapFromCheckboxes();
    return;
  }

  // Heat Map: select all / deselect all VRIDs
  if (target.id === 'heatmap-select-all') {
    document.querySelectorAll('.heatmap-vrid-cb').forEach(cb => cb.checked = true);
    updateHeatMapFromCheckboxes();
    return;
  }
  if (target.id === 'heatmap-deselect-all') {
    document.querySelectorAll('.heatmap-vrid-cb').forEach(cb => cb.checked = false);
    updateHeatMapFromCheckboxes();
    return;
  }

  // Heat Map: clear / back to tools
  if (target.id === 'heatmap-clear') {
    clearHeatMap();
    renderMapViewSidebar();
    return;
  }

  // Heat Map: export undrawn packages
  if (target.id === 'heatmap-export-undrawn') {
    exportUndrawnPackages();
    return;
  }
  
  // API Testing buttons
  if (target.id === 'test-api-inbound') {
    const nodeId = document.getElementById('api-node-id-inbound').value.toUpperCase();
    console.log('  Fetching inbound dock view for node:', nodeId);
    await fetchInboundAndExport(nodeId);
    return;
  }
  
  if (target.id === 'test-api-fullraw') {
    const nodeId = document.getElementById('api-node-id-fullraw').value.toUpperCase();
    const startInput = document.getElementById('api-fullraw-start');
    const endInput = document.getElementById('api-fullraw-end');
    const startDate = startInput ? new Date(startInput.value).getTime() : Date.now();
    const endDate = endInput ? new Date(endInput.value).getTime() : Date.now() + 48 * 60 * 60 * 1000;
    console.log('📊 Fetching full raw inbound for node:', nodeId, 'range:', startDate, '-', endDate);
    await fetchFullRawInboundAndExport(nodeId, startDate, endDate);
    return;
  }
  
  if (target.id === 'test-api-containers') {
    const nodeId = document.getElementById('api-node-id-containers').value.toUpperCase();
    console.log('📋 Fetching all inbound containers for node:', nodeId);
    await fetchAllContainersAndExport(nodeId);
    return;
  }
  
  if (target.id === 'test-api-pipeline') {
    const nodeId = document.getElementById('api-node-id-pipeline').value.toUpperCase();
    const startInput = document.getElementById('api-pipeline-start').value;
    const endInput = document.getElementById('api-pipeline-end').value;
    const startDate = new Date(startInput).getTime();
    const endDate = new Date(endInput).getTime();
    console.log('🚀 Running full inbound pipeline for node:', nodeId);
    await runFullInboundPipeline(nodeId, startDate, endDate);
    return;
  }

  if (target.id === 'test-api-tantei') {
    const nodeId = document.getElementById('api-node-id-tantei').value.toUpperCase();
    const vridsRaw = document.getElementById('api-tantei-vrids').value.trim();
    const vrids = vridsRaw.split(/[\n,]+/).map(v => v.trim()).filter(v => v.length > 0);
    if (vrids.length === 0) {
      alert('Please enter at least one VRID');
      return;
    }
    console.log('🔍 Tantei search for node:', nodeId, 'VRIDs:', vrids);
    await fetchTanteiAndExport(nodeId, vrids);
    return;
  }
  
  if (target.id === 'add-map-btn') {
    renderEditorSetupView();
    return;
  }
  
  // FIX 2: The load-map-btn handler was completely garbled in the original.
  // Reconstructed clean, correct version below.
  if (target.id === 'load-map-btn') {
    const nodeInput = document.getElementById('node-input');
    const nodeId = nodeInput
      ? nodeInput.value.trim().toUpperCase()
      : document.getElementById('node-id-select')?.value;
    
    if (!nodeId) {
      alert('Please enter a node ID');
      return;
    }
    
    selectedNodeId = nodeId;
    console.log('📍 Loading map for node:', selectedNodeId);
    
    // Save as last used node
    await chrome.storage.local.set({ lastUsedNode: selectedNodeId });
    console.log('💾 Saved last used node:', selectedNodeId);
    
    renderLoadingView();
    
    try {
      const data = await loadMapData(selectedNodeId);
      initializeMap(true);
      drawMap(data);
      renderMapViewSidebar();
      // Re-apply cached heat map if available
      if (heatMapData) {
        applyHeatMapColors();
      }
    } catch (err) {
      // If domain hop was initiated, just let it happen - no loading screen needed
      if (err.message === 'DOMAIN_HOP_INITIATED') {
        console.log('✅ Domain hop initiated, navigating...');
        return;
      }
      console.error("❌ FAILED at Load Map Button:", err);
      showErrorModal('Please try again or review your permissions.');
      mapContainer.innerHTML = `<div class="editor-setup-view"><h3>Error loading map.</h3><p>${err.message}</p></div>`;
    }
    return;
  }
  
  if (target.id === 'save-map-btn') {
    console.log('💾 Saving and locking map...');
    
    const success = saveMapToStorage(selectedNodeId);
    if (success) {
      currentView = 'mapView';
      currentTool = 'none';
      
      if (transformer) transformer.nodes([]);
      interactiveLayer.find('.editable-shape').forEach(shape => {
        shape.setDraggable(false);
      });
      stage.draggable(true);
      stage.container().style.cursor = 'default';
      
      renderMapViewSidebar();
      
      const tempMsg = document.createElement('div');
      tempMsg.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #28a745; color: white; padding: 15px 25px; border-radius: 5px; z-index: 10000; font-weight: bold;';
      tempMsg.textContent = 'Map Saved';
      document.body.appendChild(tempMsg);
      setTimeout(() => tempMsg.remove(), 2000);
    }
    return;
  }
  
  if (target.id === 'export-map-btn') {
    console.log('📥 Exporting map...');
    exportMapToFile(selectedNodeId);
    return;
  } 
  
  if (target.id === 'import-map-btn') {
    const fileInput = document.getElementById('import-map-input');
    if (fileInput) {
      fileInput.click();
    }
    return;
  }
  
  if (target.id === 'confirm-import-btn') {
    if (!selectedImportFile) {
      alert('No file selected');
      return;
    }
    
    console.log('📤 Importing map from file...');
    mapContainer.innerHTML = `<div class="loading-view"><h3>Importing Map...</h3></div>`;
    
    importMapFromFile(selectedImportFile)
      .then(mapData => {
        selectedNodeId = mapData.nodeId;
        allMapEntities = mapData.entities;
        
        initializeMap(true);
        drawMap(allMapEntities);
        
        saveMapToStorage(selectedNodeId);
        
        return chrome.storage.local.get([`apiResult3_${selectedNodeId}`])
          .then(resourceStorage => {
            const resourceResult = resourceStorage[`apiResult3_${selectedNodeId}`];
            if (resourceResult && resourceResult.success) {
              allApiResources = resourceResult.data[0].data.resources || [];
            } else {
              console.warn('⚠️ No cached resources data for', selectedNodeId);
              allApiResources = [];
            }
            calculateMissingResources();
            
            renderEditorTools();
            selectedImportFile = null;
            
            alert(`✅ Map imported successfully!\nNode: ${mapData.nodeId}\nEntities: ${mapData.entities.length}`);
          });
      })
      .catch(err => {
        console.error('❌ Import failed:', err);
        alert('Failed to import map: ' + err.message);
        renderEditorSetupView();
        selectedImportFile = null;
      });
    return;
  }
  
  if (target.id === 'cancel-import-btn') {
    console.log('Import cancelled');
    selectedImportFile = null;
    document.getElementById('import-file-status').style.display = 'none';
    document.getElementById('import-map-input').value = '';
    return;
  }
  
  if (target.id === 'reload-base-map-btn') {
    const confirmed = confirm('⚠️ Are you sure you want to reload the base map?\n\nThis will discard ALL changes and fetch fresh data from the API.');
    
    if (confirmed) {
      console.log('🔄 Reloading base map from API...');
      
      // Clear cached API data for this node
      console.log('🗑️ Clearing cached API data for node:', selectedNodeId);
      const storageKey1 = `apiResult1_${selectedNodeId}`;
      const storageKey2 = `apiResult2_${selectedNodeId}`;
      const storageKey3 = `apiResult3_${selectedNodeId}`;
      const storageKey4 = `apiResult4_${selectedNodeId}`;
      const storageKey5 = `apiResult5_${selectedNodeId}`;
      const storageKey6 = `apiResult6_${selectedNodeId}`;
      const storageKey7 = `apiResult7_${selectedNodeId}`;
      await chrome.storage.local.remove([storageKey1, storageKey2, storageKey3, storageKey4, storageKey5, storageKey6, storageKey7]);
      
      // Clear saved map
      localStorage.removeItem(STORAGE_KEY_PREFIX + selectedNodeId);
      lastSaveTime = null;
      
      renderLoadingView();
      
      // Force reload will trigger domain hop if no cached data
      try {
        const data = await loadMapData(selectedNodeId, true);
        if (stage) stage.destroy();
        
        initializeMap(true);
        drawMap(data);
        renderEditorTools();
        
        console.log('✅ Base map reloaded successfully');
      } catch (err) {
        // If domain hop was initiated, just let it happen - no loading screen needed
        if (err.message === 'DOMAIN_HOP_INITIATED') {
          console.log('✅ Domain hop initiated for reload, navigating...');
          return;
        }
        console.error('❌ Failed to reload map:', err);
        alert('Failed to reload map: ' + err.message);
      }
    }
    return;
  }
  
  if (target.classList.contains('tool-button')) {
    const newTool = target.dataset.tool;
    
    console.log(`🔧 Tool button clicked: ${newTool}`);
    
    currentTool = newTool;
    
    document.querySelectorAll('.tool-button').forEach(btn => {
      btn.classList.remove('active');
    });
    target.classList.add('active');
    
    if (interactiveLayer) {
      interactiveLayer.find('.editable-shape').forEach(shape => {
        shape.setDraggable(currentTool === 'select');
      });
    }
    
    if (currentTool !== 'select' && transformer) {
      transformer.nodes([]);
    }
    
    console.log('Current tool set to:', currentTool);
    
    const resourceType = toolToResourceType[currentTool];
    if (resourceType) {
      const title = target.innerText;
      renderAddEquipmentUI(resourceType, title);
      renderEquipmentList(missingResources[resourceType] || []);
    } else {
      const uiContainer = document.getElementById('add-equipment-ui');
      if (uiContainer) uiContainer.innerHTML = '';
    }
    return;
  }
  
  if (target.classList.contains('search-result-item')) {
    const resourceId = target.dataset.resourceId;
    const resource = allApiResources.find(r => r.resourceId === resourceId);
    
    console.log("Selected resource (for dragging):", resource);
    
    document.querySelectorAll('.search-result-item').forEach(item => item.classList.remove('selected'));
    target.classList.add('selected');
  }
}

function onFileInputChange(e) {
  const file = e.target.files[0];
  if (!file) return;
  
  console.log('📁 File selected:', file.name);
  selectedImportFile = file;
  
  const statusDiv = document.getElementById('import-file-status');
  const fileNameSpan = document.getElementById('import-file-name');
  
  if (statusDiv && fileNameSpan) {
    fileNameSpan.textContent = `Selected: ${file.name}`;
    statusDiv.style.display = 'block';
  }
}

function onRootInput(e) {
  const target = e.target;
  
  // Auto-capitalize node ID inputs
  if (target.id === 'api-node-id-inbound' || target.id === 'api-node-id-containers' || target.id === 'api-node-id-fullraw' || target.id === 'api-node-id-tantei') {
    const cursorPosition = target.selectionStart;
    target.value = target.value.toUpperCase();
    target.setSelectionRange(cursorPosition, cursorPosition);
  }
  
  if (target.id === 'equipment-search-bar') {
    const searchTerm = target.value.toLowerCase();
    
    const resourceType = toolToResourceType[currentTool];
    if (!resourceType) return;
    
    const items = missingResources[resourceType] || [];
    
    const filteredItems = items.filter(item => 
      item.label.toLowerCase().includes(searchTerm)
    );
    
    renderEquipmentList(filteredItems);
  }
}

function onRootChange(e) {
  const target = e.target;
  
  if (target.id === 'node-id-select') {
    selectedNodeId = target.value;
    console.log('Node ID set to:', selectedNodeId);
  }
  
  if (target.id === 'import-map-input') {
    onFileInputChange(e);
  }
}

function onRootDragStart(e) {
  if (!e.target.classList.contains('search-result-item')) {
    e.preventDefault();
    return;
  }
  
  const resourceId = e.target.dataset.resourceId;
  const resource = allApiResources.find(r => r.resourceId === resourceId);
  
  if (resource) {
    e.dataTransfer.setData("text/plain", JSON.stringify(resource));
    e.dataTransfer.effectAllowed = "copy";
    console.log("Dragging resource:", resource.label);
  } else {
    e.preventDefault();
  }
}

function onMapDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = "copy";
}

function onMapDrop(e) {
  e.preventDefault();
  
  const resource = JSON.parse(e.dataTransfer.getData("text/plain"));
  
  if (!stage) return;
  
  const mapRect = mapContainer.getBoundingClientRect();
  const dropX = e.clientX - mapRect.left;
  const dropY = e.clientY - mapRect.top;
  
  const transform = stage.getAbsoluteTransform().copy();
  transform.invert();
  const worldPos = transform.point({ x: dropX, y: dropY });
  
  const correctedPos = {
    x: worldPos.x,
    y: -worldPos.y
  };
  
  console.log(`Dropped ${resource.label} at`, correctedPos);
  
  drawNewItem(resource, correctedPos);
  
  const resourceType = resource.resourceType;
  missingResources[resourceType] = missingResources[resourceType].filter(
    item => item.resourceId !== resource.resourceId
  );
  renderEquipmentList(missingResources[resourceType] || []);
  
  console.log(`✅ Equipment placed. Current tool remains: ${currentTool}`);
}

// --- 8. Initialize and Load ---

// 🔧 Check if we should render the app or stay hidden
function shouldRenderApp() {
  const currentDomain = window.location.hostname;
  const currentPath = window.location.pathname;
  const hash = window.location.hash;
  
  console.log('🔍 Checking shouldRenderApp:', currentDomain, currentPath);
  console.log('🔍 URL hash:', hash);
  
  // Always render on amazonlogistics.com/ryan-vision (your main domain)
  if (currentDomain.includes('amazonlogistics.com')) {
    console.log('✅ On amazonlogistics.com - rendering app');
    return true;
  }
  
  // On API domains, check for hop parameters in URL hash
  if (hash && hash.includes('hop=')) {
    console.log('🚀 Domain hop detected in URL hash - rendering app');
    return true;
  }
  
  // Fallback: check localStorage
  const hopState = localStorage.getItem('domainHopState');
  if (hopState) {
    console.log('🚀 Domain hop detected in localStorage - rendering app');
    return true;
  }
  
  // Otherwise, don't render (let the original page show)
  console.log('ℹ️ On API domain but not in hop cycle - hiding extension UI');
  return false;
}

try {
  if (!rootContainer) {
    throw new Error("rootContainer was not successfully created. Script may have run before body.");
  }
  
  console.log("🔍 About to check shouldRenderApp()");
  const shouldRender = shouldRenderApp();
  console.log("🔍 shouldRenderApp() returned:", shouldRender);
  
  // Only attach listeners and render if we should show the app
  if (shouldRender) {
    // Add class to body to trigger CSS takeover
    document.body.classList.add('ryan-console-active');
    console.log("✅ Added ryan-console-active class to body");
    
    rootContainer.addEventListener('click', onRootClick);
    rootContainer.addEventListener('change', onRootChange);
    rootContainer.addEventListener('input', onRootInput);
    
    rootContainer.addEventListener('dragstart', onRootDragStart);
    mapContainer.addEventListener('dragover', onMapDragOver);
    mapContainer.addEventListener('drop', onMapDrop);
    
    console.log("✅ Event listeners attached to rootContainer");
  } else {
    // Hide the extension UI completely
    rootContainer.remove();
    console.log("✅ Extension UI removed (not in hop cycle)");
  }
} catch (err) {
  console.error("❌ FAILED AT STEP 8 (Attaching Listeners):", err);
}

try {
  const shouldRender = shouldRenderApp();
  console.log("🔍 Checking shouldRenderApp() for initial render:", shouldRender);
  
  if (shouldRender) {
    // Load saved theme preference
    chrome.storage.local.get(['theme'], (result) => {
      if (result.theme === 'dark') {
        document.body.classList.add('dark-mode');
        console.log('🌙 Dark mode enabled from saved preference');
      } else {
        document.body.classList.remove('dark-mode');
        console.log('☀️ Light mode enabled from saved preference');
      }
    });
    
    // Check if we're in a domain hop cycle FIRST
    const currentDomain = window.location.hostname;
    const hash = window.location.hash;
    const hopStateLS = localStorage.getItem('domainHopState');
    
    console.log('🔍 Initialization check:');
    console.log('   - currentDomain:', currentDomain);
    console.log('   - URL hash:', hash);
    console.log('   - localStorage hopState:', hopStateLS);
    console.log('   - Is stem?', currentDomain === 'stem-na.corp.amazon.com');
    
    const isHopCycle = (hash && hash.includes('hop=')) || hopStateLS;
    
    if (isHopCycle && currentDomain === 'stem-na.corp.amazon.com') {
      // We're on stem and in a hop cycle - execute API call immediately
      document.title = 'Ryan Vision';
      console.log('🚀 Domain hop detected on page load - executing API call');
      console.log('   Page title set to: Ryan Vision');
      console.log('🚀 Calling checkForDomainHop()...');
      checkForDomainHop();
      // Don't render normal UI - the hop will handle navigation
    } else {
      // Normal flow - render the UI
      document.title = 'Ryan Vision';
      console.log('📄 Normal flow - rendering initial view');
      console.log('   Page title set to: Ryan Vision');
      
      // Clean up any leftover hop state
      if (hopStateLS) {
        console.log('🗑️ Cleaning up leftover domainHopState');
        localStorage.removeItem('domainHopState');
      }
      
      // Check if there's a pending map load after domain hop
      const pendingMapLoad = localStorage.getItem('pendingMapLoad');
      if (pendingMapLoad) {
        console.log('🗺️ Pending map load detected for node:', pendingMapLoad);
        localStorage.removeItem('pendingMapLoad');
        
        // Skip renderInitialView — it would race with this via lastUsedNode auto-load
        renderLoadingView();
        
        // Auto-load the map with the fetched data
        setTimeout(async () => {
          console.log('🚀 Auto-loading map with fetched data...');
          selectedNodeId = pendingMapLoad;
          try {
            const data = await loadMapData(pendingMapLoad);
            initializeMap(true);
            drawMap(data);
            renderMapViewSidebar();
            // Re-apply cached heat map if available
            if (heatMapData) {
              applyHeatMapColors();
            }
            console.log('✅ Map loaded successfully');
          } catch (err) {
            if (err.message === 'DOMAIN_HOP_INITIATED') {
              console.log('✅ Domain hop initiated for pending load, navigating...');
              return;
            }
            console.error('❌ Failed to load map:', err);
            showErrorModal('Please try again or review your permissions.');
            // Use renderInitialViewContent to avoid re-triggering lastUsedNode auto-load
            renderInitialViewContent();
          }
        }, 500);
      } else {
        renderInitialView();
        console.log("✅ Initial view rendered");
      }
      
      // DON'T auto-display results - let user click the button
      // Results are available via "View Stored Results" button
    }
  }
} catch (err) {
  console.error("❌ FAILED AT STEP 8 (Initial Render):", err);
}