// Background service worker for Vista CSRF token fetching
// Content scripts can't always access cross-page HTML, but the background
// script can fetch any URL the extension has host_permissions for.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'fetchVistaCSRF') {
    const nodeId = msg.nodeId || 'MTN9';
    const url = `https://www.amazonlogistics.com/sortcenter/vista/${encodeURIComponent(nodeId)}`;

    console.log('[BG] Fetching Vista page for CSRF token:', url);

    fetch(url, {
      method: 'GET',
      credentials: 'include',
      redirect: 'follow'
    })
      .then(response => {
        console.log('[BG] Response status:', response.status, response.statusText);
        console.log('[BG] Response URL:', response.url);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText} (URL: ${response.url})`);
        }

        // Check for login redirect
        if (response.url.includes('/sso/') || response.url.includes('/login') || response.url.includes('/ap/signin')) {
          throw new Error('Redirected to login: ' + response.url);
        }

        return response.text();
      })
      .then(html => {
        console.log('[BG] HTML length:', html.length);

        // Try both attribute orderings
        const m1 = html.match(/<meta\s+name=["']tcp-header-csrf-token["']\s+content=["']([^"']+)["']/i);
        const m2 = html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']tcp-header-csrf-token["']/i);
        const token = m1?.[1] || m2?.[1] || null;

        if (token) {
          console.log('[BG] ✅ CSRF token found, length:', token.length);
          sendResponse({ success: true, token, htmlLength: html.length });
        } else {
          // Diagnostic info
          const allMetas = [...html.matchAll(/<meta\s+[^>]*name=["']([^"']+)["'][^>]*>/gi)].map(m => m[1]);
          const titleMatch = html.match(/<title>([^<]*)<\/title>/i);
          const title = titleMatch?.[1] || '(no title)';
          const preview = html.substring(0, 1000);

          console.log('[BG] ⚠️ Token not found. Title:', title, 'Metas:', allMetas);
          sendResponse({
            success: false,
            error: 'CSRF token meta tag not found in HTML',
            diagnostics: {
              title,
              metaNames: allMetas,
              htmlLength: html.length,
              preview
            }
          });
        }
      })
      .catch(err => {
        console.error('[BG] ❌ Fetch failed:', err);
        sendResponse({ success: false, error: err.message });
      });

    // Return true to indicate we'll call sendResponse asynchronously
    return true;
  }

  // --- Tantei CSRF token fetching ---
  if (msg.type === 'fetchTanteiCSRF') {
    const nodeId = msg.nodeId || 'MTN9';
    const url = `https://trans-logistics.amazon.com/sortcenter/tantei?nodeId=${encodeURIComponent(nodeId)}`;

    console.log('[BG] Fetching Tantei page for CSRF token:', url);

    fetch(url, {
      method: 'GET',
      credentials: 'include',
      redirect: 'follow'
    })
      .then(response => {
        console.log('[BG] Tantei response status:', response.status, response.statusText);
        console.log('[BG] Tantei response URL:', response.url);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText} (URL: ${response.url})`);
        }

        if (response.url.includes('/sso/') || response.url.includes('/login') || response.url.includes('/ap/signin')) {
          throw new Error('Redirected to login: ' + response.url);
        }

        return response.text();
      })
      .then(html => {
        console.log('[BG] Tantei HTML length:', html.length);

        // Strategy 1: Look for CSRF token in meta tags
        const m1 = html.match(/<meta\s+name=["']anti-csrftoken-a2z["']\s+content=["']([^"']+)["']/i);
        const m2 = html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']anti-csrftoken-a2z["']/i);
        const m3 = html.match(/<meta\s+[^>]*name=["']tcp-header-csrf-token["'][^>]*content=["']([^"']+)["']/i);
        const m4 = html.match(/<meta\s+[^>]*content=["']([^"']+)["'][^>]*name=["']tcp-header-csrf-token["']/i);

        // Strategy 2: Look for token in hidden input fields (e.g. <input name="__token_" type="hidden" value="...">)
        const m5 = html.match(/<input[^>]*name=["']__token_["'][^>]*value=["']([^"']+)["'][^>]*\/?>/i);
        const m6 = html.match(/<input[^>]*value=["']([^"']+)["'][^>]*name=["']__token_["'][^>]*\/?>/i);

        // Strategy 3: Look for token in inline scripts / config objects
        const m7 = html.match(/["']anti-csrftoken-a2z["']\s*[:=]\s*["']([^"']+)["']/i);
        const m8 = html.match(/["']csrfToken["']\s*[:=]\s*["']([^"']+)["']/i);
        const m9 = html.match(/["']tcp-header-csrf-token["']\s*[:=]\s*["']([^"']+)["']/i);
        const m10 = html.match(/csrf[_-]?token["']\s*[:=]\s*["']([A-Za-z0-9+/=]{20,})["']/i);

        // Strategy 4: Broad hidden input with a long base64-ish value (fallback)
        const m11 = html.match(/<input[^>]*type=["']hidden["'][^>]*value=["']([A-Za-z0-9+/=]{40,})["'][^>]*\/?>/i);

        const token = m1?.[1] || m2?.[1] || m3?.[1] || m4?.[1] || m5?.[1] || m6?.[1] || m7?.[1] || m8?.[1] || m9?.[1] || m10?.[1] || m11?.[1] || null;

        if (token) {
          console.log('[BG] ✅ Tantei CSRF token found, length:', token.length);
          sendResponse({ success: true, token, htmlLength: html.length });
        } else {
          // Dump diagnostic info to console for debugging
          const allMetas = [...html.matchAll(/<meta\s[^>]*>/gi)].map(m => m[0]);
          const titleMatch = html.match(/<title>([^<]*)<\/title>/i);
          const title = titleMatch?.[1] || '(no title)';

          // Search for ANY occurrence of "csrf" in the HTML
          const csrfMatches = [...html.matchAll(/csrf[^"'<>\s]{0,50}/gi)].map(m => m[0]);

          console.log('[BG] ⚠️ Tantei token not found.');
          console.log('[BG] Title:', title);
          console.log('[BG] All <meta> tags:', allMetas);
          console.log('[BG] All "csrf" occurrences:', csrfMatches);
          console.log('[BG] First 3000 chars:', html.substring(0, 3000));
          console.log('[BG] Last 1000 chars:', html.substring(html.length - 1000));

          sendResponse({
            success: false,
            error: 'Tantei CSRF token not found in HTML',
            diagnostics: {
              title,
              metaTags: allMetas.slice(0, 10),
              csrfOccurrences: csrfMatches,
              htmlLength: html.length
            }
          });
        }
      })
      .catch(err => {
        console.error('[BG] ❌ Tantei CSRF fetch failed:', err);
        sendResponse({ success: false, error: err.message });
      });

    return true;
  }

  // --- Tantei GraphQL proxy ---
  if (msg.type === 'tanteiGraphQL') {
    const { csrfToken, query, variables, nodeId } = msg;

    console.log('[BG] Tantei GraphQL call, nodeId:', nodeId);

    fetch('https://trans-logistics.amazon.com/sortcenter/tantei/graphql', {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'anti-csrftoken-a2z': csrfToken,
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin'
      },
      body: JSON.stringify({ query, variables })
    })
      .then(response => {
        console.log('[BG] Tantei GraphQL response:', response.status, response.statusText);
        console.log('[BG] Tantei GraphQL response URL:', response.url);

        if (!response.ok) {
          return response.text().then(text => {
            throw new Error(`HTTP ${response.status}: ${text.substring(0, 500)}`);
          });
        }

        if (response.url.includes('/sso/') || response.url.includes('/login') || response.url.includes('/ap/signin')) {
          throw new Error('Redirected to login: ' + response.url);
        }

        return response.json();
      })
      .then(data => {
        console.log('[BG] ✅ Tantei GraphQL success');
        sendResponse({ success: true, data });
      })
      .catch(err => {
        console.error('[BG] ❌ Tantei GraphQL failed:', err);
        sendResponse({ success: false, error: err.message });
      });

    return true;
  }

  // Unrecognized message type — log it
  console.warn('[BG] Unknown message type:', msg.type);
  return false;
});
